<?php
/**
 * Login Page - BookHaven Digital Library
 * Halaman login untuk member dan admin
 */
require_once __DIR__ . '/../includes/functions.php';

// Jika sudah login, redirect sesuai role
if (isLoggedIn()) {
    if (isAdmin()) {
        header("Location: " . BASE_URL . "admin/index.php");
    } else {
        header("Location: " . BASE_URL . "member/dashboard.php");
    }
    exit;
}

$page_title = 'Login';
$error = '';

if (isset($_SESSION['flash'])) {
    // Flash message akan ditampilkan di halaman
}

include __DIR__ . '/../includes/header.php';
?>

<!-- Login Page -->
<div class="flex-1 flex items-center justify-center px-4 py-12 sm:py-16">
    <div class="w-full max-w-md">

        <!-- Auth Card -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="p-8 sm:p-10">

                <!-- Logo / Header -->
                <div class="text-center mb-8">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                        <span class="material-symbols-outlined text-primary" style="font-size:36px;">auto_stories</span>
                    </div>
                    <h2 class="text-2xl font-serif font-bold text-gray-900 dark:text-white">Login ke <?= SITE_NAME ?></h2>
                    <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Masuk untuk meminjam dan membaca novel</p>
                </div>

                <!-- Flash Messages -->
                <?php showFlash(); ?>

                <?php if (isset($_GET['error'])): ?>
                    <div class="mb-4 flex items-start gap-3 rounded-lg border border-red-500/30 bg-red-500/10 p-3.5 text-sm text-red-400">
                        <span class="material-symbols-outlined text-red-400 mt-0.5" style="font-size:20px;">error</span>
                        <span><?= htmlspecialchars($_GET['error']) ?></span>
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['success'])): ?>
                    <div class="mb-4 flex items-start gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3.5 text-sm text-emerald-400">
                        <span class="material-symbols-outlined text-emerald-400 mt-0.5" style="font-size:20px;">check_circle</span>
                        <span><?= htmlspecialchars($_GET['success']) ?></span>
                    </div>
                <?php endif; ?>

                <!-- Login Form -->
                <form action="<?= BASE_URL ?>auth/process_login.php" method="POST" class="space-y-5">

                    <!-- Username -->
                    <div>
                        <label for="username" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Username</label>
                        <div class="relative">
                            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
                                <span class="material-symbols-outlined text-gray-400 dark:text-gray-500" style="font-size:20px;">person</span>
                            </div>
                            <input type="text" id="username" name="username"
                                   class="block w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-slate-50 dark:bg-[#111418] py-2.5 pl-11 pr-4 text-sm text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:border-primary focus:ring-2 focus:ring-primary/30 focus:outline-none transition"
                                   placeholder="Masukkan username" required>
                        </div>
                    </div>

                    <!-- Password -->
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Password</label>
                        <div class="relative">
                            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
                                <span class="material-symbols-outlined text-gray-400 dark:text-gray-500" style="font-size:20px;">lock</span>
                            </div>
                            <input type="password" id="password" name="password"
                                   class="block w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-slate-50 dark:bg-[#111418] py-2.5 pl-11 pr-4 text-sm text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:border-primary focus:ring-2 focus:ring-primary/30 focus:outline-none transition"
                                   placeholder="Masukkan password" required>
                        </div>
                    </div>

                    <!-- Submit -->
                    <button type="submit"
                            class="w-full flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-[#1e293b] transition-colors">
                        <span class="material-symbols-outlined" style="font-size:20px;">login</span>
                        Login
                    </button>
                </form>

                <!-- Divider -->
                <div class="relative my-6">
                    <div class="absolute inset-0 flex items-center"><div class="w-full border-t border-gray-200 dark:border-gray-600"></div></div>
                    <div class="relative flex justify-center text-xs">
                        <span class="bg-white dark:bg-[#1e293b] px-3 text-gray-400 dark:text-gray-500">atau</span>
                    </div>
                </div>

                <!-- Register Link -->
                <p class="text-center text-sm text-gray-500 dark:text-gray-400">
                    Belum punya akun?
                    <a href="<?= BASE_URL ?>auth/register.php" class="font-medium text-primary hover:text-primary/80 transition-colors">Daftar sekarang</a>
                </p>

            </div>

            <!-- Demo Hint Box -->
            <div class="border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-[#111418] px-8 py-4 sm:px-10">
                <div class="flex items-start gap-3">
                    <span class="material-symbols-outlined text-primary mt-0.5" style="font-size:20px;">info</span>
                    <div class="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                        <span class="font-semibold text-gray-700 dark:text-gray-300">Demo Login:</span><br>
                        Admin: <span class="font-mono text-gray-600 dark:text-gray-300">admin</span> / <span class="font-mono text-gray-600 dark:text-gray-300">password</span>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
