<?php
/**
 * Logout - BookHaven Digital Library
 * Menghapus session dan redirect ke halaman login
 */
require_once __DIR__ . '/../config/config.php';

// Hapus semua data session
session_unset();
session_destroy();

// Redirect ke login
header("Location: " . BASE_URL . "auth/login.php?success=Anda berhasil logout");
exit;
?>
