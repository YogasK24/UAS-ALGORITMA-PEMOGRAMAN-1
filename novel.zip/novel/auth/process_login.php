<?php
/**
 * Process Login - BookHaven Digital Library
 * ALGORITMA: PEMILIHAN (if-else) untuk validasi login
 */
require_once __DIR__ . '/../includes/functions.php';

// PEMILIHAN: Cek method request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . BASE_URL . "auth/login.php");
    exit;
}

// Ambil data dari form
$username = sanitize($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

// PEMILIHAN: Validasi input
if (empty($username) || empty($password)) {
    header("Location: " . BASE_URL . "auth/login.php?error=Username dan password harus diisi");
    exit;
}

// Query user dari database menggunakan prepared statement
$sql = "SELECT u.*, mt.tier_name FROM users u 
        JOIN membership_tiers mt ON u.tier_id = mt.tier_id 
        WHERE u.username = ? AND u.is_active = 1";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// PEMILIHAN: Verifikasi password
if ($user && password_verify($password, $user['password'])) {
    // Login berhasil - simpan data ke session (ARRAY)
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['tier_id'] = $user['tier_id'];
    $_SESSION['tier_name'] = $user['tier_name'];
    
    // PEMILIHAN: Redirect berdasarkan role
    if ($user['role'] === 'admin') {
        header("Location: " . BASE_URL . "admin/index.php");
    } else {
        header("Location: " . BASE_URL . "member/dashboard.php");
    }
    exit;
} else {
    // Login gagal
    header("Location: " . BASE_URL . "auth/login.php?error=Username atau password salah");
    exit;
}
?>
