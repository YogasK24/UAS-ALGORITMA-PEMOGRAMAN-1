<?php
/**
 * Process Register - BookHaven Digital Library
 * ALGORITMA: PEMILIHAN (if-else) untuk validasi registrasi
 */
require_once __DIR__ . '/../includes/functions.php';

// PEMILIHAN: Cek method request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . BASE_URL . "auth/register.php");
    exit;
}

// Ambil data dari form
$full_name = sanitize($_POST['full_name'] ?? '');
$username = sanitize($_POST['username'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$phone = sanitize($_POST['phone'] ?? '');
$address = sanitize($_POST['address'] ?? '');

// PEMILIHAN: Validasi input
if (empty($full_name) || empty($username) || empty($email) || empty($password)) {
    header("Location: " . BASE_URL . "auth/register.php?error=Semua field wajib harus diisi");
    exit;
}

if (strlen($username) < 3) {
    header("Location: " . BASE_URL . "auth/register.php?error=Username minimal 3 karakter");
    exit;
}

if (strlen($password) < 6) {
    header("Location: " . BASE_URL . "auth/register.php?error=Password minimal 6 karakter");
    exit;
}

if ($password !== $confirm_password) {
    header("Location: " . BASE_URL . "auth/register.php?error=Konfirmasi password tidak cocok");
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: " . BASE_URL . "auth/register.php?error=Format email tidak valid");
    exit;
}

// Cek username sudah dipakai
$sql = "SELECT user_id FROM users WHERE username = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    header("Location: " . BASE_URL . "auth/register.php?error=Username sudah digunakan");
    exit;
}

// Cek email sudah dipakai
$sql = "SELECT user_id FROM users WHERE email = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    header("Location: " . BASE_URL . "auth/register.php?error=Email sudah terdaftar");
    exit;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert user baru (default: member, tier Free)
$sql = "INSERT INTO users (username, password, full_name, email, phone, address, role, tier_id) 
        VALUES (?, ?, ?, ?, ?, ?, 'member', 1)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ssssss", $username, $hashed_password, $full_name, $email, $phone, $address);

if (mysqli_stmt_execute($stmt)) {
    header("Location: " . BASE_URL . "auth/login.php?success=Registrasi berhasil! Silakan login.");
    exit;
} else {
    header("Location: " . BASE_URL . "auth/register.php?error=Registrasi gagal. Silakan coba lagi.");
    exit;
}
?>
