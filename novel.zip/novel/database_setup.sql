-- =============================================
-- BookHaven - Sistem Perpustakaan Digital Novel
-- Database Setup Script
-- =============================================

-- Buat database
CREATE DATABASE IF NOT EXISTS db_digital_library;
USE db_digital_library;

-- =============================================
-- Tabel membership_tiers
-- =============================================
CREATE TABLE IF NOT EXISTS membership_tiers (
    tier_id INT PRIMARY KEY AUTO_INCREMENT,
    tier_name VARCHAR(20) NOT NULL,
    max_books INT NOT NULL COMMENT 'Max books dapat dipinjam bersamaan',
    borrow_days INT NOT NULL COMMENT 'Durasi peminjaman (hari)',
    renewal_limit INT NOT NULL COMMENT 'Berapa kali bisa extend',
    penalty_rate DECIMAL(10,2) NOT NULL COMMENT 'Denda per hari (Rupiah)',
    monthly_fee DECIMAL(10,2) DEFAULT 0,
    features TEXT COMMENT 'Fitur tier dalam JSON',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO membership_tiers VALUES
(1, 'Free', 2, 7, 0, 2000, 0, '{"priority":"Low","support":"Email"}', NOW()),
(2, 'Silver', 5, 14, 1, 1500, 50000, '{"priority":"Medium","support":"Email+Chat"}', NOW()),
(3, 'Gold', 10, 21, 2, 1000, 100000, '{"priority":"High","support":"24/7"}', NOW()),
(4, 'Premium', 999, 30, 999, 0, 200000, '{"priority":"VIP","support":"24/7+Phone"}', NOW());

-- =============================================
-- Tabel users
-- =============================================
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    address TEXT,
    role ENUM('admin','member') DEFAULT 'member',
    tier_id INT DEFAULT 1,
    tier_expiry DATE COMMENT 'Kapan membership expire',
    is_active BOOLEAN DEFAULT TRUE,
    status ENUM('active','suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tier_id) REFERENCES membership_tiers(tier_id)
);

-- Insert admin (password: password)
INSERT INTO users (username, password, email, full_name, role, tier_id) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
        'admin@bookhaven.com', 'Library Admin', 'admin', 4);

-- =============================================
-- Tabel authors
-- =============================================
CREATE TABLE IF NOT EXISTS authors (
    author_id INT PRIMARY KEY AUTO_INCREMENT,
    author_name VARCHAR(100) NOT NULL,
    biography TEXT,
    country VARCHAR(50),
    birth_year INT,
    photo VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO authors (author_name, biography, country, birth_year) VALUES
('Andrea Hirata', 'Penulis novel Laskar Pelangi yang terkenal dari Belitung', 'Indonesia', 1967),
('Tere Liye', 'Penulis novel populer Indonesia dengan berbagai genre', 'Indonesia', 1979),
('J.K. Rowling', 'Penulis seri Harry Potter yang terkenal di seluruh dunia', 'United Kingdom', 1965),
('Dan Brown', 'Penulis thriller dan misteri terlaris dunia', 'United States', 1964),
('Agatha Christie', 'Ratu misteri, penulis detektif paling terkenal', 'United Kingdom', 1890),
('Paulo Coelho', 'Penulis The Alchemist, novelis Brazil terkenal', 'Brazil', 1947),
('Haruki Murakami', 'Penulis novel Jepang kontemporer', 'Japan', 1949),
('Dee Lestari', 'Penulis novel Supernova dan musisi Indonesia', 'Indonesia', 1976);

-- =============================================
-- Tabel publishers
-- =============================================
CREATE TABLE IF NOT EXISTS publishers (
    publisher_id INT PRIMARY KEY AUTO_INCREMENT,
    publisher_name VARCHAR(100) NOT NULL,
    country VARCHAR(50),
    website VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO publishers (publisher_name, country, website) VALUES
('Gramedia Pustaka Utama', 'Indonesia', 'https://gpu.id'),
('Mizan', 'Indonesia', 'https://mizan.com'),
('Bentang Pustaka', 'Indonesia', 'https://bentangpustaka.com'),
('Penguin Books', 'United Kingdom', 'https://penguin.co.uk'),
('HarperCollins', 'United States', 'https://harpercollins.com'),
('Bloomsbury', 'United Kingdom', 'https://bloomsbury.com');

-- =============================================
-- Tabel genres
-- =============================================
CREATE TABLE IF NOT EXISTS genres (
    genre_id INT PRIMARY KEY AUTO_INCREMENT,
    genre_name VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO genres (genre_name, description) VALUES
('Romance', 'Novel tentang percintaan dan hubungan'),
('Mystery', 'Novel misteri dan detektif'),
('Fantasy', 'Novel fantasi dengan dunia imajinatif'),
('Sci-Fi', 'Science fiction dan teknologi masa depan'),
('Horror', 'Novel horor dan thriller'),
('Historical', 'Novel berlatar sejarah'),
('Biography', 'Biografi dan memoir'),
('Adventure', 'Novel petualangan');

-- =============================================
-- Tabel books
-- =============================================
CREATE TABLE IF NOT EXISTS books (
    book_id INT PRIMARY KEY AUTO_INCREMENT,
    isbn VARCHAR(20) UNIQUE,
    title VARCHAR(200) NOT NULL,
    author_id INT,
    publisher_id INT,
    year_published INT,
    pages INT,
    language VARCHAR(50) DEFAULT 'Indonesian',
    synopsis TEXT,
    cover_image VARCHAR(255),
    pdf_file VARCHAR(255) COMMENT 'Path to PDF file',
    total_copies INT DEFAULT 1,
    available_copies INT DEFAULT 1,
    rating_avg DECIMAL(3,2) DEFAULT 0,
    total_reviews INT DEFAULT 0,
    total_borrowed INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES authors(author_id),
    FOREIGN KEY (publisher_id) REFERENCES publishers(publisher_id)
);

INSERT INTO books (isbn, title, author_id, publisher_id, year_published, pages, language, synopsis, cover_image, total_copies, available_copies) VALUES
('978-979-22-1', 'Laskar Pelangi', 1, 3, 2005, 534, 'Indonesian', 'Kisah inspiratif 10 anak dari Belitung yang berjuang untuk mendapatkan pendidikan layak.', 'https://covers.openlibrary.org/b/id/7079796-L.jpg', 5, 5),
('978-979-22-2', 'Sang Pemimpi', 1, 3, 2006, 292, 'Indonesian', 'Kelanjutan Laskar Pelangi, tentang mimpi besar anak-anak Belitung.', 'https://books.google.com/books/content?id=FQ_xml4y71EC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api', 3, 3),
('978-602-03-1', 'Bumi', 2, 1, 2014, 440, 'Indonesian', 'Novel fantasi tentang tiga remaja dengan kekuatan luar biasa.', 'https://covers.openlibrary.org/b/id/12810708-L.jpg', 4, 4),
('978-602-03-2', 'Bulan', 2, 1, 2015, 400, 'Indonesian', 'Kelanjutan petualangan fantasi dari novel Bumi.', 'https://covers.openlibrary.org/b/id/14640031-L.jpg', 3, 3),
('978-0-7475-1', 'Harry Potter and the Philosophers Stone', 3, 6, 1997, 309, 'English', 'Kisah awal Harry Potter menemukan dunia sihir di Hogwarts.', 'https://covers.openlibrary.org/b/id/15155833-L.jpg', 5, 5),
('978-0-385-1', 'The Da Vinci Code', 4, 5, 2003, 689, 'English', 'Thriller misteri tentang konspirasi dan rahasia tersembunyi dalam karya seni.', 'https://covers.openlibrary.org/b/id/9255229-L.jpg', 3, 3),
('978-0-06-1', 'Murder on the Orient Express', 5, 5, 1934, 274, 'English', 'Misteri klasik Hercule Poirot di kereta Orient Express.', 'https://covers.openlibrary.org/b/id/11100465-L.jpg', 2, 2),
('978-0-06-2', 'The Alchemist', 6, 5, 1988, 197, 'English', 'Kisah seorang gembala Spanyol yang mencari harta karun di Mesir.', 'https://covers.openlibrary.org/b/id/7414780-L.jpg', 4, 4),
('978-4-10-1', 'Norwegian Wood', 7, 4, 1987, 389, 'English', 'Novel tentang kenangan, cinta, dan kehilangan di Tokyo tahun 1960-an.', 'https://covers.openlibrary.org/b/id/2237620-L.jpg', 2, 2),
('978-979-22-3', 'Supernova: Ksatria Puteri dan Bintang Jatuh', 8, 3, 2001, 308, 'Indonesian', 'Novel pertama serial Supernova tentang cinta, sains, dan spiritualitas.', 'https://covers.openlibrary.org/b/id/7026997-L.jpg', 3, 3);

-- =============================================
-- Tabel book_genres (Many-to-Many)
-- =============================================
CREATE TABLE IF NOT EXISTS book_genres (
    id INT PRIMARY KEY AUTO_INCREMENT,
    book_id INT,
    genre_id INT,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
    FOREIGN KEY (genre_id) REFERENCES genres(genre_id),
    UNIQUE KEY unique_book_genre (book_id, genre_id)
);

INSERT INTO book_genres (book_id, genre_id) VALUES
(1, 8), (1, 6), -- Laskar Pelangi: Adventure, Historical
(2, 8), (2, 6), -- Sang Pemimpi: Adventure, Historical
(3, 3), (3, 8), -- Bumi: Fantasy, Adventure
(4, 3), (4, 8), -- Bulan: Fantasy, Adventure
(5, 3), (5, 8), -- Harry Potter: Fantasy, Adventure
(6, 2), (6, 8), -- Da Vinci Code: Mystery, Adventure
(7, 2),          -- Murder Orient Express: Mystery
(8, 3), (8, 8), -- Alchemist: Fantasy, Adventure
(9, 1),          -- Norwegian Wood: Romance
(10, 4), (10, 1); -- Supernova: Sci-Fi, Romance

-- =============================================
-- Tabel borrowings
-- =============================================
CREATE TABLE IF NOT EXISTS borrowings (
    borrow_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    book_id INT,
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE NULL,
    extended_count INT DEFAULT 0 COMMENT 'Berapa kali sudah extend',
    status ENUM('borrowed','returned','overdue') DEFAULT 'borrowed',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (book_id) REFERENCES books(book_id)
);


-- =============================================
-- Tabel penalties
-- =============================================
CREATE TABLE IF NOT EXISTS penalties (
    penalty_id INT PRIMARY KEY AUTO_INCREMENT,
    borrow_id INT,
    user_id INT,
    penalty_amount DECIMAL(10,2) NOT NULL,
    days_late INT NOT NULL,
    penalty_status ENUM('unpaid','paid','waived') DEFAULT 'unpaid',
    paid_at DATETIME NULL,
    payment_method VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (borrow_id) REFERENCES borrowings(borrow_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- =============================================
-- Tabel reviews
-- =============================================
CREATE TABLE IF NOT EXISTS reviews (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    book_id INT,
    user_id INT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT,
    helpful_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    UNIQUE KEY unique_user_book_review (user_id, book_id)
);

-- =============================================
-- Tabel reading_lists (Wishlist)
-- =============================================
CREATE TABLE IF NOT EXISTS reading_lists (
    list_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    book_id INT,
    status ENUM('want_to_read','currently_reading','finished') DEFAULT 'want_to_read',
    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_book_list (user_id, book_id)
);
