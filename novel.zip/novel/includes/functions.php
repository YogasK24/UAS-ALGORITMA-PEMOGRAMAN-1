<?php
/**
 * Helper Functions - BookHaven Digital Library
 * 
 * DOKUMENTASI ALGORITMA:
 * File ini berisi fungsi-fungsi helper yang menggunakan:
 * - PEMILIHAN (if-else, switch-case)
 * - PERULANGAN (foreach, while)
 * - ARRAY & ARRAY MULTIDIMENSI
 */

require_once __DIR__ . '/../config/config.php';

// =============================================
// FUNGSI AUTENTIKASI
// =============================================

/**
 * Cek apakah user sudah login
 * ALGORITMA: PEMILIHAN (if-else)
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Cek apakah user adalah admin
 * ALGORITMA: PEMILIHAN (if-else)
 */
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Cek apakah user adalah member
 * ALGORITMA: PEMILIHAN (if-else)
 */
function isMember() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'member';
}

/**
 * Redirect jika belum login
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . BASE_URL . "auth/login.php");
        exit;
    }
}

/**
 * Redirect jika bukan admin
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header("Location: " . BASE_URL . "index.php");
        exit;
    }
}

/**
 * Redirect jika bukan member
 */
function requireMember() {
    requireLogin();
    if (!isMember()) {
        header("Location: " . BASE_URL . "index.php");
        exit;
    }
}

// =============================================
// FUNGSI PENALTY CALCULATOR (CORE ALGORITHM)
// =============================================

/**
 * Menghitung denda keterlambatan pengembalian buku
 * ALGORITMA: PEMILIHAN (switch-case) + PERULANGAN + ARRAY
 * 
 * @param int $borrowing_id ID peminjaman
 * @param mysqli $conn Koneksi database
 * @return array|int Data denda atau 0 jika tidak ada
 */
function calculatePenalty($borrowing_id, $conn) {
    // Query data peminjaman dengan info tier membership
    $sql = "SELECT b.*, u.tier_id, mt.penalty_rate, mt.tier_name
            FROM borrowings b
            JOIN users u ON b.user_id = u.user_id
            JOIN membership_tiers mt ON u.tier_id = mt.tier_id
            WHERE b.borrow_id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $borrowing_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $borrow = mysqli_fetch_assoc($result);
    
    // PEMILIHAN: Jika data tidak ditemukan
    if (!$borrow) return 0;
    
    // Hitung selisih hari keterlambatan
    $due_date = new DateTime($borrow['due_date']);
    $return_date = $borrow['return_date'] ? new DateTime($borrow['return_date']) : new DateTime();
    $days_late = (int)$return_date->diff($due_date)->format('%r%a');
    
    // PEMILIHAN: Jika tidak terlambat, tidak ada denda
    if ($days_late <= 0) {
        return 0;
    }
    
    // PEMILIHAN (SWITCH-CASE): Tentukan tarif denda berdasarkan tier
    $penalty_rate = 0;
    switch ($borrow['tier_name']) {
        case 'Free':
            $penalty_rate = 2000;   // Rp 2.000/hari
            break;
        case 'Silver':
            $penalty_rate = 1500;   // Rp 1.500/hari
            break;
        case 'Gold':
            $penalty_rate = 1000;   // Rp 1.000/hari
            break;
        case 'Premium':
            $penalty_rate = 0;      // Gratis untuk Premium
            break;
        default:
            $penalty_rate = 2000;   // Default: Rp 2.000/hari
    }
    
    // Hitung total denda
    $total_penalty = $days_late * $penalty_rate;
    
    // ARRAY: Kembalikan data denda dalam array
    return [
        'days_late' => $days_late,
        'penalty_rate' => $penalty_rate,
        'total_amount' => $total_penalty,
        'tier_name' => $borrow['tier_name']
    ];
}

/**
 * Cek apakah user boleh meminjam buku
 * ALGORITMA: ARRAY + PEMILIHAN (if-else)
 * 
 * @param int $user_id ID user
 * @param mysqli $conn Koneksi database
 * @return array Info kemampuan pinjam
 */
function canUserBorrow($user_id, $conn) {
    // Hitung jumlah peminjaman aktif saat ini
    $sql = "SELECT COUNT(*) as count FROM borrowings 
            WHERE user_id = ? AND status = 'borrowed'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    $current_count = $row['count'];
    
    // Ambil info tier membership user
    $sql = "SELECT mt.* FROM users u 
            JOIN membership_tiers mt ON u.tier_id = mt.tier_id
            WHERE u.user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $tier = mysqli_fetch_assoc($result);
    
    // Cek denda yang belum dibayar
    $sql = "SELECT COUNT(*) as count FROM penalties 
            WHERE user_id = ? AND penalty_status = 'unpaid'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    $unpaid_penalties = $row['count'];
    
    // ARRAY: Kembalikan info lengkap
    // PEMILIHAN: Tentukan apakah boleh pinjam
    return [
        'can_borrow' => ($current_count < $tier['max_books'] && $unpaid_penalties == 0),
        'current_count' => $current_count,
        'max_books' => $tier['max_books'],
        'borrow_days' => $tier['borrow_days'],
        'tier_name' => $tier['tier_name'],
        'renewal_limit' => $tier['renewal_limit'],
        'has_unpaid_penalty' => ($unpaid_penalties > 0),
        'message' => ($current_count >= $tier['max_books']) 
            ? "Batas peminjaman tercapai untuk tier {$tier['tier_name']} ({$tier['max_books']} buku)"
            : (($unpaid_penalties > 0) ? "Harap bayar denda terlebih dahulu" : "OK")
    ];
}

/**
 * Mendapatkan rekomendasi buku berdasarkan riwayat baca
 * ALGORITMA: FOREACH, ARRAY MULTIDIMENSI, array_count_values
 * 
 * @param int $user_id ID user
 * @param mysqli $conn Koneksi database
 * @return array Daftar buku rekomendasi (array multidimensi)
 */
function getRecommendations($user_id, $conn) {
    // 1. Ambil riwayat peminjaman user
    $sql = "SELECT DISTINCT bg.genre_id, g.genre_name
            FROM borrowings br
            JOIN book_genres bg ON br.book_id = bg.book_id
            JOIN genres g ON bg.genre_id = g.genre_id
            WHERE br.user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    // 2. ARRAY: Kumpulkan genre dari buku yang pernah dipinjam
    $genre_list = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $genre_list[] = $row['genre_id'];
    }
    
    // Jika belum pernah pinjam, ambil buku populer
    if (empty($genre_list)) {
        $sql = "SELECT b.*, a.author_name 
                FROM books b 
                LEFT JOIN authors a ON b.author_id = a.author_id
                WHERE b.is_active = 1
                ORDER BY b.total_borrowed DESC, b.rating_avg DESC
                LIMIT 10";
        $result = mysqli_query($conn, $sql);
        $recommendations = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $recommendations[] = $row;
        }
        return $recommendations;
    }
    
    // 3. ARRAY: Hitung frekuensi genre
    $genre_counts = array_count_values($genre_list);
    arsort($genre_counts);
    
    // 4. Ambil top 3 genre favorit
    $top_genres = array_slice(array_keys($genre_counts), 0, 3);
    $genre_ids = implode(',', array_map('intval', $top_genres));
    
    // 5. Query buku dengan genre yang sama tapi belum pernah dipinjam
    $sql = "SELECT DISTINCT b.*, a.author_name
            FROM books b
            LEFT JOIN authors a ON b.author_id = a.author_id
            JOIN book_genres bg ON b.book_id = bg.book_id
            WHERE bg.genre_id IN ($genre_ids)
            AND b.book_id NOT IN (
                SELECT book_id FROM borrowings WHERE user_id = ?
            )
            AND b.is_active = 1
            ORDER BY b.rating_avg DESC, b.total_borrowed DESC
            LIMIT 10";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    // 6. ARRAY MULTIDIMENSI: Simpan rekomendasi
    $recommendations = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $recommendations[] = $row;
    }
    
    return $recommendations;
}

// =============================================
// FUNGSI UTILITY
// =============================================

/**
 * Format angka ke format Rupiah
 */
function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Format tanggal ke format Indonesia
 */
function formatDate($date) {
    if (!$date) return '-';
    return date('d M Y', strtotime($date));
}

/**
 * Sanitize input user
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Set flash message
 */
function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Tampilkan flash message
 */
function showFlash() {
    if (isset($_SESSION['flash'])) {
        $type = $_SESSION['flash']['type'];
        $message = $_SESSION['flash']['message'];
        $colors = [
            'success' => 'bg-green-100 dark:bg-green-900/30 border-green-400 dark:border-green-700 text-green-800 dark:text-green-300',
            'danger'  => 'bg-red-100 dark:bg-red-900/30 border-red-400 dark:border-red-700 text-red-800 dark:text-red-300',
            'warning' => 'bg-yellow-100 dark:bg-yellow-900/30 border-yellow-400 dark:border-yellow-700 text-yellow-800 dark:text-yellow-300',
            'info'    => 'bg-blue-100 dark:bg-blue-900/30 border-blue-400 dark:border-blue-700 text-blue-800 dark:text-blue-300',
        ];
        $icons = ['success'=>'check_circle','danger'=>'error','warning'=>'warning','info'=>'info'];
        $c = $colors[$type] ?? $colors['info'];
        $ic = $icons[$type] ?? 'info';
        echo "<div class='flex items-center gap-3 px-4 py-3 rounded-xl border {$c} text-sm' role='alert'>
                <span class='material-symbols-outlined text-[20px]'>{$ic}</span>
                <span class='flex-1'>{$message}</span>
                <button onclick='this.parentElement.remove()' class='opacity-60 hover:opacity-100 transition-opacity'>
                    <span class='material-symbols-outlined text-[18px]'>close</span>
                </button>
              </div>";
        unset($_SESSION['flash']);
    }
}

/**
 * Generate rating stars HTML
 */
function ratingStars($rating, $size = 'text-sm') {
    $html = '<div class="flex items-center gap-0.5 ' . $size . '">';
    for ($i = 1; $i <= 5; $i++) {
        if ($i <= floor($rating)) {
            $html .= '<span class="material-symbols-outlined text-yellow-400 !text-[16px]" style="font-variation-settings:\'FILL\' 1">star</span>';
        } elseif ($i - 0.5 <= $rating) {
            $html .= '<span class="material-symbols-outlined text-yellow-400 !text-[16px]" style="font-variation-settings:\'FILL\' 1">star_half</span>';
        } else {
            $html .= '<span class="material-symbols-outlined text-slate-400 dark:text-slate-600 !text-[16px]">star</span>';
        }
    }
    $html .= '</div>';
    return $html;
}

/**
 * Ambil genre untuk sebuah buku
 * ALGORITMA: WHILE loop + ARRAY
 */
function getBookGenres($book_id, $conn) {
    $sql = "SELECT g.genre_id, g.genre_name FROM book_genres bg 
            JOIN genres g ON bg.genre_id = g.genre_id 
            WHERE bg.book_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $book_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $genres = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $genres[] = $row;
    }
    return $genres;
}

/**
 * Warna badge genre
 * ALGORITMA: SWITCH-CASE
 */
function getGenreBadgeClass($genre_name) {
    switch ($genre_name) {
        case 'Romance': return 'bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-400';
        case 'Mystery': return 'bg-slate-100 dark:bg-slate-700/50 text-slate-700 dark:text-slate-300';
        case 'Fantasy': return 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400';
        case 'Sci-Fi': return 'bg-cyan-100 dark:bg-cyan-900/30 text-cyan-700 dark:text-cyan-400';
        case 'Horror': return 'bg-gray-100 dark:bg-gray-700/50 text-gray-700 dark:text-gray-300';
        case 'Historical': return 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400';
        case 'Biography': return 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400';
        case 'Adventure': return 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400';
        default: return 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400';
    }
}

/**
 * Ambil info user lengkap
 */
function getUserInfo($user_id, $conn) {
    $sql = "SELECT u.*, mt.tier_name, mt.max_books, mt.borrow_days, 
                   mt.renewal_limit, mt.penalty_rate, mt.monthly_fee
            FROM users u
            JOIN membership_tiers mt ON u.tier_id = mt.tier_id
            WHERE u.user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

/**
 * Dapatkan URL cover buku
 * Mendukung: URL eksternal (http/https) dan file lokal di uploads/covers/
 * ALGORITMA: IF-ELSE, STRING function
 * @param string|null $cover_image - Nilai kolom cover_image dari DB
 * @return string|null - Full URL cover atau null jika tidak ada
 */
function getBookCoverUrl($cover_image) {
    if (empty($cover_image)) return null;
    // Jika sudah berupa URL (http/https), langsung return
    if (preg_match('/^https?:\/\//i', $cover_image)) {
        return $cover_image;
    }
    // Jika file lokal, cek keberadaannya
    $local_path = __DIR__ . '/../uploads/covers/' . $cover_image;
    if (file_exists($local_path)) {
        return BASE_URL . 'uploads/covers/' . $cover_image;
    }
    return null;
}

/**
 * Hitung total denda belum bayar user
 */
function getUnpaidPenalties($user_id, $conn) {
    $sql = "SELECT COALESCE(SUM(penalty_amount), 0) as total FROM penalties 
            WHERE user_id = ? AND penalty_status = 'unpaid'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    return $row['total'];
}
?>
