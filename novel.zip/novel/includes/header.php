<?php
/**
 * BookHaven - Header Include (Tailwind Dark Mode UI)
 * Consistent design system across all pages
 */
if (!isset($page_title)) $page_title = 'BookHaven';
$is_admin_page = strpos($_SERVER['PHP_SELF'], '/admin/') !== false;
$is_member_page = strpos($_SERVER['PHP_SELF'], '/member/') !== false;
$is_auth_page = strpos($_SERVER['PHP_SELF'], '/auth/') !== false;

// Current page for active nav highlighting
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html class="dark" lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> - <?= SITE_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Playfair+Display:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#1466b8",
                        "secondary": "#3b82f6",
                        "background-light": "#f6f7f8",
                        "background-dark": "#111921",
                        "surface-light": "#ffffff",
                        "surface-dark": "#1e293b",
                        "text-primary-light": "#111827",
                        "text-primary-dark": "#f8fafc",
                        "text-secondary-light": "#6b7280",
                        "text-secondary-dark": "#94a3b8",
                        "accent-red": "#ef4444",
                        "accent-cream": "#F5F5DC",
                        "navy": "#2C3E50",
                        "navy-dark": "#1e293b",
                        "burgundy": "#8B0000",
                    },
                    fontFamily: {
                        "display": ["Inter", "sans-serif"],
                        "serif": ["Playfair Display", "serif"],
                    },
                    borderRadius: {"DEFAULT": "0.25rem", "lg": "0.5rem", "xl": "0.75rem", "full": "9999px"},
                },
            },
        }
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: #1e293b; }
        ::-webkit-scrollbar-thumb { background: #475569; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #64748b; }
        @media print { .no-print { display: none !important; } html { background: #fff !important; } }
    </style>
</head>
<body class="bg-background-light dark:bg-background-dark text-text-primary-light dark:text-text-primary-dark font-display min-h-screen <?= $is_admin_page ? 'flex overflow-hidden' : 'flex flex-col' ?>">
<?php if ($is_admin_page): ?>
    <?php include __DIR__ . '/admin_sidebar.php'; ?>
<?php else: ?>
    <?php include __DIR__ . '/navbar.php'; ?>
<?php endif; ?>
