<?php
/**
 * BookHaven - Admin Sidebar (Tailwind Dark Mode)
 * Matches admin_dashboard_overview reference UI
 */
$admin_page = basename($_SERVER['PHP_SELF'], '.php');
$nav_items = [
    ['page' => 'index', 'icon' => 'dashboard', 'label' => 'Dashboard'],
    ['page' => 'books', 'icon' => 'inventory_2', 'label' => 'Manajemen Buku'],
    ['page' => 'authors', 'icon' => 'person_edit', 'label' => 'Penulis'],
    ['page' => 'publishers', 'icon' => 'apartment', 'label' => 'Penerbit'],
    ['page' => 'genres', 'icon' => 'category', 'label' => 'Genre'],
    ['page' => 'borrowings', 'icon' => 'swap_horiz', 'label' => 'Peminjaman'],
    ['page' => 'members', 'icon' => 'group', 'label' => 'Anggota'],
    ['page' => 'penalties', 'icon' => 'gavel', 'label' => 'Denda'],
    ['page' => 'reports', 'icon' => 'assessment', 'label' => 'Laporan'],
];
?>
<aside class="w-72 flex flex-col bg-white dark:bg-[#111418] border-r border-slate-200 dark:border-slate-800 h-screen shrink-0 no-print">
    <!-- Logo -->
    <div class="flex items-center gap-3 px-6 py-5 border-b border-slate-100 dark:border-slate-800">
        <div class="text-primary">
            <span class="material-symbols-outlined text-3xl">menu_book</span>
        </div>
        <h1 class="text-slate-900 dark:text-white text-xl font-bold font-serif tracking-tight"><?= SITE_NAME ?></h1>
    </div>
    <!-- Navigation -->
    <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <?php foreach ($nav_items as $item): ?>
        <a href="<?= BASE_URL ?>admin/<?= $item['page'] === 'index' ? 'index' : $item['page'] ?>.php"
           class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
                  <?= $admin_page === $item['page']
                      ? 'bg-primary text-white shadow-sm shadow-primary/30'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
            <span class="material-symbols-outlined text-[20px]"><?= $item['icon'] ?></span>
            <span><?= $item['label'] ?></span>
        </a>
        <?php endforeach; ?>
    </nav>
    <!-- Back to Site & User Profile -->
    <div class="border-t border-slate-100 dark:border-slate-800 px-3 py-3 space-y-2">
        <a href="<?= BASE_URL ?>index.php" class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-all duration-200">
            <span class="material-symbols-outlined text-[20px]">home</span>
            <span>Kembali ke Situs</span>
        </a>
        <div class="flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
            <div class="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                <?= strtoupper(substr($_SESSION['full_name'] ?? 'A', 0, 1)) ?>
            </div>
            <div class="min-w-0 flex-1">
                <p class="text-sm font-semibold text-slate-900 dark:text-white truncate"><?= htmlspecialchars($_SESSION['full_name'] ?? 'Admin') ?></p>
                <p class="text-xs text-slate-500 dark:text-slate-400">Administrator</p>
            </div>
            <a href="<?= BASE_URL ?>auth/logout.php" class="text-slate-400 hover:text-accent-red transition-colors" title="Logout">
                <span class="material-symbols-outlined text-[20px]">logout</span>
            </a>
        </div>
    </div>
</aside>
