<?php
/**
 * BookHaven - Public Navbar (Tailwind Dark Mode)
 * Matches catalog_explorer reference UI
 */
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<header class="sticky top-0 z-50 flex items-center justify-between whitespace-nowrap border-b border-solid border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111418] px-6 py-3 lg:px-10 no-print">
    <div class="flex items-center gap-4">
        <a href="<?= BASE_URL ?>index.php" class="flex items-center gap-3">
            <div class="text-primary dark:text-white">
                <span class="material-symbols-outlined text-3xl">menu_book</span>
            </div>
            <h2 class="text-slate-900 dark:text-white text-xl font-bold font-serif tracking-tight"><?= SITE_NAME ?></h2>
        </a>
    </div>
    <div class="flex items-center gap-8">
        <nav class="hidden md:flex items-center gap-6">
            <a href="<?= BASE_URL ?>index.php" class="<?= $current_page === 'index' ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-primary pb-0.5' : 'text-slate-600 dark:text-slate-300 hover:text-primary dark:hover:text-white' ?> text-sm font-medium transition-colors">Home</a>
            <a href="<?= BASE_URL ?>catalog.php" class="<?= $current_page === 'catalog' ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-primary pb-0.5' : 'text-slate-600 dark:text-slate-300 hover:text-primary dark:hover:text-white' ?> text-sm font-medium transition-colors">Catalog</a>

            <?php if (isLoggedIn() && isMember()): ?>
            <a href="<?= BASE_URL ?>member/dashboard.php" class="<?= $is_member_page ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-primary pb-0.5' : 'text-slate-600 dark:text-slate-300 hover:text-primary dark:hover:text-white' ?> text-sm font-medium transition-colors">My Books</a>
            <?php endif; ?>

            <?php if (isLoggedIn() && isAdmin()): ?>
            <a href="<?= BASE_URL ?>admin/index.php" class="text-slate-600 dark:text-slate-300 hover:text-primary dark:hover:text-white text-sm font-medium transition-colors flex items-center gap-1">
                <span class="material-symbols-outlined text-[16px]">admin_panel_settings</span> Admin
            </a>
            <?php endif; ?>
        </nav>

        <div class="flex items-center gap-3">
            <?php if (isLoggedIn()): ?>
                <!-- User Info -->
                <div class="relative" x-data="{ open: false }">
                    <button onclick="document.getElementById('userDropdown').classList.toggle('hidden')" class="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity">
                        <div class="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                            <?= strtoupper(substr($_SESSION['full_name'], 0, 1)) ?>
                        </div>
                        <div class="hidden sm:block text-left">
                            <p class="text-sm font-medium text-slate-900 dark:text-white leading-tight"><?= htmlspecialchars($_SESSION['full_name']) ?></p>
                            <p class="text-[10px] text-primary font-bold uppercase tracking-wider"><?= $_SESSION['tier_name'] ?? 'Free' ?></p>
                        </div>
                        <span class="material-symbols-outlined text-slate-400 text-[16px] hidden sm:block">expand_more</span>
                    </button>
                    <div id="userDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white dark:bg-[#1e293b] rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 py-2 z-50">
                        <?php if (isMember()): ?>
                        <a href="<?= BASE_URL ?>member/dashboard.php" class="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
                            <span class="material-symbols-outlined text-[18px]">dashboard</span> Dashboard
                        </a>
                        <a href="<?= BASE_URL ?>member/borrowed.php" class="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
                            <span class="material-symbols-outlined text-[18px]">library_books</span> Buku Dipinjam
                        </a>
                        <a href="<?= BASE_URL ?>member/profile.php" class="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700">
                            <span class="material-symbols-outlined text-[18px]">person</span> Profil
                        </a>
                        <div class="border-t border-slate-200 dark:border-slate-700 my-1"></div>
                        <?php endif; ?>
                        <a href="<?= BASE_URL ?>auth/logout.php" class="flex items-center gap-2 px-4 py-2 text-sm text-accent-red hover:bg-red-50 dark:hover:bg-red-900/20">
                            <span class="material-symbols-outlined text-[18px]">logout</span> Logout
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <a href="<?= BASE_URL ?>auth/login.php" class="text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-primary transition-colors">Login</a>
                <a href="<?= BASE_URL ?>auth/register.php" class="text-sm font-semibold bg-primary text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors shadow-sm">Register</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<!-- Close dropdown on outside click -->
<script>document.addEventListener('click',function(e){var d=document.getElementById('userDropdown');if(d&&!e.target.closest('[onclick]')&&!d.contains(e.target))d.classList.add('hidden');});</script>
