<?php
/**
 * BookHaven - Footer (Tailwind Dark Mode)
 */
?>
<?php if (!$is_admin_page): ?>
<footer class="bg-white dark:bg-[#111418] border-t border-slate-200 dark:border-slate-800 mt-auto no-print">
    <div class="max-w-7xl mx-auto px-6 py-10 lg:px-10">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <!-- Brand -->
            <div class="md:col-span-2">
                <div class="flex items-center gap-3 mb-4">
                    <span class="material-symbols-outlined text-primary text-3xl">menu_book</span>
                    <h3 class="text-lg font-bold font-serif text-slate-900 dark:text-white"><?= SITE_NAME ?></h3>
                </div>
                <p class="text-sm text-slate-500 dark:text-slate-400 leading-relaxed max-w-md">
                    Perpustakaan digital modern yang menyediakan akses mudah ke ribuan koleksi buku berkualitas. 
                    Jelajahi, pinjam, dan nikmati dunia literasi kapan saja, di mana saja.
                </p>
            </div>
            <!-- Quick Links -->
            <div>
                <h4 class="text-sm font-semibold text-slate-900 dark:text-white mb-4">Tautan Cepat</h4>
                <ul class="space-y-2.5">
                    <li><a href="<?= BASE_URL ?>index.php" class="text-sm text-slate-500 dark:text-slate-400 hover:text-primary dark:hover:text-primary transition-colors">Beranda</a></li>
                    <li><a href="<?= BASE_URL ?>catalog.php" class="text-sm text-slate-500 dark:text-slate-400 hover:text-primary dark:hover:text-primary transition-colors">Katalog</a></li>
                    <?php if (isLoggedIn() && isMember()): ?>
                    <li><a href="<?= BASE_URL ?>member/dashboard.php" class="text-sm text-slate-500 dark:text-slate-400 hover:text-primary dark:hover:text-primary transition-colors">Dashboard</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <!-- Contact -->
            <div>
                <h4 class="text-sm font-semibold text-slate-900 dark:text-white mb-4">Kontak</h4>
                <ul class="space-y-2.5">
                    <li class="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                        <span class="material-symbols-outlined text-[16px]">mail</span> admin@bookhaven.id
                    </li>
                    <li class="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                        <span class="material-symbols-outlined text-[16px]">phone</span> (021) 1234-5678
                    </li>
                    <li class="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                        <span class="material-symbols-outlined text-[16px]">location_on</span> Jakarta, Indonesia
                    </li>
                </ul>
            </div>
        </div>
        <div class="border-t border-slate-200 dark:border-slate-700 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
            <p class="text-xs text-slate-400">&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p>
            <div class="flex gap-4">
                <a href="#" class="text-slate-400 hover:text-primary transition-colors"><span class="material-symbols-outlined text-[20px]">public</span></a>
                <a href="#" class="text-slate-400 hover:text-primary transition-colors"><span class="material-symbols-outlined text-[20px]">share</span></a>
            </div>
        </div>
    </div>
</footer>
<?php endif; ?>

<!-- Tailwind Modals Support -->
<script>
// Generic modal handler
function openModal(id){ document.getElementById(id)?.classList.remove('hidden'); document.body.style.overflow='hidden'; }
function closeModal(id){ document.getElementById(id)?.classList.add('hidden'); document.body.style.overflow=''; }
document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ document.querySelectorAll('[data-modal]').forEach(m=>m.classList.add('hidden')); document.body.style.overflow=''; }});
</script>
</body>
</html>
