<?php
/**
 * Book Detail - BookHaven Digital Library
 * Halaman detail novel dengan review dan info peminjaman
 * ALGORITMA: IF-ELSE, FOREACH, ARRAY MULTIDIMENSI
 */
require_once __DIR__ . '/includes/functions.php';

// PEMILIHAN: Validasi parameter
$book_id = intval($_GET['id'] ?? 0);
if ($book_id <= 0) {
    header("Location: " . BASE_URL . "catalog.php");
    exit;
}

// Query detail buku (ARRAY MULTIDIMENSI)
$sql = "SELECT b.*, a.author_name, a.biography, a.country, a.birth_year,
               p.publisher_name, p.website as publisher_website
        FROM books b
        LEFT JOIN authors a ON b.author_id = a.author_id
        LEFT JOIN publishers p ON b.publisher_id = p.publisher_id
        WHERE b.book_id = ? AND b.is_active = 1";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $book_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$book = mysqli_fetch_assoc($result);

// PEMILIHAN: Jika buku tidak ditemukan
if (!$book) {
    header("Location: " . BASE_URL . "catalog.php");
    exit;
}

$page_title = $book['title'];

// Ambil genre buku
$book['genres'] = getBookGenres($book_id, $conn);

// Query reviews (ARRAY MULTIDIMENSI)
$sql_reviews = "SELECT r.*, u.username, u.full_name 
                FROM reviews r 
                JOIN users u ON r.user_id = u.user_id 
                WHERE r.book_id = ? 
                ORDER BY r.created_at DESC";
$stmt = mysqli_prepare($conn, $sql_reviews);
mysqli_stmt_bind_param($stmt, "i", $book_id);
mysqli_stmt_execute($stmt);
$result_reviews = mysqli_stmt_get_result($stmt);
$reviews = [];
while ($row = mysqli_fetch_assoc($result_reviews)) {
    $reviews[] = $row;
}

// Cek apakah user sudah review
$user_has_reviewed = false;
if (isLoggedIn()) {
    $sql = "SELECT review_id FROM reviews WHERE book_id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    $uid = $_SESSION['user_id'];
    mysqli_stmt_bind_param($stmt, "ii", $book_id, $uid);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user_has_reviewed = (mysqli_num_rows($result) > 0);
}

// Cek apakah buku ada di reading list
$in_reading_list = false;
if (isLoggedIn()) {
    $sql = "SELECT list_id FROM reading_lists WHERE book_id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $book_id, $uid);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $in_reading_list = (mysqli_num_rows($result) > 0);
}

// Process review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review']) && isLoggedIn()) {
    $rating = intval($_POST['rating']);
    $review_text = sanitize($_POST['review_text'] ?? '');
    
    if ($rating >= 1 && $rating <= 5) {
        $sql = "INSERT INTO reviews (book_id, user_id, rating, review_text) VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE rating = ?, review_text = ?, updated_at = NOW()";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "iiisis", $book_id, $uid, $rating, $review_text, $rating, $review_text);
        
        if (mysqli_stmt_execute($stmt)) {
            // Update rata-rata rating buku
            $sql = "UPDATE books SET 
                    rating_avg = (SELECT AVG(rating) FROM reviews WHERE book_id = ?),
                    total_reviews = (SELECT COUNT(*) FROM reviews WHERE book_id = ?)
                    WHERE book_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "iii", $book_id, $book_id, $book_id);
            mysqli_stmt_execute($stmt);
            
            setFlash('success', 'Review berhasil disimpan!');
            header("Location: " . BASE_URL . "book_detail.php?id=$book_id");
            exit;
        }
    }
}

// Process add to reading list
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_reading_list']) && isLoggedIn()) {
    $sql = "INSERT IGNORE INTO reading_lists (user_id, book_id) VALUES (?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $uid, $book_id);
    if (mysqli_stmt_execute($stmt)) {
        setFlash('success', 'Buku ditambahkan ke Reading List!');
        header("Location: " . BASE_URL . "book_detail.php?id=$book_id");
        exit;
    }
}

include __DIR__ . '/includes/header.php';
?>

<main class="flex-1">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-8">

        <!-- Flash Message -->
        <div class="mb-6">
            <?php showFlash(); ?>
        </div>

        <!-- Breadcrumb -->
        <nav class="mb-8" aria-label="breadcrumb">
            <ol class="flex items-center gap-2 text-sm text-slate-400 dark:text-slate-500">
                <li class="flex items-center gap-1">
                    <span class="material-symbols-outlined text-[16px]">home</span>
                    <a href="<?= BASE_URL ?>index.php" class="hover:text-primary transition-colors">Beranda</a>
                </li>
                <li class="flex items-center gap-1">
                    <span class="material-symbols-outlined text-[14px]">chevron_right</span>
                    <a href="<?= BASE_URL ?>catalog.php" class="hover:text-primary transition-colors">Katalog</a>
                </li>
                <li class="flex items-center gap-1">
                    <span class="material-symbols-outlined text-[14px]">chevron_right</span>
                    <span class="text-slate-200 dark:text-slate-300 font-medium truncate max-w-[250px]"><?= htmlspecialchars($book['title']) ?></span>
                </li>
            </ol>
        </nav>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">

            <!-- ========================================== -->
            <!-- LEFT COLUMN: Cover & Actions              -->
            <!-- ========================================== -->
            <div class="lg:col-span-3 space-y-5">

                <!-- Book Cover Card -->
                <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                    <?php $cover_url = getBookCoverUrl($book['cover_image']); ?>
                    <?php if ($cover_url): ?>
                        <img src="<?= htmlspecialchars($cover_url) ?>" 
                             alt="<?= htmlspecialchars($book['title']) ?>" 
                             class="w-full aspect-[2/3] object-cover">
                    <?php else: ?>
                        <div class="w-full aspect-[2/3] bg-gradient-to-br from-primary/30 via-[#1e293b] to-slate-900 flex flex-col items-center justify-center p-6 text-center">
                            <span class="material-symbols-outlined text-slate-400 dark:text-slate-500 !text-[72px] mb-4" style="font-variation-settings:'FILL' 0,'wght' 200">auto_stories</span>
                            <h4 class="text-white/80 font-serif font-bold text-lg leading-tight"><?= htmlspecialchars($book['title']) ?></h4>
                            <p class="text-slate-400 text-xs mt-2"><?= htmlspecialchars($book['author_name'] ?? '') ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Action Buttons -->
                <div class="space-y-3">
                    <?php if ($book['available_copies'] > 0): ?>
                        <?php if (isLoggedIn() && isMember()): ?>
                            <form method="POST" action="<?= BASE_URL ?>borrow_book.php">
                                <input type="hidden" name="book_id" value="<?= $book['book_id'] ?>">
                                <button type="submit" class="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-200 shadow-lg shadow-primary/25 hover:shadow-primary/40">
                                    <span class="material-symbols-outlined text-[20px]">download</span>
                                    Pinjam Buku
                                </button>
                            </form>
                        <?php elseif (!isLoggedIn()): ?>
                            <a href="<?= BASE_URL ?>auth/login.php" class="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-200 shadow-lg shadow-primary/25">
                                <span class="material-symbols-outlined text-[20px]">login</span>
                                Login untuk Meminjam
                            </a>
                        <?php endif; ?>

                        <!-- Availability Badge -->
                        <div class="flex items-center justify-center gap-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl py-2.5 px-4 text-sm font-medium">
                            <span class="material-symbols-outlined text-[18px]" style="font-variation-settings:'FILL' 1">check_circle</span>
                            Tersedia (<?= $book['available_copies'] ?>/<?= $book['total_copies'] ?>)
                        </div>
                    <?php else: ?>
                        <!-- Unavailable Badge -->
                        <div class="flex items-center justify-center gap-2 bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl py-2.5 px-4 text-sm font-medium">
                            <span class="material-symbols-outlined text-[18px]" style="font-variation-settings:'FILL' 1">cancel</span>
                            Semua Dipinjam
                        </div>
                    <?php endif; ?>

                    <!-- Reading List Button -->
                    <?php if (isLoggedIn() && !$in_reading_list): ?>
                        <form method="POST">
                            <input type="hidden" name="add_reading_list" value="1">
                            <button type="submit" class="w-full flex items-center justify-center gap-2 border border-pink-500/40 text-pink-400 hover:bg-pink-500/10 font-medium py-2.5 px-4 rounded-xl transition-all duration-200 text-sm">
                                <span class="material-symbols-outlined text-[20px]">favorite_border</span>
                                Tambah ke Reading List
                            </button>
                        </form>
                    <?php elseif ($in_reading_list): ?>
                        <div class="w-full flex items-center justify-center gap-2 border border-slate-600 text-slate-400 py-2.5 px-4 rounded-xl text-sm cursor-default">
                            <span class="material-symbols-outlined text-pink-400 text-[20px]" style="font-variation-settings:'FILL' 1">favorite</span>
                            Sudah di Reading List
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ========================================== -->
            <!-- RIGHT COLUMN: Book Info                   -->
            <!-- ========================================== -->
            <div class="lg:col-span-9 space-y-6">

                <!-- Title & Author -->
                <div>
                    <h1 class="text-3xl sm:text-4xl font-serif font-bold text-slate-900 dark:text-white leading-tight mb-3">
                        <?= htmlspecialchars($book['title']) ?>
                    </h1>
                    <p class="text-slate-500 dark:text-slate-400 text-base">
                        oleh
                        <span class="text-slate-800 dark:text-white font-semibold"><?= htmlspecialchars($book['author_name'] ?? 'Unknown') ?></span>
                        <?php if ($book['publisher_name']): ?>
                            <span class="mx-2 text-slate-300 dark:text-slate-600">&bull;</span>
                            <span><?= htmlspecialchars($book['publisher_name']) ?></span>
                        <?php endif; ?>
                    </p>
                </div>

                <!-- Genre Badges -->
                <div class="flex flex-wrap gap-2">
                    <?php foreach ($book['genres'] as $genre): ?>
                        <span class="inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-semibold <?= getGenreBadgeClass($genre['genre_name']) ?>">
                            <?= $genre['genre_name'] ?>
                        </span>
                    <?php endforeach; ?>
                </div>

                <!-- Rating Display Card -->
                <div class="flex flex-wrap items-center gap-4 bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm px-5 py-4">
                    <div class="flex items-center gap-3">
                        <div class="flex items-center gap-1">
                            <?= ratingStars($book['rating_avg'], 'text-base') ?>
                        </div>
                        <span class="text-2xl font-bold text-yellow-400"><?= number_format($book['rating_avg'], 1) ?></span>
                    </div>
                    <div class="h-8 w-px bg-slate-200 dark:bg-slate-600 hidden sm:block"></div>
                    <div class="flex items-center gap-1.5 text-sm text-slate-500 dark:text-slate-400">
                        <span class="material-symbols-outlined text-[18px]">rate_review</span>
                        <?= $book['total_reviews'] ?> review
                    </div>
                    <div class="h-8 w-px bg-slate-200 dark:bg-slate-600 hidden sm:block"></div>
                    <div class="flex items-center gap-1.5 text-sm text-slate-500 dark:text-slate-400">
                        <span class="material-symbols-outlined text-[18px]">bookmark</span>
                        <?= $book['total_borrowed'] ?>x dipinjam
                    </div>
                </div>

                <!-- Book Details Table Card -->
                <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                    <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                            <span class="material-symbols-outlined text-primary text-[22px]">info</span>
                            Informasi Buku
                        </h3>
                    </div>
                    <div class="p-5">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
                            <div class="flex items-start gap-3">
                                <span class="material-symbols-outlined text-slate-400 dark:text-slate-500 text-[20px] mt-0.5">qr_code</span>
                                <div>
                                    <p class="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider font-medium">ISBN</p>
                                    <p class="text-sm text-slate-800 dark:text-slate-200 font-medium mt-0.5"><?= $book['isbn'] ?: '-' ?></p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <span class="material-symbols-outlined text-slate-400 dark:text-slate-500 text-[20px] mt-0.5">calendar_month</span>
                                <div>
                                    <p class="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider font-medium">Tahun Terbit</p>
                                    <p class="text-sm text-slate-800 dark:text-slate-200 font-medium mt-0.5"><?= $book['year_published'] ?: '-' ?></p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <span class="material-symbols-outlined text-slate-400 dark:text-slate-500 text-[20px] mt-0.5">description</span>
                                <div>
                                    <p class="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider font-medium">Halaman</p>
                                    <p class="text-sm text-slate-800 dark:text-slate-200 font-medium mt-0.5"><?= $book['pages'] ?: '-' ?></p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <span class="material-symbols-outlined text-slate-400 dark:text-slate-500 text-[20px] mt-0.5">translate</span>
                                <div>
                                    <p class="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider font-medium">Bahasa</p>
                                    <p class="text-sm text-slate-800 dark:text-slate-200 font-medium mt-0.5"><?= $book['language'] ?></p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <span class="material-symbols-outlined text-slate-400 dark:text-slate-500 text-[20px] mt-0.5">domain</span>
                                <div>
                                    <p class="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider font-medium">Penerbit</p>
                                    <p class="text-sm text-slate-800 dark:text-slate-200 font-medium mt-0.5"><?= htmlspecialchars($book['publisher_name'] ?? '-') ?></p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <span class="material-symbols-outlined text-slate-400 dark:text-slate-500 text-[20px] mt-0.5">inventory_2</span>
                                <div>
                                    <p class="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider font-medium">Stok</p>
                                    <p class="text-sm text-slate-800 dark:text-slate-200 font-medium mt-0.5"><?= $book['available_copies'] ?>/<?= $book['total_copies'] ?> tersedia</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Synopsis Card -->
                <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                    <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                            <span class="material-symbols-outlined text-primary text-[22px]">article</span>
                            Sinopsis
                        </h3>
                    </div>
                    <div class="p-5">
                        <p class="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                            <?= nl2br(htmlspecialchars($book['synopsis'] ?? 'Sinopsis belum tersedia.')) ?>
                        </p>
                    </div>
                </div>

                <!-- Author Info Card -->
                <?php if ($book['author_name']): ?>
                    <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                        <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700">
                            <h3 class="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                                <span class="material-symbols-outlined text-primary text-[22px]">person</span>
                                Tentang Penulis
                            </h3>
                        </div>
                        <div class="p-5">
                            <div class="flex items-start gap-4">
                                <div class="w-14 h-14 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
                                    <span class="material-symbols-outlined text-primary text-[28px]">person</span>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <h4 class="text-base font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($book['author_name']) ?></h4>
                                    <div class="flex flex-wrap items-center gap-3 mt-1 text-sm text-slate-400 dark:text-slate-500">
                                        <?php if ($book['country']): ?>
                                            <span class="flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[16px]">location_on</span>
                                                <?= htmlspecialchars($book['country']) ?>
                                            </span>
                                        <?php endif; ?>
                                        <?php if ($book['birth_year']): ?>
                                            <span class="flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[16px]">cake</span>
                                                Lahir tahun <?= $book['birth_year'] ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($book['biography']): ?>
                                        <p class="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mt-3"><?= htmlspecialchars($book['biography']) ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Reviews Section Card -->
                <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                    <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                            <span class="material-symbols-outlined text-primary text-[22px]">reviews</span>
                            Review & Rating
                            <span class="ml-1 inline-flex items-center justify-center bg-primary/10 text-primary text-xs font-bold rounded-full px-2.5 py-0.5"><?= count($reviews) ?></span>
                        </h3>
                    </div>
                    <div class="p-5 space-y-5">

                        <!-- Review Form (logged-in member who hasn't reviewed yet) -->
                        <?php if (isLoggedIn() && isMember() && !$user_has_reviewed): ?>
                            <form method="POST" class="bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 p-5">
                                <h4 class="text-sm font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                                    <span class="material-symbols-outlined text-[18px] text-primary">edit_note</span>
                                    Tulis Review Anda
                                </h4>
                                <div class="mb-4">
                                    <label class="block text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Rating</label>
                                    <select name="rating" required
                                            class="w-44 bg-white dark:bg-[#1e293b] border border-slate-300 dark:border-slate-600 rounded-lg px-3 py-2 text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all">
                                        <option value="">Pilih...</option>
                                        <option value="5">★★★★★ (5)</option>
                                        <option value="4">★★★★☆ (4)</option>
                                        <option value="3">★★★☆☆ (3)</option>
                                        <option value="2">★★☆☆☆ (2)</option>
                                        <option value="1">★☆☆☆☆ (1)</option>
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="block text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Ulasan</label>
                                    <textarea name="review_text" rows="3"
                                              placeholder="Tulis pendapat Anda tentang novel ini..."
                                              class="w-full bg-white dark:bg-[#1e293b] border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-3 text-sm text-slate-800 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all resize-none"></textarea>
                                </div>
                                <button type="submit" name="submit_review"
                                        class="inline-flex items-center gap-2 bg-primary hover:bg-primary/90 text-white font-semibold text-sm py-2.5 px-5 rounded-lg transition-all duration-200 shadow-sm">
                                    <span class="material-symbols-outlined text-[18px]">send</span>
                                    Kirim Review
                                </button>
                            </form>
                        <?php endif; ?>

                        <!-- Reviews List -->
                        <?php if (empty($reviews)): ?>
                            <div class="text-center py-10">
                                <span class="material-symbols-outlined text-slate-300 dark:text-slate-600 !text-[48px] mb-3" style="font-variation-settings:'FILL' 0,'wght' 200">chat_bubble</span>
                                <p class="text-slate-400 dark:text-slate-500 text-sm">Belum ada review. Jadilah yang pertama!</p>
                            </div>
                        <?php else: ?>
                            <div class="divide-y divide-slate-100 dark:divide-slate-700/50">
                                <?php 
                                // PERULANGAN (FOREACH): Tampilkan setiap review
                                foreach ($reviews as $review): 
                                ?>
                                    <div class="py-4 first:pt-0 last:pb-0">
                                        <div class="flex items-start justify-between gap-4">
                                            <div class="flex items-start gap-3">
                                                <!-- User Avatar -->
                                                <div class="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
                                                    <span class="text-primary font-bold text-sm"><?= strtoupper(substr($review['full_name'], 0, 1)) ?></span>
                                                </div>
                                                <div>
                                                    <div class="flex items-center gap-2 flex-wrap">
                                                        <span class="font-semibold text-sm text-slate-900 dark:text-white"><?= htmlspecialchars($review['full_name']) ?></span>
                                                        <div class="flex items-center">
                                                            <?= ratingStars($review['rating']) ?>
                                                        </div>
                                                    </div>
                                                    <p class="text-xs text-slate-400 dark:text-slate-500 mt-0.5"><?= formatDate($review['created_at']) ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if ($review['review_text']): ?>
                                            <p class="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mt-3 ml-[52px]"><?= htmlspecialchars($review['review_text']) ?></p>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>

            </div><!-- /right column -->
        </div><!-- /grid -->
    </div><!-- /container -->
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
