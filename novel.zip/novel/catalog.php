<?php
/**
 * Katalog Buku - BookHaven Digital Library
 * ALGORITMA: 
 * - FOREACH (tampilkan buku, nested foreach genre)
 * - IF-ELSE (filter dinamis)
 * - SWITCH-CASE (sorting)
 * - ARRAY (genre filter, buku data)
 */
require_once __DIR__ . '/includes/functions.php';

$page_title = 'Katalog Novel';

// =============================================
// AMBIL PARAMETER FILTER (ARRAY)
// =============================================
$search = sanitize($_GET['search'] ?? '');
$selected_genres = $_GET['genres'] ?? []; // ARRAY: genre yang dipilih
$year_min = intval($_GET['year_min'] ?? 1900);
$year_max = intval($_GET['year_max'] ?? date('Y'));
$rating_filter = sanitize($_GET['rating'] ?? '');
$availability = sanitize($_GET['availability'] ?? '');
$sort = sanitize($_GET['sort'] ?? 'newest');
$page = max(1, intval($_GET['page'] ?? 1));

// =============================================
// BUILD DYNAMIC SQL QUERY
// ALGORITMA: IF-ELSE untuk setiap filter
// =============================================
$where_clauses = ["b.is_active = 1"];
$params = [];
$types = "";

// PEMILIHAN: Filter pencarian
if (!empty($search)) {
    $where_clauses[] = "(b.title LIKE ? OR a.author_name LIKE ? OR b.isbn LIKE ?)";
    $search_param = "%{$search}%";
    $params[] = &$search_param;
    $params[] = &$search_param;
    $params[] = &$search_param;
    $types .= "sss";
}

// PEMILIHAN: Filter genre (ARRAY)
if (!empty($selected_genres) && is_array($selected_genres)) {
    $genre_ids = array_map('intval', $selected_genres);
    $placeholders = implode(',', array_fill(0, count($genre_ids), '?'));
    $where_clauses[] = "b.book_id IN (SELECT book_id FROM book_genres WHERE genre_id IN ($placeholders))";
    foreach ($genre_ids as &$gid) {
        $params[] = &$gid;
        $types .= "i";
    }
    unset($gid);
}

// PEMILIHAN: Filter tahun
if ($year_min > 1900) {
    $where_clauses[] = "b.year_published >= ?";
    $params[] = &$year_min;
    $types .= "i";
}
if ($year_max < date('Y')) {
    $where_clauses[] = "b.year_published <= ?";
    $params[] = &$year_max;
    $types .= "i";
}

// PEMILIHAN: Filter rating
if (!empty($rating_filter) && is_numeric($rating_filter)) {
    $rating_val = intval($rating_filter);
    $where_clauses[] = "b.rating_avg >= ?";
    $params[] = &$rating_val;
    $types .= "i";
}

// PEMILIHAN: Filter ketersediaan
if ($availability === 'available') {
    $where_clauses[] = "b.available_copies > 0";
}

$where_sql = implode(' AND ', $where_clauses);

// SWITCH-CASE: Sorting
switch ($sort) {
    case 'title_asc':
        $order_sql = "b.title ASC";
        break;
    case 'title_desc':
        $order_sql = "b.title DESC";
        break;
    case 'newest':
        $order_sql = "b.created_at DESC";
        break;
    case 'oldest':
        $order_sql = "b.year_published ASC";
        break;
    case 'popular':
        $order_sql = "b.total_borrowed DESC";
        break;
    case 'rating':
        $order_sql = "b.rating_avg DESC";
        break;
    default:
        $order_sql = "b.created_at DESC";
}

// =============================================
// COUNT TOTAL RESULTS (untuk pagination)
// =============================================
$count_sql = "SELECT COUNT(DISTINCT b.book_id) as total 
              FROM books b 
              LEFT JOIN authors a ON b.author_id = a.author_id 
              WHERE $where_sql";

if (!empty($params)) {
    $count_stmt = mysqli_prepare($conn, $count_sql);
    mysqli_stmt_bind_param($count_stmt, $types, ...$params);
    mysqli_stmt_execute($count_stmt);
    $count_result = mysqli_stmt_get_result($count_stmt);
} else {
    $count_result = mysqli_query($conn, $count_sql);
}
$total_books = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_books / ITEMS_PER_PAGE);
$offset = ($page - 1) * ITEMS_PER_PAGE;

// =============================================
// QUERY BUKU DENGAN FILTER
// =============================================
$sql = "SELECT DISTINCT b.*, a.author_name, p.publisher_name
        FROM books b 
        LEFT JOIN authors a ON b.author_id = a.author_id 
        LEFT JOIN publishers p ON b.publisher_id = p.publisher_id
        WHERE $where_sql
        ORDER BY $order_sql
        LIMIT $offset, " . ITEMS_PER_PAGE;

if (!empty($params)) {
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $result = mysqli_query($conn, $sql);
}

// ARRAY MULTIDIMENSI: Simpan buku dengan genre
$books = [];
while ($row = mysqli_fetch_assoc($result)) {
    $row['genres'] = getBookGenres($row['book_id'], $conn);
    $books[] = $row;
}

// Query semua genre untuk filter sidebar
$all_genres = [];
$genre_result = mysqli_query($conn, "SELECT * FROM genres ORDER BY genre_name");
while ($row = mysqli_fetch_assoc($genre_result)) {
    $all_genres[] = $row;
}

include __DIR__ . '/includes/header.php';
?>

<div class="flex flex-1 relative">
    <!-- ==================== SIDEBAR FILTER ==================== -->
    <aside id="filterSidebar" class="w-80 hidden lg:flex flex-col border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-dark h-[calc(100vh-65px)] sticky top-[65px] overflow-y-auto">
        <form method="GET" action="" class="p-6 space-y-7">
            <!-- Search -->
            <div>
                <label class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-2 block font-serif">Pencarian</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400 dark:text-slate-500">
                        <span class="material-symbols-outlined text-xl">search</span>
                    </span>
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                           placeholder="Judul, penulis, ISBN..."
                           class="w-full pl-10 pr-4 py-2.5 bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:ring-2 focus:ring-primary">
                </div>
            </div>

            <!-- Genre Checkboxes -->
            <div>
                <h3 class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-3 font-serif">Genre</h3>
                <div class="space-y-2 max-h-52 overflow-y-auto pr-1">
                    <?php 
                    // FOREACH: Tampilkan checkbox genre
                    foreach ($all_genres as $genre): 
                    ?>
                        <div class="flex items-center">
                            <input type="checkbox" name="genres[]"
                                   id="genre-<?= $genre['genre_id'] ?>"
                                   value="<?= $genre['genre_id'] ?>"
                                   <?= in_array($genre['genre_id'], $selected_genres) ? 'checked' : '' ?>
                                   class="size-4 rounded border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-primary focus:ring-primary">
                            <label for="genre-<?= $genre['genre_id'] ?>"
                                   class="ml-3 text-sm text-slate-700 dark:text-slate-300 hover:text-primary cursor-pointer transition-colors">
                                <?= htmlspecialchars($genre['genre_name']) ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Year Published Range -->
            <div>
                <h3 class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-3 font-serif">Tahun Terbit</h3>
                <div class="flex items-center gap-3">
                    <input type="number" name="year_min" value="<?= $year_min ?>" min="1900" max="<?= date('Y') ?>"
                           placeholder="Dari"
                           class="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:ring-2 focus:ring-primary">
                    <span class="text-slate-400 dark:text-slate-500 text-sm font-medium shrink-0">—</span>
                    <input type="number" name="year_max" value="<?= $year_max ?>" min="1900" max="<?= date('Y') ?>"
                           placeholder="Sampai"
                           class="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:ring-2 focus:ring-primary">
                </div>
            </div>

            <!-- Rating Filter -->
            <div>
                <h3 class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-3 font-serif">Rating Minimal</h3>
                <div class="space-y-2">
                    <label class="flex items-center cursor-pointer group">
                        <input type="radio" name="rating" value="" <?= $rating_filter == '' ? 'checked' : '' ?>
                               class="size-4 rounded-full border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-primary focus:ring-primary">
                        <span class="ml-3 text-sm text-slate-600 dark:text-slate-400 group-hover:text-primary transition-colors">Semua</span>
                    </label>
                    <?php for ($r = 5; $r >= 3; $r--): ?>
                    <label class="flex items-center cursor-pointer group">
                        <input type="radio" name="rating" value="<?= $r ?>" <?= $rating_filter == (string)$r ? 'checked' : '' ?>
                               class="size-4 rounded-full border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-primary focus:ring-primary">
                        <div class="flex text-yellow-500 dark:text-yellow-400 ml-3">
                            <?php for ($s = 1; $s <= 5; $s++): ?>
                                <span class="material-symbols-outlined text-[16px] <?= $s <= $r ? '' : '!text-slate-300 dark:!text-slate-600' ?>"
                                      <?= $s <= $r ? 'style="font-variation-settings:\'FILL\' 1"' : '' ?>>star</span>
                            <?php endfor; ?>
                        </div>
                        <span class="text-xs text-slate-500 ml-2 group-hover:text-primary transition-colors"><?= $r < 5 ? '& up' : 'only' ?></span>
                    </label>
                    <?php endfor; ?>
                </div>
            </div>

            <!-- Availability Toggle -->
            <div class="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-700">
                <span class="text-sm font-medium text-slate-900 dark:text-slate-200">Tersedia saja</span>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" name="availability" value="available"
                           <?= $availability === 'available' ? 'checked' : '' ?>
                           class="sr-only peer">
                    <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary/50 dark:peer-focus:ring-primary/30 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-primary"></div>
                </label>
            </div>

            <!-- Sort -->
            <div>
                <h3 class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-2 font-serif">Urutkan</h3>
                <div class="relative">
                    <select name="sort"
                            class="appearance-none w-full bg-slate-100 dark:bg-slate-800 border-none text-slate-700 dark:text-slate-200 text-sm rounded-lg focus:ring-2 focus:ring-primary block p-2.5 pr-8 cursor-pointer">
                        <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Terbaru</option>
                        <option value="title_asc" <?= $sort === 'title_asc' ? 'selected' : '' ?>>Judul (A-Z)</option>
                        <option value="title_desc" <?= $sort === 'title_desc' ? 'selected' : '' ?>>Judul (Z-A)</option>
                        <option value="popular" <?= $sort === 'popular' ? 'selected' : '' ?>>Terpopuler</option>
                        <option value="rating" <?= $sort === 'rating' ? 'selected' : '' ?>>Rating Tertinggi</option>
                        <option value="oldest" <?= $sort === 'oldest' ? 'selected' : '' ?>>Terlama</option>
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                        <span class="material-symbols-outlined text-base">expand_more</span>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="space-y-2 pt-2">
                <button type="submit"
                        class="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-white text-sm font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-sm">
                    <span class="material-symbols-outlined text-[18px]">filter_list</span>
                    Terapkan Filter
                </button>
                <a href="<?= BASE_URL ?>catalog.php"
                   class="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 text-sm font-medium rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                    <span class="material-symbols-outlined text-[18px]">restart_alt</span>
                    Reset Filter
                </a>
            </div>
        </form>
    </aside>

    <!-- ==================== MAIN CONTENT ==================== -->
    <main class="flex-1 p-6 lg:p-10">
        <!-- Result Header -->
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
                <h1 class="text-3xl font-bold text-slate-900 dark:text-accent-cream font-serif mb-1">
                    <span class="material-symbols-outlined text-primary align-middle mr-1" style="font-size:32px">auto_stories</span>
                    Katalog Novel
                </h1>
                <p class="text-slate-500 dark:text-slate-400 text-sm">
                    Menampilkan <?= ($offset + 1) ?>–<?= min($offset + ITEMS_PER_PAGE, $total_books) ?> dari <?= $total_books ?> novel
                </p>
            </div>
            <!-- Mobile Filter Toggle -->
            <button onclick="toggleMobileFilter()"
                    class="lg:hidden flex items-center gap-2 px-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                <span class="material-symbols-outlined text-[18px]">filter_list</span>
                Filter
            </button>
        </div>

        <!-- Flash Messages -->
        <div class="mb-6">
            <?php showFlash(); ?>
        </div>

        <!-- Mobile Filter Panel (overlay) -->
        <div id="mobileFilterOverlay" class="fixed inset-0 z-50 lg:hidden hidden">
            <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" onclick="toggleMobileFilter()"></div>
            <div class="absolute left-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white dark:bg-navy-dark overflow-y-auto shadow-2xl transform transition-transform duration-300">
                <div class="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-accent-cream font-serif">Filter</h3>
                    <button onclick="toggleMobileFilter()" class="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700">
                        <span class="material-symbols-outlined">close</span>
                    </button>
                </div>
                <form method="GET" action="" class="p-6 space-y-6">
                    <!-- Mobile Search -->
                    <div>
                        <label class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-2 block font-serif">Pencarian</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400"><span class="material-symbols-outlined text-xl">search</span></span>
                            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Judul, penulis, ISBN..."
                                   class="w-full pl-10 pr-4 py-2.5 bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm text-slate-900 dark:text-white placeholder-slate-500 focus:ring-2 focus:ring-primary">
                        </div>
                    </div>
                    <!-- Mobile Genre -->
                    <div>
                        <label class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-2 block font-serif">Genre</label>
                        <div class="space-y-2 max-h-40 overflow-y-auto">
                            <?php foreach ($all_genres as $genre): ?>
                            <div class="flex items-center">
                                <input type="checkbox" name="genres[]" id="m-genre-<?= $genre['genre_id'] ?>" value="<?= $genre['genre_id'] ?>"
                                       <?= in_array($genre['genre_id'], $selected_genres) ? 'checked' : '' ?>
                                       class="size-4 rounded border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-primary focus:ring-primary">
                                <label for="m-genre-<?= $genre['genre_id'] ?>" class="ml-3 text-sm text-slate-700 dark:text-slate-300 cursor-pointer"><?= htmlspecialchars($genre['genre_name']) ?></label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <!-- Mobile Rating -->
                    <div>
                        <label class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-2 block font-serif">Rating Minimal</label>
                        <select name="rating" class="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm text-slate-700 dark:text-slate-200 p-2.5 focus:ring-2 focus:ring-primary">
                            <option value="">Semua</option>
                            <option value="5" <?= $rating_filter == '5' ? 'selected' : '' ?>>5★</option>
                            <option value="4" <?= $rating_filter == '4' ? 'selected' : '' ?>>4★+</option>
                            <option value="3" <?= $rating_filter == '3' ? 'selected' : '' ?>>3★+</option>
                        </select>
                    </div>
                    <!-- Mobile Availability -->
                    <div>
                        <label class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-2 block font-serif">Ketersediaan</label>
                        <select name="availability" class="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm text-slate-700 dark:text-slate-200 p-2.5 focus:ring-2 focus:ring-primary">
                            <option value="">Semua</option>
                            <option value="available" <?= $availability === 'available' ? 'selected' : '' ?>>Tersedia saja</option>
                        </select>
                    </div>
                    <!-- Mobile Sort -->
                    <div>
                        <label class="text-sm font-semibold text-slate-900 dark:text-accent-cream mb-2 block font-serif">Urutkan</label>
                        <select name="sort" class="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm text-slate-700 dark:text-slate-200 p-2.5 focus:ring-2 focus:ring-primary">
                            <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Terbaru</option>
                            <option value="title_asc" <?= $sort === 'title_asc' ? 'selected' : '' ?>>Judul (A-Z)</option>
                            <option value="title_desc" <?= $sort === 'title_desc' ? 'selected' : '' ?>>Judul (Z-A)</option>
                            <option value="popular" <?= $sort === 'popular' ? 'selected' : '' ?>>Terpopuler</option>
                            <option value="rating" <?= $sort === 'rating' ? 'selected' : '' ?>>Rating Tertinggi</option>
                            <option value="oldest" <?= $sort === 'oldest' ? 'selected' : '' ?>>Terlama</option>
                        </select>
                    </div>
                    <!-- Mobile Actions -->
                    <div class="space-y-2">
                        <button type="submit" class="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-white text-sm font-semibold rounded-lg hover:bg-blue-700 transition-colors">
                            <span class="material-symbols-outlined text-[18px]">filter_list</span>
                            Terapkan Filter
                        </button>
                        <a href="<?= BASE_URL ?>catalog.php"
                           class="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 text-sm font-medium rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                            <span class="material-symbols-outlined text-[18px]">restart_alt</span>
                            Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <?php if (empty($books)): ?>
            <!-- Empty State -->
            <div class="flex flex-col items-center justify-center py-20">
                <div class="w-24 h-24 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-6">
                    <span class="material-symbols-outlined text-slate-400 dark:text-slate-500" style="font-size:48px">search_off</span>
                </div>
                <h3 class="text-xl font-bold text-slate-900 dark:text-accent-cream font-serif mb-2">Tidak ada novel ditemukan</h3>
                <p class="text-slate-500 dark:text-slate-400 text-sm mb-6">Coba ubah filter pencarian Anda</p>
                <a href="<?= BASE_URL ?>catalog.php"
                   class="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-white text-sm font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-sm">
                    <span class="material-symbols-outlined text-[18px]">restart_alt</span>
                    Reset Filter
                </a>
            </div>
        <?php else: ?>
            <!-- ==================== BOOK GRID ==================== -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
                <?php 
                // PERULANGAN (FOREACH): Tampilkan setiap buku
                foreach ($books as $book): 
                ?>
                    <article class="group bg-white dark:bg-navy-dark rounded-xl overflow-hidden shadow-sm hover:shadow-xl dark:shadow-none dark:hover:bg-[#253346] transition-all duration-300 flex flex-col border border-slate-200 dark:border-slate-700/50">
                        <!-- Cover Image -->
                        <div class="relative aspect-[2/3] overflow-hidden bg-slate-100 dark:bg-slate-800">
                            <?php $cover_url = getBookCoverUrl($book['cover_image']); ?>
                            <?php if ($cover_url): ?>
                                <img src="<?= htmlspecialchars($cover_url) ?>"
                                     alt="<?= htmlspecialchars($book['title']) ?>"
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                     loading="lazy">
                            <?php else: ?>
                                <div class="w-full h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 p-4">
                                    <span class="material-symbols-outlined mb-2" style="font-size:56px">menu_book</span>
                                    <span class="text-xs text-center leading-tight font-medium"><?= htmlspecialchars(mb_strimwidth($book['title'], 0, 40, '…')) ?></span>
                                </div>
                            <?php endif; ?>

                            <!-- Availability Badge -->
                            <div class="absolute top-3 right-3">
                                <?php if ($book['available_copies'] > 0): ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 border border-green-200 dark:border-green-800 shadow-sm backdrop-blur-sm">
                                        Tersedia
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-burgundy dark:text-white border border-red-200 dark:border-red-900 shadow-sm backdrop-blur-sm">
                                        Dipinjam
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Card Body -->
                        <div class="p-5 flex flex-col flex-1">
                            <!-- Genre Badges + Rating -->
                            <div class="flex items-center gap-1.5 mb-2 flex-wrap">
                                <?php 
                                // FOREACH BERSARANG: Genre badges (limit 2 for space)
                                $shown_genres = array_slice($book['genres'], 0, 2);
                                foreach ($shown_genres as $genre): 
                                ?>
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wide <?= getGenreBadgeClass($genre['genre_name']) ?>">
                                        <?= htmlspecialchars($genre['genre_name']) ?>
                                    </span>
                                <?php endforeach; ?>
                                <?php if (count($book['genres']) > 2): ?>
                                    <span class="text-[10px] text-slate-400 dark:text-slate-500 font-medium">+<?= count($book['genres']) - 2 ?></span>
                                <?php endif; ?>

                                <span class="flex items-center text-yellow-500 dark:text-yellow-400 text-xs font-bold gap-0.5 ml-auto shrink-0">
                                    <span class="material-symbols-outlined text-[16px]" style="font-variation-settings:'FILL' 1">star</span>
                                    <?= number_format($book['rating_avg'], 1) ?>
                                </span>
                            </div>

                            <!-- Title -->
                            <h3 class="text-lg font-bold text-slate-900 dark:text-accent-cream font-serif leading-tight mb-1 truncate"
                                title="<?= htmlspecialchars($book['title']) ?>">
                                <?= htmlspecialchars($book['title']) ?>
                            </h3>

                            <!-- Author -->
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-1 truncate">
                                <?= htmlspecialchars($book['author_name'] ?? 'Unknown') ?>
                            </p>

                            <!-- Year & Pages -->
                            <p class="text-xs text-slate-400 dark:text-slate-500 mb-4">
                                <?= $book['year_published'] ?> · <?= $book['pages'] ?> hal
                            </p>

                            <!-- Action Buttons -->
                            <div class="mt-auto grid grid-cols-2 gap-3 pt-4 border-t border-slate-100 dark:border-slate-700/50">
                                <a href="<?= BASE_URL ?>book_detail.php?id=<?= $book['book_id'] ?>"
                                   class="flex items-center justify-center gap-1 px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                                    <span class="material-symbols-outlined text-[14px]">visibility</span>
                                    Detail
                                </a>
                                <?php if ($book['available_copies'] > 0 && isLoggedIn() && isMember()): ?>
                                    <form method="POST" action="<?= BASE_URL ?>borrow_book.php">
                                        <input type="hidden" name="book_id" value="<?= $book['book_id'] ?>">
                                        <button type="submit"
                                                class="w-full flex items-center justify-center gap-1 px-3 py-2 bg-primary text-white rounded-lg text-xs font-semibold hover:bg-blue-700 transition-colors shadow-sm">
                                            <span class="material-symbols-outlined text-[14px]">bookmark_add</span>
                                            Pinjam
                                        </button>
                                    </form>
                                <?php elseif ($book['available_copies'] <= 0): ?>
                                    <button disabled
                                            class="flex items-center justify-center px-3 py-2 bg-slate-200 dark:bg-slate-700 text-slate-400 dark:text-slate-500 rounded-lg text-xs font-semibold cursor-not-allowed">
                                        Habis
                                    </button>
                                <?php else: ?>
                                    <a href="<?= BASE_URL ?>auth/login.php"
                                       class="flex items-center justify-center gap-1 px-3 py-2 bg-primary/80 text-white rounded-lg text-xs font-semibold hover:bg-primary transition-colors">
                                        <span class="material-symbols-outlined text-[14px]">login</span>
                                        Login
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>

            <!-- ==================== PAGINATION ==================== -->
            <?php if ($total_pages > 1): ?>
                <div class="flex items-center justify-center gap-2 flex-wrap">
                    <!-- Previous -->
                    <?php if ($page > 1): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>"
                           class="flex items-center justify-center px-3 h-9 text-sm font-medium text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-white transition-colors">
                            <span class="material-symbols-outlined text-sm mr-1">chevron_left</span>
                            Prev
                        </a>
                    <?php else: ?>
                        <span class="flex items-center justify-center px-3 h-9 text-sm font-medium text-slate-300 dark:text-slate-600 bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg cursor-not-allowed select-none">
                            <span class="material-symbols-outlined text-sm mr-1">chevron_left</span>
                            Prev
                        </span>
                    <?php endif; ?>

                    <!-- Page Numbers -->
                    <?php
                    $range = 2;
                    $start_page = max(1, $page - $range);
                    $end_page = min($total_pages, $page + $range);

                    if ($start_page > 1): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => 1])) ?>"
                           class="flex items-center justify-center px-3 h-9 text-sm font-medium text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-white transition-colors">1</a>
                        <?php if ($start_page > 2): ?>
                            <span class="px-1 text-slate-400 dark:text-slate-500 select-none">…</span>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="flex items-center justify-center px-3 h-9 text-sm font-medium text-white bg-primary border border-primary rounded-lg shadow-sm">
                                <?= $i ?>
                            </span>
                        <?php else: ?>
                            <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"
                               class="flex items-center justify-center px-3 h-9 text-sm font-medium text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-white transition-colors">
                                <?= $i ?>
                            </a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if ($end_page < $total_pages): ?>
                        <?php if ($end_page < $total_pages - 1): ?>
                            <span class="px-1 text-slate-400 dark:text-slate-500 select-none">…</span>
                        <?php endif; ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $total_pages])) ?>"
                           class="flex items-center justify-center px-3 h-9 text-sm font-medium text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-white transition-colors"><?= $total_pages ?></a>
                    <?php endif; ?>

                    <!-- Next -->
                    <?php if ($page < $total_pages): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>"
                           class="flex items-center justify-center px-3 h-9 text-sm font-medium text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-white transition-colors">
                            Next
                            <span class="material-symbols-outlined text-sm ml-1">chevron_right</span>
                        </a>
                    <?php else: ?>
                        <span class="flex items-center justify-center px-3 h-9 text-sm font-medium text-slate-300 dark:text-slate-600 bg-white dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg cursor-not-allowed select-none">
                            Next
                            <span class="material-symbols-outlined text-sm ml-1">chevron_right</span>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
</div>

<!-- Mobile filter toggle script -->
<script>
function toggleMobileFilter() {
    const overlay = document.getElementById('mobileFilterOverlay');
    overlay.classList.toggle('hidden');
    document.body.classList.toggle('overflow-hidden');
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
