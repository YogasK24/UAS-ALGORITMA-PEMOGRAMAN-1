<?php
/**
 * Homepage - BookHaven Digital Library
 * Halaman utama perpustakaan digital
 * ALGORITMA: FOREACH (display buku), ARRAY MULTIDIMENSI (data buku)
 */
require_once __DIR__ . '/includes/functions.php';

$page_title = 'Beranda';

// Query buku terbaru (ARRAY MULTIDIMENSI)
$sql_new = "SELECT b.*, a.author_name FROM books b 
            LEFT JOIN authors a ON b.author_id = a.author_id 
            WHERE b.is_active = 1 
            ORDER BY b.created_at DESC LIMIT 8";
$result_new = mysqli_query($conn, $sql_new);
$new_books = [];
while ($row = mysqli_fetch_assoc($result_new)) {
    $row['genres'] = getBookGenres($row['book_id'], $conn);
    $new_books[] = $row;
}

// Query buku populer
$sql_popular = "SELECT b.*, a.author_name FROM books b 
                LEFT JOIN authors a ON b.author_id = a.author_id 
                WHERE b.is_active = 1 
                ORDER BY b.total_borrowed DESC, b.rating_avg DESC LIMIT 8";
$result_popular = mysqli_query($conn, $sql_popular);
$popular_books = [];
while ($row = mysqli_fetch_assoc($result_popular)) {
    $row['genres'] = getBookGenres($row['book_id'], $conn);
    $popular_books[] = $row;
}

// Statistik
$stats = [];
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM books WHERE is_active = 1");
$stats['total_books'] = mysqli_fetch_assoc($result)['count'];
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'member'");
$stats['total_members'] = mysqli_fetch_assoc($result)['count'];
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM authors");
$stats['total_authors'] = mysqli_fetch_assoc($result)['count'];
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM genres");
$stats['total_genres'] = mysqli_fetch_assoc($result)['count'];

include __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="relative overflow-hidden bg-gradient-to-br from-[#2C3E50] via-[#1e293b] to-[#8B0000]">
    <!-- Decorative elements -->
    <div class="absolute inset-0">
        <div class="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
        <div class="absolute bottom-0 left-0 w-80 h-80 bg-burgundy/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/4"></div>
        <div class="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2230%22%20height%3D%2230%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cdefs%3E%3Cpattern%20id%3D%22g%22%20width%3D%2230%22%20height%3D%2230%22%20patternUnits%3D%22userSpaceOnUse%22%3E%3Ccircle%20cx%3D%2215%22%20cy%3D%2215%22%20r%3D%221%22%20fill%3D%22rgba(255%2C255%2C255%2C0.05)%22%2F%3E%3C%2Fpattern%3E%3C%2Fdefs%3E%3Crect%20fill%3D%22url(%23g)%22%20width%3D%22100%25%22%20height%3D%22100%25%22%2F%3E%3C%2Fsvg%3E')] opacity-60"></div>
    </div>

    <div class="relative max-w-7xl mx-auto px-6 lg:px-10 py-20 lg:py-28">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <!-- Left content -->
            <div class="text-center lg:text-left">
                <div class="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/10 rounded-full px-4 py-1.5 mb-6">
                    <span class="material-symbols-outlined text-yellow-400 !text-[18px]" style="font-variation-settings:'FILL' 1">auto_awesome</span>
                    <span class="text-sm text-white/80 font-medium">Perpustakaan Digital Terbaik</span>
                </div>
                <h1 class="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-white leading-tight mb-6">
                    Jelajahi Dunia <br class="hidden sm:block">
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 to-cyan-300">Novel Digital</span>
                </h1>
                <p class="text-lg text-slate-300 leading-relaxed max-w-xl mx-auto lg:mx-0 mb-8">
                    Temukan ribuan novel dari berbagai genre. Pinjam, baca, dan nikmati pengalaman membaca digital terbaik dengan <?= SITE_NAME ?>.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                    <a href="<?= BASE_URL ?>catalog.php" 
                       class="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white font-semibold px-8 py-3.5 rounded-xl shadow-lg shadow-primary/25 transition-all duration-200 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5">
                        <span class="material-symbols-outlined !text-[20px]">grid_view</span>
                        Jelajahi Katalog
                    </a>
                    <?php if (!isLoggedIn()): ?>
                        <a href="<?= BASE_URL ?>auth/register.php" 
                           class="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white font-semibold px-8 py-3.5 rounded-xl border border-white/20 transition-all duration-200 hover:-translate-y-0.5">
                            <span class="material-symbols-outlined !text-[20px]">person_add</span>
                            Daftar Gratis
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right decorative illustration -->
            <div class="hidden lg:flex items-center justify-center">
                <div class="relative">
                    <div class="absolute inset-0 bg-gradient-to-br from-primary/20 to-burgundy/20 rounded-full blur-2xl scale-110"></div>
                    <div class="relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl p-12">
                        <span class="material-symbols-outlined text-white/20" style="font-size: 12rem; font-variation-settings:'FILL' 1">menu_book</span>
                        <div class="absolute top-6 right-6 bg-primary/80 backdrop-blur-sm rounded-xl px-3 py-2 flex items-center gap-2">
                            <span class="material-symbols-outlined text-white !text-[18px]">library_books</span>
                            <span class="text-white text-sm font-semibold"><?= number_format($stats['total_books']) ?>+ Novel</span>
                        </div>
                        <div class="absolute bottom-6 left-6 bg-emerald-600/80 backdrop-blur-sm rounded-xl px-3 py-2 flex items-center gap-2">
                            <span class="material-symbols-outlined text-white !text-[18px]">group</span>
                            <span class="text-white text-sm font-semibold"><?= number_format($stats['total_members']) ?> Member</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Wave separator -->
    <div class="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full">
            <path d="M0 60L48 55C96 50 192 40 288 35C384 30 480 30 576 33.3C672 36.7 768 43.3 864 45C960 46.7 1056 43.3 1152 40C1248 36.7 1344 33.3 1392 31.7L1440 30V60H1392C1344 60 1248 60 1152 60C1056 60 960 60 864 60C768 60 672 60 576 60C480 60 384 60 288 60C192 60 96 60 48 60H0Z" fill="#111921"/>
        </svg>
    </div>
</section>

<!-- Statistics Bar -->
<section class="relative z-10 -mt-1 bg-white dark:bg-[#111921]">
    <div class="max-w-7xl mx-auto px-6 lg:px-10 py-10">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 lg:gap-6">
            <!-- Koleksi Novel -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 text-center group hover:border-primary/50 dark:hover:border-primary/50 transition-colors duration-200">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-primary mb-3 group-hover:scale-110 transition-transform">
                    <span class="material-symbols-outlined !text-[24px]">auto_stories</span>
                </div>
                <h3 class="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white"><?= number_format($stats['total_books']) ?></h3>
                <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Koleksi Novel</p>
            </div>

            <!-- Member Aktif -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 text-center group hover:border-burgundy/50 dark:hover:border-burgundy/50 transition-colors duration-200">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-red-100 dark:bg-red-900/30 text-burgundy mb-3 group-hover:scale-110 transition-transform">
                    <span class="material-symbols-outlined !text-[24px]">group</span>
                </div>
                <h3 class="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white"><?= number_format($stats['total_members']) ?></h3>
                <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Member Aktif</p>
            </div>

            <!-- Penulis -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 text-center group hover:border-primary/50 dark:hover:border-primary/50 transition-colors duration-200">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-primary mb-3 group-hover:scale-110 transition-transform">
                    <span class="material-symbols-outlined !text-[24px]">edit_note</span>
                </div>
                <h3 class="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white"><?= number_format($stats['total_authors']) ?></h3>
                <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Penulis</p>
            </div>

            <!-- Genre -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 text-center group hover:border-burgundy/50 dark:hover:border-burgundy/50 transition-colors duration-200">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-red-100 dark:bg-red-900/30 text-burgundy mb-3 group-hover:scale-110 transition-transform">
                    <span class="material-symbols-outlined !text-[24px]">label</span>
                </div>
                <h3 class="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white"><?= number_format($stats['total_genres']) ?></h3>
                <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Genre</p>
            </div>
        </div>
    </div>
</section>

<!-- Buku Terbaru -->
<section class="bg-white dark:bg-[#111921] py-12 lg:py-16">
    <div class="max-w-7xl mx-auto px-6 lg:px-10">
        <!-- Section header -->
        <div class="flex items-center justify-between mb-8">
            <div class="flex items-center gap-3">
                <div class="flex items-center justify-center w-10 h-10 rounded-xl bg-yellow-100 dark:bg-yellow-900/30">
                    <span class="material-symbols-outlined text-yellow-500 !text-[22px]" style="font-variation-settings:'FILL' 1">auto_awesome</span>
                </div>
                <h2 class="text-2xl lg:text-3xl font-serif font-bold text-slate-900 dark:text-white">Novel Terbaru</h2>
            </div>
            <a href="<?= BASE_URL ?>catalog.php?sort=newest" 
               class="hidden sm:inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
                Lihat Semua
                <span class="material-symbols-outlined !text-[18px]">arrow_forward</span>
            </a>
        </div>

        <!-- Book grid -->
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
            <?php 
            // PERULANGAN (FOREACH): Tampilkan setiap buku terbaru
            foreach ($new_books as $book): 
            ?>
                <div class="group">
                    <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden h-full flex flex-col hover:shadow-md hover:border-primary/30 dark:hover:border-primary/30 transition-all duration-200">
                        <!-- Cover area -->
                        <div class="relative aspect-[2/3] overflow-hidden">
                            <?php $cover_url = getBookCoverUrl($book['cover_image']); ?>
                            <?php if ($cover_url): ?>
                                <img src="<?= htmlspecialchars($cover_url) ?>" 
                                     alt="<?= htmlspecialchars($book['title']) ?>" 
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                     loading="lazy" onerror="this.parentElement.innerHTML='<div class=\'w-full h-full bg-gradient-to-br from-navy via-[#1e293b] to-burgundy flex flex-col items-center justify-center p-4 text-center\'><span class=\'material-symbols-outlined text-white/20 mb-3\' style=\'font-size:4rem;font-variation-settings:FILL 1\'>menu_book</span></div>'">
                            <?php else: ?>
                                <div class="w-full h-full bg-gradient-to-br from-navy via-[#1e293b] to-burgundy flex flex-col items-center justify-center p-4 text-center">
                                    <span class="material-symbols-outlined text-white/20 mb-3" style="font-size: 4rem; font-variation-settings:'FILL' 1">menu_book</span>
                                    <p class="text-white/60 text-xs font-medium leading-tight line-clamp-3"><?= htmlspecialchars($book['title']) ?></p>
                                </div>
                            <?php endif; ?>

                            <!-- Availability badge -->
                            <?php if ($book['available_copies'] > 0): ?>
                                <span class="absolute top-2 right-2 inline-flex items-center gap-1 bg-emerald-500/90 backdrop-blur-sm text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                                    <span class="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
                                    Tersedia
                                </span>
                            <?php else: ?>
                                <span class="absolute top-2 right-2 inline-flex items-center gap-1 bg-red-500/90 backdrop-blur-sm text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                                    Dipinjam
                                </span>
                            <?php endif; ?>
                        </div>

                        <!-- Card body -->
                        <div class="flex flex-col flex-1 p-4">
                            <h3 class="text-sm font-bold text-slate-900 dark:text-white leading-snug line-clamp-2 mb-1">
                                <?= htmlspecialchars($book['title']) ?>
                            </h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mb-2.5 truncate">
                                <?= htmlspecialchars($book['author_name'] ?? 'Unknown') ?>
                            </p>

                            <!-- Genre badges -->
                            <div class="flex flex-wrap gap-1 mb-3">
                                <?php 
                                // FOREACH BERSARANG: Tampilkan genre badges per buku
                                foreach ($book['genres'] as $genre): 
                                ?>
                                    <span class="inline-block text-[10px] font-medium px-2 py-0.5 rounded-full <?= getGenreBadgeClass($genre['genre_name']) ?>">
                                        <?= $genre['genre_name'] ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>

                            <!-- Rating -->
                            <div class="flex items-center gap-1.5 mt-auto mb-3">
                                <?= ratingStars($book['rating_avg']) ?>
                                <span class="text-[11px] text-slate-400 dark:text-slate-500">(<?= $book['total_reviews'] ?>)</span>
                            </div>

                            <!-- Detail button -->
                            <a href="<?= BASE_URL ?>book_detail.php?id=<?= $book['book_id'] ?>" 
                               class="inline-flex items-center justify-center gap-1.5 w-full text-sm font-medium text-primary border border-primary/30 hover:bg-primary hover:text-white rounded-lg px-3 py-2 transition-all duration-200">
                                <span class="material-symbols-outlined !text-[16px]">visibility</span>
                                Detail
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Mobile view all link -->
        <div class="flex justify-center mt-6 sm:hidden">
            <a href="<?= BASE_URL ?>catalog.php?sort=newest" 
               class="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
                Lihat Semua Novel Terbaru
                <span class="material-symbols-outlined !text-[18px]">arrow_forward</span>
            </a>
        </div>
    </div>
</section>

<!-- Buku Populer -->
<section class="bg-slate-50 dark:bg-[#0d1117] py-12 lg:py-16 border-y border-slate-200 dark:border-slate-800">
    <div class="max-w-7xl mx-auto px-6 lg:px-10">
        <!-- Section header -->
        <div class="flex items-center justify-between mb-8">
            <div class="flex items-center gap-3">
                <div class="flex items-center justify-center w-10 h-10 rounded-xl bg-red-100 dark:bg-red-900/30">
                    <span class="material-symbols-outlined text-accent-red !text-[22px]" style="font-variation-settings:'FILL' 1">local_fire_department</span>
                </div>
                <h2 class="text-2xl lg:text-3xl font-serif font-bold text-slate-900 dark:text-white">Novel Populer</h2>
            </div>
            <a href="<?= BASE_URL ?>catalog.php?sort=popular" 
               class="hidden sm:inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
                Lihat Semua
                <span class="material-symbols-outlined !text-[18px]">arrow_forward</span>
            </a>
        </div>

        <!-- Book grid -->
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
            <?php foreach ($popular_books as $book): ?>
                <div class="group">
                    <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden h-full flex flex-col hover:shadow-md hover:border-primary/30 dark:hover:border-primary/30 transition-all duration-200">
                        <!-- Cover area -->
                        <div class="relative aspect-[2/3] overflow-hidden">
                            <?php $cover_url = getBookCoverUrl($book['cover_image']); ?>
                            <?php if ($cover_url): ?>
                                <img src="<?= htmlspecialchars($cover_url) ?>" 
                                     alt="<?= htmlspecialchars($book['title']) ?>" 
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                     loading="lazy">
                            <?php else: ?>
                                <div class="w-full h-full bg-gradient-to-br from-burgundy via-[#1e293b] to-navy flex flex-col items-center justify-center p-4 text-center">
                                    <span class="material-symbols-outlined text-white/20 mb-3" style="font-size: 4rem; font-variation-settings:'FILL' 1">menu_book</span>
                                    <p class="text-white/60 text-xs font-medium leading-tight line-clamp-3"><?= htmlspecialchars($book['title']) ?></p>
                                </div>
                            <?php endif; ?>

                            <!-- Availability badge -->
                            <?php if ($book['available_copies'] > 0): ?>
                                <span class="absolute top-2 right-2 inline-flex items-center gap-1 bg-emerald-500/90 backdrop-blur-sm text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                                    <span class="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
                                    Tersedia
                                </span>
                            <?php else: ?>
                                <span class="absolute top-2 right-2 inline-flex items-center gap-1 bg-red-500/90 backdrop-blur-sm text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                                    Dipinjam
                                </span>
                            <?php endif; ?>

                            <!-- Popular badge -->
                            <span class="absolute top-2 left-2 inline-flex items-center gap-1 bg-amber-500/90 backdrop-blur-sm text-white text-[11px] font-semibold px-2.5 py-1 rounded-full">
                                <span class="material-symbols-outlined !text-[14px]" style="font-variation-settings:'FILL' 1">trending_up</span>
                                <?= $book['total_borrowed'] ?>x
                            </span>
                        </div>

                        <!-- Card body -->
                        <div class="flex flex-col flex-1 p-4">
                            <h3 class="text-sm font-bold text-slate-900 dark:text-white leading-snug line-clamp-2 mb-1">
                                <?= htmlspecialchars($book['title']) ?>
                            </h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mb-2.5 truncate">
                                <?= htmlspecialchars($book['author_name'] ?? 'Unknown') ?>
                            </p>

                            <!-- Genre badges -->
                            <div class="flex flex-wrap gap-1 mb-3">
                                <?php foreach ($book['genres'] as $genre): ?>
                                    <span class="inline-block text-[10px] font-medium px-2 py-0.5 rounded-full <?= getGenreBadgeClass($genre['genre_name']) ?>">
                                        <?= $genre['genre_name'] ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>

                            <!-- Rating -->
                            <div class="flex items-center gap-1.5 mt-auto mb-3">
                                <?= ratingStars($book['rating_avg']) ?>
                                <span class="text-[11px] text-slate-400 dark:text-slate-500">(<?= $book['total_reviews'] ?>)</span>
                            </div>

                            <!-- Detail button -->
                            <a href="<?= BASE_URL ?>book_detail.php?id=<?= $book['book_id'] ?>" 
                               class="inline-flex items-center justify-center gap-1.5 w-full text-sm font-medium text-primary border border-primary/30 hover:bg-primary hover:text-white rounded-lg px-3 py-2 transition-all duration-200">
                                <span class="material-symbols-outlined !text-[16px]">visibility</span>
                                Detail
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Mobile view all link -->
        <div class="flex justify-center mt-6 sm:hidden">
            <a href="<?= BASE_URL ?>catalog.php?sort=popular" 
               class="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
                Lihat Semua Novel Populer
                <span class="material-symbols-outlined !text-[18px]">arrow_forward</span>
            </a>
        </div>
    </div>
</section>

<!-- Membership Tier Section -->
<section class="bg-white dark:bg-[#111921] py-12 lg:py-16">
    <div class="max-w-7xl mx-auto px-6 lg:px-10">
        <!-- Section header -->
        <div class="text-center mb-10">
            <div class="inline-flex items-center gap-2 bg-amber-100 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 rounded-full px-4 py-1.5 mb-4">
                <span class="material-symbols-outlined !text-[18px]" style="font-variation-settings:'FILL' 1">workspace_premium</span>
                <span class="text-sm font-medium">Membership</span>
            </div>
            <h2 class="text-2xl lg:text-3xl font-serif font-bold text-slate-900 dark:text-white mb-3">Pilih Membership Anda</h2>
            <p class="text-slate-500 dark:text-slate-400 max-w-lg mx-auto">Nikmati lebih banyak benefit dengan upgrade membership</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6">
            <?php
            // Query semua tier
            $tiers = [];
            $result = mysqli_query($conn, "SELECT * FROM membership_tiers ORDER BY tier_id");
            while ($row = mysqli_fetch_assoc($result)) {
                $tiers[] = $row;
            }
            
            // FOREACH: Tampilkan setiap tier
            $tier_colors = ['Free' => 'secondary', 'Silver' => 'info', 'Gold' => 'warning', 'Premium' => 'danger'];

            // Tailwind color maps for tiers
            $tier_tw_accent = [
                'Free'    => 'slate',
                'Silver'  => 'sky',
                'Gold'    => 'amber',
                'Premium' => 'rose',
            ];
            $tier_tw_icon = [
                'Free'    => 'kid_star',
                'Silver'  => 'military_tech',
                'Gold'    => 'emoji_events',
                'Premium' => 'diamond',
            ];

            foreach ($tiers as $tier):
                $color = $tier_colors[$tier['tier_name']] ?? 'primary';
                $is_popular = ($tier['tier_name'] === 'Gold');
                $tw = $tier_tw_accent[$tier['tier_name']] ?? 'blue';
                $icon = $tier_tw_icon[$tier['tier_name']] ?? 'workspace_premium';
            ?>
                <div class="relative flex">
                    <?php if ($is_popular): ?>
                        <div class="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                            <span class="inline-flex items-center gap-1 bg-amber-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg shadow-amber-500/25">
                                <span class="material-symbols-outlined !text-[14px]" style="font-variation-settings:'FILL' 1">star</span>
                                Populer
                            </span>
                        </div>
                    <?php endif; ?>

                    <div class="bg-white dark:bg-[#1e293b] rounded-xl border-2 <?= $is_popular ? 'border-amber-400 dark:border-amber-500 shadow-lg shadow-amber-500/10' : 'border-gray-200 dark:border-gray-700 shadow-sm' ?> flex flex-col w-full overflow-hidden hover:shadow-md transition-shadow duration-200">
                        <!-- Tier header -->
                        <div class="p-6 pb-4 text-center">
                            <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-<?= $tw ?>-100 dark:bg-<?= $tw ?>-900/30 mb-4">
                                <span class="material-symbols-outlined text-<?= $tw ?>-500 dark:text-<?= $tw ?>-400 !text-[28px]" style="font-variation-settings:'FILL' 1"><?= $icon ?></span>
                            </div>
                            <span class="inline-block text-xs font-bold uppercase tracking-wider text-<?= $tw ?>-600 dark:text-<?= $tw ?>-400 bg-<?= $tw ?>-100 dark:bg-<?= $tw ?>-900/30 px-3 py-1 rounded-full mb-3">
                                <?= $tier['tier_name'] ?>
                            </span>
                            <div class="mt-2">
                                <span class="text-3xl font-bold text-slate-900 dark:text-white">
                                    <?= $tier['monthly_fee'] > 0 ? formatRupiah($tier['monthly_fee']) : 'Gratis' ?>
                                </span>
                                <?php if ($tier['monthly_fee'] > 0): ?>
                                    <span class="text-sm text-slate-400 dark:text-slate-500">/bulan</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Divider -->
                        <div class="mx-6 border-t border-slate-200 dark:border-slate-600/50"></div>

                        <!-- Features -->
                        <div class="p-6 flex-1">
                            <ul class="space-y-3">
                                <li class="flex items-start gap-2.5">
                                    <span class="material-symbols-outlined text-emerald-500 !text-[20px] mt-0.5" style="font-variation-settings:'FILL' 1">check_circle</span>
                                    <span class="text-sm text-slate-600 dark:text-slate-300">
                                        Max <strong><?= $tier['max_books'] == 999 ? 'Unlimited' : $tier['max_books'] ?></strong> buku
                                    </span>
                                </li>
                                <li class="flex items-start gap-2.5">
                                    <span class="material-symbols-outlined text-emerald-500 !text-[20px] mt-0.5" style="font-variation-settings:'FILL' 1">check_circle</span>
                                    <span class="text-sm text-slate-600 dark:text-slate-300">
                                        <strong><?= $tier['borrow_days'] ?></strong> hari peminjaman
                                    </span>
                                </li>
                                <li class="flex items-start gap-2.5">
                                    <span class="material-symbols-outlined text-emerald-500 !text-[20px] mt-0.5" style="font-variation-settings:'FILL' 1">check_circle</span>
                                    <span class="text-sm text-slate-600 dark:text-slate-300">
                                        <strong><?= $tier['renewal_limit'] == 999 ? 'Unlimited' : $tier['renewal_limit'] . 'x' ?></strong> perpanjangan
                                    </span>
                                </li>
                                <li class="flex items-start gap-2.5">
                                    <?php if ($tier['penalty_rate'] > 0): ?>
                                        <span class="material-symbols-outlined text-primary !text-[20px] mt-0.5" style="font-variation-settings:'FILL' 1">info</span>
                                        <span class="text-sm text-slate-600 dark:text-slate-300">
                                            Denda <strong><?= formatRupiah($tier['penalty_rate']) ?></strong>/hari
                                        </span>
                                    <?php else: ?>
                                        <span class="material-symbols-outlined text-emerald-500 !text-[20px] mt-0.5" style="font-variation-settings:'FILL' 1">check_circle</span>
                                        <span class="text-sm text-slate-600 dark:text-slate-300">
                                            <strong>Tanpa denda</strong>
                                        </span>
                                    <?php endif; ?>
                                </li>
                            </ul>
                        </div>

                        <!-- CTA -->
                        <?php if (!isLoggedIn()): ?>
                            <div class="p-6 pt-0">
                                <a href="<?= BASE_URL ?>auth/register.php" 
                                   class="inline-flex items-center justify-center w-full gap-2 text-sm font-semibold px-4 py-3 rounded-xl transition-all duration-200 <?= $is_popular ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-lg shadow-amber-500/25' : 'bg-slate-100 dark:bg-slate-700 hover:bg-primary hover:text-white text-slate-700 dark:text-slate-300' ?>">
                                    <span class="material-symbols-outlined !text-[18px]">person_add</span>
                                    Daftar
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
