<?php
/**
 * Admin - Kelola Penerbit - BookHaven Digital Library
 * CRUD penerbit novel
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$page_title = 'Kelola Penerbit';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_publisher'])) {
        $name = sanitize($_POST['publisher_name']);
        $country = sanitize($_POST['country'] ?? '');
        $website = sanitize($_POST['website'] ?? '');
        $stmt = mysqli_prepare($conn, "INSERT INTO publishers (publisher_name, country, website) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sss", $name, $country, $website);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Penerbit berhasil ditambahkan');
        header("Location: " . BASE_URL . "admin/publishers.php"); exit;
    }
    if (isset($_POST['edit_publisher'])) {
        $id = intval($_POST['publisher_id']);
        $name = sanitize($_POST['publisher_name']);
        $country = sanitize($_POST['country'] ?? '');
        $website = sanitize($_POST['website'] ?? '');
        $stmt = mysqli_prepare($conn, "UPDATE publishers SET publisher_name=?, country=?, website=? WHERE publisher_id=?");
        mysqli_stmt_bind_param($stmt, "sssi", $name, $country, $website, $id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Penerbit berhasil diperbarui');
        header("Location: " . BASE_URL . "admin/publishers.php"); exit;
    }
    if (isset($_POST['delete_publisher'])) {
        $id = intval($_POST['publisher_id']);
        $stmt = mysqli_prepare($conn, "DELETE FROM publishers WHERE publisher_id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Penerbit berhasil dihapus');
        header("Location: " . BASE_URL . "admin/publishers.php"); exit;
    }
}

$publishers = [];
$r = mysqli_query($conn, "SELECT p.*, (SELECT COUNT(*) FROM books WHERE publisher_id = p.publisher_id) as book_count FROM publishers p ORDER BY p.publisher_name");
while ($row = mysqli_fetch_assoc($r)) $publishers[] = $row;

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Kelola Penerbit</h2>
            <div class="flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400 mt-0.5">
                <a href="<?= BASE_URL ?>admin/index.php" class="hover:text-primary transition-colors">Dashboard</a>
                <span class="material-symbols-outlined text-[12px]">chevron_right</span>
                <span class="text-gray-900 dark:text-white font-medium">Penerbit</span>
            </div>
        </div>
        <button onclick="openModal('addModal')" class="inline-flex items-center gap-2 bg-primary hover:bg-blue-700 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-sm shadow-primary/20 transition-colors">
            <span class="material-symbols-outlined text-[18px]">add_circle</span>
            Tambah Penerbit
        </button>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Summary Bar -->
        <div class="flex items-center gap-4 flex-wrap">
            <div class="inline-flex items-center gap-2 bg-white dark:bg-[#1e293b] border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2.5 text-sm">
                <span class="material-symbols-outlined text-primary text-[18px]">apartment</span>
                <span class="text-gray-500 dark:text-slate-400">Total:</span>
                <span class="font-bold text-gray-900 dark:text-white"><?= count($publishers) ?> penerbit</span>
            </div>
        </div>

        <!-- Publishers Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                    <thead class="bg-gray-50 dark:bg-[#293038] text-gray-500 dark:text-slate-400">
                        <tr>
                            <th class="px-5 py-3.5 font-medium w-12">#</th>
                            <th class="px-5 py-3.5 font-medium">Nama Penerbit</th>
                            <th class="px-5 py-3.5 font-medium">Negara</th>
                            <th class="px-5 py-3.5 font-medium">Website</th>
                            <th class="px-5 py-3.5 font-medium">Jumlah Buku</th>
                            <th class="px-5 py-3.5 font-medium text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700 text-gray-700 dark:text-gray-300">
                        <?php if (empty($publishers)): ?>
                            <tr>
                                <td colspan="6" class="px-5 py-12 text-center text-gray-400 dark:text-slate-500">
                                    <span class="material-symbols-outlined text-5xl block mb-3">domain_disabled</span>
                                    <p class="text-sm font-medium">Belum ada penerbit</p>
                                    <p class="text-xs mt-1">Klik tombol "Tambah Penerbit" untuk menambahkan</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; foreach ($publishers as $p): ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                    <td class="px-5 py-3.5 text-gray-400 dark:text-slate-500 font-medium"><?= $no++ ?></td>
                                    <td class="px-5 py-3.5">
                                        <span class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($p['publisher_name']) ?></span>
                                    </td>
                                    <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400">
                                        <?php if (!empty($p['country'])): ?>
                                            <span class="inline-flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[14px]">public</span>
                                                <?= htmlspecialchars($p['country']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-300 dark:text-slate-600">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <?php if (!empty($p['website'])): ?>
                                            <a href="<?= htmlspecialchars($p['website']) ?>" target="_blank"
                                               class="inline-flex items-center gap-1.5 text-primary hover:text-blue-700 dark:hover:text-blue-300 transition-colors text-sm">
                                                <span class="material-symbols-outlined text-[14px]">language</span>
                                                <span class="underline underline-offset-2">Kunjungi</span>
                                                <span class="material-symbols-outlined text-[12px]">open_in_new</span>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-gray-300 dark:text-slate-600">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <span class="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400">
                                            <span class="material-symbols-outlined text-[13px]">menu_book</span>
                                            <?= $p['book_count'] ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <div class="flex items-center justify-center gap-1.5">
                                            <button onclick="editPub(<?= htmlspecialchars(json_encode($p)) ?>)"
                                                    class="p-1.5 rounded-lg text-gray-400 dark:text-slate-500 hover:text-yellow-500 hover:bg-yellow-500/10 transition-all" title="Edit">
                                                <span class="material-symbols-outlined text-[18px]">edit</span>
                                            </button>
                                            <form method="POST" class="inline">
                                                <input type="hidden" name="publisher_id" value="<?= $p['publisher_id'] ?>">
                                                <input type="hidden" name="delete_publisher" value="1">
                                                <button type="submit" onclick="return confirm('Hapus penerbit ini?')"
                                                        class="p-1.5 rounded-lg text-gray-400 dark:text-slate-500 hover:text-red-500 hover:bg-red-500/10 transition-all" title="Hapus">
                                                    <span class="material-symbols-outlined text-[18px]">delete</span>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div><!-- end scrollable -->
</main>

<!-- Add Modal -->
<div id="addModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-lg mx-4 transform transition-all">
        <form method="POST">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                        <span class="material-symbols-outlined text-primary text-[20px]">domain_add</span>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white">Tambah Penerbit</h3>
                </div>
                <button type="button" onclick="closeModal('addModal')" class="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-all">
                    <span class="material-symbols-outlined text-[20px]">close</span>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="px-6 py-5 space-y-4 max-h-[65vh] overflow-y-auto">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Nama Penerbit <span class="text-red-500">*</span></label>
                    <input type="text" name="publisher_name" required
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500"
                           placeholder="Masukkan nama penerbit">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Negara</label>
                    <input type="text" name="country"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500"
                           placeholder="Contoh: Indonesia">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Website</label>
                    <input type="url" name="website"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500"
                           placeholder="https://example.com">
                </div>
            </div>
            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                <button type="button" onclick="closeModal('addModal')"
                        class="px-4 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors">
                    Batal
                </button>
                <button type="submit" name="add_publisher"
                        class="px-5 py-2.5 text-sm font-medium text-white bg-primary hover:bg-blue-700 rounded-lg shadow-sm shadow-primary/20 transition-colors">
                    <span class="inline-flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[16px]">save</span>
                        Simpan
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-lg mx-4 transform transition-all">
        <form method="POST">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                        <span class="material-symbols-outlined text-yellow-500 text-[20px]">edit</span>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white">Edit Penerbit</h3>
                </div>
                <button type="button" onclick="closeModal('editModal')" class="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-all">
                    <span class="material-symbols-outlined text-[20px]">close</span>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="px-6 py-5 space-y-4 max-h-[65vh] overflow-y-auto">
                <input type="hidden" name="publisher_id" id="e_pub_id">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Nama Penerbit <span class="text-red-500">*</span></label>
                    <input type="text" name="publisher_name" id="e_pub_name" required
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Negara</label>
                    <input type="text" name="country" id="e_pub_country"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Website</label>
                    <input type="url" name="website" id="e_pub_website"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"
                           placeholder="https://">
                </div>
            </div>
            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                <button type="button" onclick="closeModal('editModal')"
                        class="px-4 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors">
                    Batal
                </button>
                <button type="submit" name="edit_publisher"
                        class="px-5 py-2.5 text-sm font-medium text-white bg-yellow-500 hover:bg-yellow-600 rounded-lg shadow-sm shadow-yellow-500/20 transition-colors">
                    <span class="inline-flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[16px]">save</span>
                        Update
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal helpers
function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}
function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
    document.body.style.overflow = '';
}
// Close modal on backdrop click
document.querySelectorAll('[data-modal]').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) closeModal(this.id);
    });
});
// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('[data-modal]:not(.hidden)').forEach(m => closeModal(m.id));
    }
});

// Populate edit modal
function editPub(p) {
    document.getElementById('e_pub_id').value = p.publisher_id;
    document.getElementById('e_pub_name').value = p.publisher_name;
    document.getElementById('e_pub_country').value = p.country || '';
    document.getElementById('e_pub_website').value = p.website || '';
    openModal('editModal');
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
