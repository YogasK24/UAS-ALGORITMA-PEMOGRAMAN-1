<?php
/**
 * Admin - Kelola Denda - BookHaven Digital Library
 * Mengelola denda keterlambatan
 * Algoritma: foreach, switch-case, if-else
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$page_title = 'Kelola Denda';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['mark_paid'])) {
        $pid = intval($_POST['penalty_id']);
        $stmt = mysqli_prepare($conn, "UPDATE penalties SET penalty_status='paid', paid_at=NOW() WHERE penalty_id=?");
        mysqli_stmt_bind_param($stmt, "i", $pid);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Denda berhasil ditandai lunas');
        header("Location: " . BASE_URL . "admin/penalties.php"); exit;
    }
    if (isset($_POST['waive_penalty'])) {
        $pid = intval($_POST['penalty_id']);
        $stmt = mysqli_prepare($conn, "UPDATE penalties SET penalty_status='waived', paid_at=NOW() WHERE penalty_id=?");
        mysqli_stmt_bind_param($stmt, "i", $pid);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Denda berhasil dihapuskan (waived)');
        header("Location: " . BASE_URL . "admin/penalties.php"); exit;
    }
}

// Stats
$total_unpaid = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(penalty_amount),0) as total FROM penalties WHERE penalty_status='unpaid'"))['total'];
$total_paid = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(penalty_amount),0) as total FROM penalties WHERE penalty_status='paid'"))['total'];
$total_waived = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(penalty_amount),0) as total FROM penalties WHERE penalty_status='waived'"))['total'];
$count_unpaid = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM penalties WHERE penalty_status='unpaid'"))['c'];

// Filter
$filter = $_GET['status'] ?? 'all';
$page = max(1, intval($_GET['page'] ?? 1));

$where = '';
if ($filter !== 'all') {
    $where = "WHERE p.penalty_status = '" . mysqli_real_escape_string($conn, $filter) . "'";
}

$total_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM penalties p $where"))['c'];
$total_pages = ceil($total_count / ITEMS_PER_PAGE);
$offset = ($page - 1) * ITEMS_PER_PAGE;

$sql = "SELECT p.*, u.full_name, u.username, b.title as book_title, br.borrow_date, br.due_date, br.return_date
        FROM penalties p
        JOIN users u ON p.user_id = u.user_id
        JOIN borrowings br ON p.borrow_id = br.borrow_id
        JOIN books b ON br.book_id = b.book_id
        $where
        ORDER BY p.created_at DESC LIMIT $offset, " . ITEMS_PER_PAGE;

$penalties = [];
$r = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($r)) $penalties[] = $row;

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span class="material-symbols-outlined text-primary">gavel</span>
                Kelola Denda
            </h2>
            <p class="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Kelola denda keterlambatan pengembalian buku</p>
        </div>
        <div class="flex items-center gap-2">
            <span class="text-xs text-gray-400 dark:text-slate-500 hidden sm:inline"><?= date('d F Y') ?></span>
        </div>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <!-- Belum Dibayar -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-accent-red/30 shadow-sm shadow-accent-red/5 relative overflow-hidden">
                <div class="absolute right-0 top-0 w-16 h-16 bg-accent-red/10 rounded-bl-full -mr-2 -mt-2"></div>
                <div class="relative z-10">
                    <div class="flex items-center gap-2 mb-1">
                        <div class="p-1.5 bg-accent-red/10 rounded-lg text-accent-red">
                            <span class="material-symbols-outlined text-[20px]">pending</span>
                        </div>
                        <span class="text-xs font-medium text-gray-500 dark:text-slate-400">Belum Dibayar</span>
                    </div>
                    <h3 class="text-xl font-bold text-accent-red mt-2"><?= formatRupiah($total_unpaid) ?></h3>
                    <p class="text-xs text-gray-400 dark:text-slate-500 mt-1"><?= $count_unpaid ?> denda aktif</p>
                </div>
            </div>
            <!-- Sudah Dibayar -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex items-center gap-2 mb-1">
                    <div class="p-1.5 bg-green-500/10 rounded-lg text-green-500">
                        <span class="material-symbols-outlined text-[20px]">check_circle</span>
                    </div>
                    <span class="text-xs font-medium text-gray-500 dark:text-slate-400">Sudah Dibayar</span>
                </div>
                <h3 class="text-xl font-bold text-green-500 mt-2"><?= formatRupiah($total_paid) ?></h3>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-1">Total diterima</p>
            </div>
            <!-- Dihapuskan -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex items-center gap-2 mb-1">
                    <div class="p-1.5 bg-yellow-500/10 rounded-lg text-yellow-500">
                        <span class="material-symbols-outlined text-[20px]">remove_circle</span>
                    </div>
                    <span class="text-xs font-medium text-gray-500 dark:text-slate-400">Dihapuskan</span>
                </div>
                <h3 class="text-xl font-bold text-yellow-500 mt-2"><?= formatRupiah($total_waived) ?></h3>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-1">Total waived</p>
            </div>
            <!-- Total Keseluruhan -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex items-center gap-2 mb-1">
                    <div class="p-1.5 bg-primary/10 rounded-lg text-primary">
                        <span class="material-symbols-outlined text-[20px]">account_balance</span>
                    </div>
                    <span class="text-xs font-medium text-gray-500 dark:text-slate-400">Total Keseluruhan</span>
                </div>
                <h3 class="text-xl font-bold text-gray-900 dark:text-white mt-2"><?= formatRupiah($total_paid + $total_unpaid + $total_waived) ?></h3>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-1">Semua denda</p>
            </div>
        </div>

        <!-- Filter Tabs -->
        <div class="flex items-center gap-1 p-1 bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm w-fit">
            <?php
            $tabs = [
                'all' => ['label' => 'Semua', 'icon' => 'list'],
                'unpaid' => ['label' => 'Belum Dibayar', 'icon' => 'pending'],
                'paid' => ['label' => 'Sudah Dibayar', 'icon' => 'check_circle'],
                'waived' => ['label' => 'Dihapuskan', 'icon' => 'remove_circle'],
            ];
            foreach ($tabs as $key => $tab):
                $active = $filter === $key;
            ?>
            <a href="?status=<?= $key ?>"
               class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200
                      <?= $active
                          ? 'bg-primary text-white shadow-sm'
                          : 'text-gray-500 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-[#293038] hover:text-gray-700 dark:hover:text-white' ?>">
                <span class="material-symbols-outlined text-[18px]"><?= $tab['icon'] ?></span>
                <?= $tab['label'] ?>
            </a>
            <?php endforeach; ?>
        </div>

        <!-- Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-[#293038] border-b border-gray-200 dark:border-gray-700">
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">#</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Member</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Buku</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Terlambat</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Jumlah Denda</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Status</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Tanggal</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700/50">
                        <?php $no = $offset + 1; foreach ($penalties as $p): ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                            <td class="px-4 py-3 text-gray-500 dark:text-slate-400"><?= $no++ ?></td>
                            <td class="px-4 py-3">
                                <p class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($p['full_name']) ?></p>
                                <p class="text-xs text-gray-400 dark:text-slate-500">@<?= htmlspecialchars($p['username']) ?></p>
                            </td>
                            <td class="px-4 py-3 text-gray-700 dark:text-slate-300 max-w-[200px] truncate"><?= htmlspecialchars($p['book_title']) ?></td>
                            <td class="px-4 py-3 text-center">
                                <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400">
                                    <span class="material-symbols-outlined text-[14px]">schedule</span>
                                    <?= $p['days_late'] ?> hari
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="font-bold text-gray-900 dark:text-white"><?= formatRupiah($p['penalty_amount']) ?></span>
                            </td>
                            <td class="px-4 py-3">
                                <?php
                                switch ($p['penalty_status']) {
                                    case 'unpaid':
                                        echo '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"><span class="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>Belum Dibayar</span>';
                                        break;
                                    case 'paid':
                                        echo '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400"><span class="w-1.5 h-1.5 rounded-full bg-green-500"></span>Lunas</span>';
                                        break;
                                    case 'waived':
                                        echo '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400"><span class="w-1.5 h-1.5 rounded-full bg-yellow-500"></span>Dihapuskan</span>';
                                        break;
                                }
                                ?>
                            </td>
                            <td class="px-4 py-3 text-gray-600 dark:text-slate-400 whitespace-nowrap text-xs"><?= formatDate($p['created_at']) ?></td>
                            <td class="px-4 py-3">
                                <?php if ($p['penalty_status'] === 'unpaid'): ?>
                                <div class="flex items-center gap-1.5">
                                    <form method="POST">
                                        <input type="hidden" name="penalty_id" value="<?= $p['penalty_id'] ?>">
                                        <input type="hidden" name="mark_paid" value="1">
                                        <button type="submit" title="Tandai Lunas"
                                                class="p-1.5 rounded-lg bg-green-600 hover:bg-green-700 text-white transition-colors shadow-sm">
                                            <span class="material-symbols-outlined text-[18px]">check</span>
                                        </button>
                                    </form>
                                    <form method="POST">
                                        <input type="hidden" name="penalty_id" value="<?= $p['penalty_id'] ?>">
                                        <input type="hidden" name="waive_penalty" value="1">
                                        <button type="submit" onclick="return confirm('Hapuskan denda ini?')" title="Hapuskan Denda"
                                                class="p-1.5 rounded-lg border border-yellow-300 dark:border-yellow-700/50 text-yellow-600 dark:text-yellow-400 hover:bg-yellow-50 dark:hover:bg-yellow-900/20 transition-colors">
                                            <span class="material-symbols-outlined text-[18px]">close</span>
                                        </button>
                                    </form>
                                </div>
                                <?php else: ?>
                                    <span class="text-xs text-gray-400 dark:text-slate-500"><?= $p['paid_at'] ? formatDate($p['paid_at']) : '-' ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($penalties)): ?>
                        <tr>
                            <td colspan="8" class="px-4 py-12 text-center">
                                <div class="flex flex-col items-center gap-2">
                                    <span class="material-symbols-outlined text-4xl text-gray-300 dark:text-slate-600">payments</span>
                                    <p class="text-gray-500 dark:text-slate-400">Tidak ada data denda</p>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="flex items-center justify-center gap-1 pt-2">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary text-white text-sm font-semibold shadow-sm"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&status=<?= $filter ?>"
                       class="inline-flex items-center justify-center w-9 h-9 rounded-lg text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-[#293038] text-sm font-medium transition-colors"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>

    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
