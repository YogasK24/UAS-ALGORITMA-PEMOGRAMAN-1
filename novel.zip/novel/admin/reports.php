<?php
/**
 * Admin - Laporan & Statistik - BookHaven Digital Library
 * Halaman laporan dengan berbagai statistik perpustakaan
 * Algoritma: foreach, for, while, switch-case, if-else, array multidimensi
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$page_title = 'Laporan & Statistik';

// ============================
// 1. Statistik Peminjaman per Genre (array multidimensi)
// ============================
$genre_stats = [];
$r = mysqli_query($conn, "
    SELECT g.genre_name, COUNT(br.borrow_id) as borrow_count
    FROM genres g
    LEFT JOIN book_genres bg ON g.genre_id = bg.genre_id
    LEFT JOIN books b ON bg.book_id = b.book_id
    LEFT JOIN borrowings br ON b.book_id = br.book_id
    GROUP BY g.genre_id, g.genre_name
    ORDER BY borrow_count DESC
");
while ($row = mysqli_fetch_assoc($r)) $genre_stats[] = $row;
$max_genre_borrow = !empty($genre_stats) ? max(array_column($genre_stats, 'borrow_count')) : 1;

// ============================
// 2. Statistik Member per Tier
// ============================
$tier_stats = [
    1 => ['name' => 'Free', 'count' => 0, 'color' => '#6b7280'],
    2 => ['name' => 'Silver', 'count' => 0, 'color' => '#64748b'],
    3 => ['name' => 'Gold', 'count' => 0, 'color' => '#eab308'],
    4 => ['name' => 'Premium', 'count' => 0, 'color' => '#a855f7'],
];
$r = mysqli_query($conn, "SELECT tier_id, COUNT(*) as cnt FROM users WHERE role='member' GROUP BY tier_id");
while ($row = mysqli_fetch_assoc($r)) {
    if (isset($tier_stats[$row['tier_id']])) {
        $tier_stats[$row['tier_id']]['count'] = $row['cnt'];
    }
}
$total_members = array_sum(array_column($tier_stats, 'count'));

// ============================
// 3. Trend Peminjaman 6 Bulan Terakhir
// ============================
$monthly_trends = [];
for ($i = 5; $i >= 0; $i--) {
    $month_start = date('Y-m-01', strtotime("-$i months"));
    $month_end = date('Y-m-t', strtotime("-$i months"));
    $month_label = date('M Y', strtotime("-$i months"));

    $r = mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE borrow_date BETWEEN '$month_start' AND '$month_end 23:59:59'");
    $count = mysqli_fetch_assoc($r)['c'];

    $monthly_trends[] = [
        'month' => $month_label,
        'count' => $count
    ];
}
$max_monthly = max(array_column($monthly_trends, 'count'));
if ($max_monthly == 0) $max_monthly = 1;

// ============================
// 4. Top 10 Buku Terpopuler
// ============================
$popular_books = [];
$r = mysqli_query($conn, "
    SELECT b.title, b.cover_image, a.author_name, COUNT(br.borrow_id) as borrow_count, AVG(rv.rating) as avg_rating
    FROM books b
    LEFT JOIN authors a ON b.author_id = a.author_id
    LEFT JOIN borrowings br ON b.book_id = br.book_id
    LEFT JOIN reviews rv ON b.book_id = rv.book_id
    GROUP BY b.book_id
    ORDER BY borrow_count DESC
    LIMIT 10
");
while ($row = mysqli_fetch_assoc($r)) $popular_books[] = $row;

// ============================
// 5. Top Borrowers
// ============================
$top_borrowers = [];
$r = mysqli_query($conn, "
    SELECT u.full_name, u.username, u.tier_id, COUNT(br.borrow_id) as total_borrows
    FROM users u
    JOIN borrowings br ON u.user_id = br.user_id
    WHERE u.role = 'member'
    GROUP BY u.user_id
    ORDER BY total_borrows DESC
    LIMIT 10
");
while ($row = mysqli_fetch_assoc($r)) $top_borrowers[] = $row;

// ============================
// 6. Ringkasan Keseluruhan
// ============================
$summary = [
    'total_books' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM books"))['c'],
    'total_members' => $total_members,
    'total_borrowings' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings"))['c'],
    'active_borrows' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE status='borrowed'"))['c'],
    'total_overdue' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE status='overdue'"))['c'],
    'total_revenue' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(penalty_amount),0) as c FROM penalties WHERE penalty_status='paid'"))['c'],
    'total_reviews' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM reviews"))['c'],
    'avg_rating' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(AVG(rating),0) as c FROM reviews"))['c'],
];

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span class="material-symbols-outlined text-primary">assessment</span>
                Laporan & Statistik
            </h2>
            <p class="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Ringkasan data perpustakaan</p>
        </div>
        <button onclick="window.print()" class="inline-flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary/90 text-white text-sm font-medium rounded-lg transition-colors shadow-sm no-print">
            <span class="material-symbols-outlined text-[18px]">print</span>
            Cetak Laporan
        </button>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <!-- Summary Cards (8 cards) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <?php
            $cards = [
                ['icon' => 'library_books', 'label' => 'Total Buku', 'value' => number_format($summary['total_books']), 'color' => 'primary', 'desc' => 'Buku di perpustakaan'],
                ['icon' => 'group', 'label' => 'Total Member', 'value' => number_format($summary['total_members']), 'color' => 'purple-500', 'desc' => 'Anggota terdaftar'],
                ['icon' => 'swap_horiz', 'label' => 'Total Peminjaman', 'value' => number_format($summary['total_borrowings']), 'color' => 'blue-500', 'desc' => 'Semua transaksi'],
                ['icon' => 'outbox', 'label' => 'Sedang Dipinjam', 'value' => number_format($summary['active_borrows']), 'color' => 'orange-500', 'desc' => 'Peminjaman aktif'],
                ['icon' => 'warning', 'label' => 'Terlambat', 'value' => number_format($summary['total_overdue']), 'color' => 'accent-red', 'desc' => 'Overdue saat ini'],
                ['icon' => 'payments', 'label' => 'Pendapatan Denda', 'value' => formatRupiah($summary['total_revenue']), 'color' => 'green-500', 'desc' => 'Denda terbayar'],
                ['icon' => 'rate_review', 'label' => 'Total Review', 'value' => number_format($summary['total_reviews']), 'color' => 'cyan-500', 'desc' => 'Ulasan member'],
                ['icon' => 'star', 'label' => 'Rata-rata Rating', 'value' => number_format($summary['avg_rating'], 1), 'color' => 'yellow-500', 'desc' => 'Rating keseluruhan'],
            ];
            foreach ($cards as $card):
            ?>
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400"><?= $card['label'] ?></p>
                        <h3 class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?= $card['value'] ?></h3>
                    </div>
                    <div class="p-2.5 bg-<?= $card['color'] ?>/10 rounded-lg text-<?= $card['color'] ?>">
                        <span class="material-symbols-outlined"><?= $card['icon'] ?></span>
                    </div>
                </div>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-2"><?= $card['desc'] ?></p>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Genre Stats & Tier Distribution Row -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Genre Stats Bar Chart -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-2">
                    <span class="material-symbols-outlined text-primary text-[20px]">bar_chart</span>
                    <h3 class="text-sm font-bold text-gray-900 dark:text-white">Peminjaman per Genre</h3>
                </div>
                <div class="p-5 space-y-3 max-h-[400px] overflow-y-auto">
                    <?php foreach ($genre_stats as $gs): ?>
                    <div>
                        <div class="flex justify-between items-center mb-1.5">
                            <span class="text-sm text-gray-700 dark:text-slate-300"><?= htmlspecialchars($gs['genre_name']) ?></span>
                            <span class="text-sm font-bold text-gray-900 dark:text-white"><?= $gs['borrow_count'] ?></span>
                        </div>
                        <div class="w-full h-2.5 bg-gray-100 dark:bg-gray-700/50 rounded-full overflow-hidden">
                            <div class="h-full bg-primary rounded-full transition-all duration-500" style="width: <?= ($gs['borrow_count'] / $max_genre_borrow) * 100 ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php if (empty($genre_stats)): ?>
                    <p class="text-center text-gray-400 dark:text-slate-500 py-4 text-sm">Belum ada data</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tier Distribution -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-2">
                    <span class="material-symbols-outlined text-primary text-[20px]">donut_large</span>
                    <h3 class="text-sm font-bold text-gray-900 dark:text-white">Distribusi Tier Member</h3>
                </div>
                <div class="p-5 space-y-3">
                    <?php foreach ($tier_stats as $tid => $ts): ?>
                    <div class="flex items-center gap-4 p-4 rounded-xl bg-gray-50 dark:bg-[#111418] border border-gray-100 dark:border-gray-700/50">
                        <div class="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg shrink-0" style="background: <?= $ts['color'] ?>">
                            <?= $ts['count'] ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex justify-between items-center mb-1.5">
                                <span class="text-sm font-semibold text-gray-900 dark:text-white"><?= $ts['name'] ?></span>
                                <span class="text-sm font-bold text-gray-700 dark:text-slate-300"><?= $total_members > 0 ? round(($ts['count'] / $total_members) * 100) : 0 ?>%</span>
                            </div>
                            <div class="w-full h-2 bg-gray-200 dark:bg-gray-700/50 rounded-full overflow-hidden">
                                <div class="h-full rounded-full transition-all duration-500" style="width: <?= $total_members > 0 ? ($ts['count'] / $total_members) * 100 : 0 ?>%; background: <?= $ts['color'] ?>"></div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Monthly Trend & Top Borrowers Row -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Monthly Trend Bar Chart -->
            <div class="lg:col-span-2 bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-2">
                    <span class="material-symbols-outlined text-primary text-[20px]">trending_up</span>
                    <h3 class="text-sm font-bold text-gray-900 dark:text-white">Trend Peminjaman 6 Bulan Terakhir</h3>
                </div>
                <div class="p-5">
                    <div class="flex items-end justify-around gap-2" style="height: 220px;">
                        <?php foreach ($monthly_trends as $mt): ?>
                        <div class="flex flex-col items-center flex-1 h-full justify-end">
                            <div class="relative w-full max-w-[48px] group">
                                <div class="bg-primary/80 hover:bg-primary rounded-t-lg mx-auto transition-all duration-300 cursor-default"
                                     style="width: 100%; height: <?= ($mt['count'] / $max_monthly) * 170 ?>px; min-height: 6px;">
                                </div>
                                <!-- Tooltip -->
                                <div class="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-xs font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                                    <?= $mt['count'] ?>
                                </div>
                            </div>
                            <div class="text-sm font-bold text-gray-900 dark:text-white mt-2"><?= $mt['count'] ?></div>
                            <div class="text-xs text-gray-400 dark:text-slate-500 mt-0.5"><?= $mt['month'] ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Top Borrowers -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-2">
                    <span class="material-symbols-outlined text-primary text-[20px]">emoji_events</span>
                    <h3 class="text-sm font-bold text-gray-900 dark:text-white">Top Peminjam</h3>
                </div>
                <div class="divide-y divide-gray-100 dark:divide-gray-700/50">
                    <?php $rank = 1; foreach ($top_borrowers as $tb): ?>
                    <div class="flex items-center justify-between px-5 py-3 hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                        <div class="flex items-center gap-3 min-w-0">
                            <?php if ($rank <= 3): ?>
                                <span class="inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold
                                    <?php
                                    switch ($rank) {
                                        case 1: echo 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400'; break;
                                        case 2: echo 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'; break;
                                        case 3: echo 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'; break;
                                    }
                                    ?>">
                                    <?= $rank ?>
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-medium text-gray-400 dark:text-slate-500">
                                    <?= $rank ?>
                                </span>
                            <?php endif; ?>
                            <div class="min-w-0">
                                <p class="text-sm font-semibold text-gray-900 dark:text-white truncate"><?= htmlspecialchars($tb['full_name']) ?></p>
                                <p class="text-xs text-gray-400 dark:text-slate-500">@<?= htmlspecialchars($tb['username']) ?></p>
                            </div>
                        </div>
                        <span class="inline-flex items-center justify-center min-w-[28px] px-2 py-1 rounded-full text-xs font-bold bg-primary/10 text-primary">
                            <?= $tb['total_borrows'] ?>
                        </span>
                    </div>
                    <?php $rank++; endforeach; ?>
                    <?php if (empty($top_borrowers)): ?>
                    <div class="px-5 py-8 text-center text-gray-400 dark:text-slate-500 text-sm">Belum ada data</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Top 10 Popular Books -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-2">
                <span class="material-symbols-outlined text-primary text-[20px]">auto_stories</span>
                <h3 class="text-sm font-bold text-gray-900 dark:text-white">Top 10 Buku Terpopuler</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-[#293038] border-b border-gray-200 dark:border-gray-700">
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">#</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Judul</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Penulis</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Jumlah Dipinjam</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Rating</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700/50">
                        <?php $no = 1; foreach ($popular_books as $pb): ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                            <td class="px-4 py-3">
                                <?php if ($no <= 3): ?>
                                    <span class="inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold
                                        <?php
                                        switch ($no) {
                                            case 1: echo 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400'; break;
                                            case 2: echo 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'; break;
                                            case 3: echo 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'; break;
                                        }
                                        ?>">
                                        <?= $no ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-gray-500 dark:text-slate-400"><?= $no ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <span class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($pb['title']) ?></span>
                            </td>
                            <td class="px-4 py-3 text-gray-600 dark:text-slate-400"><?= htmlspecialchars($pb['author_name'] ?? '-') ?></td>
                            <td class="px-4 py-3 text-center">
                                <span class="inline-flex items-center justify-center min-w-[28px] px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400">
                                    <?= $pb['borrow_count'] ?>
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <?= $pb['avg_rating'] ? ratingStars(round($pb['avg_rating'])) : '<span class="text-xs text-gray-400 dark:text-slate-500">Belum ada</span>' ?>
                            </td>
                        </tr>
                        <?php $no++; endforeach; ?>
                        <?php if (empty($popular_books)): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-12 text-center">
                                <div class="flex flex-col items-center gap-2">
                                    <span class="material-symbols-outlined text-4xl text-gray-300 dark:text-slate-600">menu_book</span>
                                    <p class="text-gray-500 dark:text-slate-400">Belum ada data buku</p>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
