<?php
/**
 * Admin - Kelola Peminjaman - BookHaven Digital Library
 * Mengelola semua transaksi peminjaman
 * Algoritma: foreach untuk iterasi, switch-case untuk status, if-else untuk filter
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$page_title = 'Kelola Peminjaman';

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Manual return
    if (isset($_POST['return_book'])) {
        $borrow_id = intval($_POST['borrow_id']);
        $borrow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM borrowings WHERE borrow_id = $borrow_id"));
        if ($borrow && $borrow['status'] === 'borrowed') {
            $return_date = date('Y-m-d H:i:s');
            $due = new DateTime($borrow['due_date']);
            $now = new DateTime($return_date);
            $diff = $now->diff($due);
            $days_late = ($now > $due) ? $diff->days : 0;

            mysqli_begin_transaction($conn);
            try {
                // Update borrowing
                $stmt = mysqli_prepare($conn, "UPDATE borrowings SET return_date=?, status='returned' WHERE borrow_id=?");
                mysqli_stmt_bind_param($stmt, "si", $return_date, $borrow_id);
                mysqli_stmt_execute($stmt);

                // Return book copies
                $stmt2 = mysqli_prepare($conn, "UPDATE books SET available_copies = available_copies + 1 WHERE book_id=?");
                mysqli_stmt_bind_param($stmt2, "i", $borrow['book_id']);
                mysqli_stmt_execute($stmt2);

                // Calculate penalty if late
                if ($days_late > 0) {
                    $penalty_info = calculatePenalty($borrow_id, $conn);
                    $penalty_amount = is_array($penalty_info) ? $penalty_info['total_amount'] : 0;
                    if ($penalty_amount > 0) {
                        $stmt3 = mysqli_prepare($conn, "INSERT INTO penalties (borrow_id, user_id, days_late, penalty_amount, penalty_status) VALUES (?,?,?,?,'unpaid')");
                        mysqli_stmt_bind_param($stmt3, "iiid", $borrow_id, $borrow['user_id'], $days_late, $penalty_amount);
                        mysqli_stmt_execute($stmt3);
                    }
                }
                mysqli_commit($conn);
                setFlash('success', "Buku berhasil dikembalikan" . ($days_late > 0 ? " (terlambat $days_late hari)" : ""));
            } catch (Exception $e) {
                mysqli_rollback($conn);
                setFlash('danger', 'Gagal mengembalikan buku');
            }
        }
        header("Location: " . BASE_URL . "admin/borrowings.php"); exit;
    }

    // Mark overdue
    if (isset($_POST['mark_overdue'])) {
        $now = date('Y-m-d H:i:s');
        $stmt = mysqli_prepare($conn, "UPDATE borrowings SET status='overdue' WHERE status='borrowed' AND due_date < ?");
        mysqli_stmt_bind_param($stmt, "s", $now);
        mysqli_stmt_execute($stmt);
        $affected = mysqli_affected_rows($conn);
        setFlash('success', "$affected peminjaman ditandai sebagai terlambat");
        header("Location: " . BASE_URL . "admin/borrowings.php"); exit;
    }
}

// Filter parameters
$filter_status = $_GET['status'] ?? 'all';
$filter_search = $_GET['search'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));

// Build query with filters - demonstrating if-else chain
$where = [];
$params = [];
$types = '';

if ($filter_status !== 'all') {
    $where[] = "br.status = ?";
    $params[] = $filter_status;
    $types .= 's';
}

if (!empty($filter_search)) {
    $where[] = "(u.full_name LIKE ? OR b.title LIKE ?)";
    $search = "%$filter_search%";
    $params[] = $search;
    $params[] = $search;
    $types .= 'ss';
}

$where_sql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Count total
$count_sql = "SELECT COUNT(*) as total FROM borrowings br
              JOIN users u ON br.user_id = u.user_id
              JOIN books b ON br.book_id = b.book_id $where_sql";
$count_stmt = mysqli_prepare($conn, $count_sql);
if (!empty($params)) {
    mysqli_stmt_bind_param($count_stmt, $types, ...$params);
}
mysqli_stmt_execute($count_stmt);
$total = mysqli_fetch_assoc(mysqli_stmt_get_result($count_stmt))['total'];
$total_pages = ceil($total / ITEMS_PER_PAGE);
$offset = ($page - 1) * ITEMS_PER_PAGE;

// Fetch borrowings
$sql = "SELECT br.*, u.full_name, u.username, b.title, b.cover_image,
        DATEDIFF(NOW(), br.due_date) as days_overdue
        FROM borrowings br
        JOIN users u ON br.user_id = u.user_id
        JOIN books b ON br.book_id = b.book_id
        $where_sql
        ORDER BY br.borrow_date DESC LIMIT ? OFFSET ?";
$stmt = mysqli_prepare($conn, $sql);
$types2 = $types . 'ii';
$params2 = array_merge($params, [ITEMS_PER_PAGE, $offset]);
mysqli_stmt_bind_param($stmt, $types2, ...$params2);
mysqli_stmt_execute($stmt);
$borrowings = [];
$result = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($result)) $borrowings[] = $row;

// Stats
$stats = [];
$stat_statuses = ['borrowed', 'returned', 'overdue'];
foreach ($stat_statuses as $s) {
    $r = mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE status = '$s'");
    $stats[$s] = mysqli_fetch_assoc($r)['c'];
}

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span class="material-symbols-outlined text-primary">swap_horiz</span>
                Kelola Peminjaman
            </h2>
            <p class="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Kelola transaksi peminjaman perpustakaan</p>
        </div>
        <form method="POST" class="flex items-center gap-3">
            <input type="hidden" name="mark_overdue" value="1">
            <button type="submit" onclick="return confirm('Tandai semua peminjaman yang melewati batas waktu sebagai overdue?')"
                    class="inline-flex items-center gap-2 px-4 py-2 bg-accent-red hover:bg-red-600 text-white text-sm font-medium rounded-lg transition-colors shadow-sm">
                <span class="material-symbols-outlined text-[18px]">schedule</span>
                Tandai Overdue
            </button>
        </form>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <!-- Total -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Total Peminjaman</p>
                        <h3 class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?= number_format($total) ?></h3>
                    </div>
                    <div class="p-2.5 bg-primary/10 rounded-lg text-primary">
                        <span class="material-symbols-outlined">library_books</span>
                    </div>
                </div>
            </div>
            <!-- Aktif -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Sedang Dipinjam</p>
                        <h3 class="text-2xl font-bold text-blue-500 mt-1"><?= number_format($stats['borrowed']) ?></h3>
                    </div>
                    <div class="p-2.5 bg-blue-500/10 rounded-lg text-blue-500">
                        <span class="material-symbols-outlined">outbox</span>
                    </div>
                </div>
            </div>
            <!-- Dikembalikan -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Dikembalikan</p>
                        <h3 class="text-2xl font-bold text-green-500 mt-1"><?= number_format($stats['returned']) ?></h3>
                    </div>
                    <div class="p-2.5 bg-green-500/10 rounded-lg text-green-500">
                        <span class="material-symbols-outlined">check_circle</span>
                    </div>
                </div>
            </div>
            <!-- Terlambat -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-accent-red/30 shadow-sm shadow-accent-red/5 relative overflow-hidden">
                <div class="absolute right-0 top-0 w-16 h-16 bg-accent-red/10 rounded-bl-full -mr-2 -mt-2"></div>
                <div class="flex justify-between items-start relative z-10">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Terlambat</p>
                        <h3 class="text-2xl font-bold text-accent-red mt-1"><?= number_format($stats['overdue']) ?></h3>
                    </div>
                    <div class="p-2.5 bg-accent-red/10 rounded-lg text-accent-red">
                        <span class="material-symbols-outlined">warning</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Card -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5">
            <form method="GET" class="flex flex-col md:flex-row gap-4 items-end">
                <div class="flex-1 min-w-0">
                    <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Cari</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500 text-[20px]">search</span>
                        <input type="text" name="search" value="<?= htmlspecialchars($filter_search) ?>"
                               placeholder="Nama member atau judul buku..."
                               class="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-colors">
                    </div>
                </div>
                <div class="w-full md:w-48">
                    <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Status</label>
                    <select name="status" class="w-full py-2.5 px-3 bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-colors">
                        <option value="all" <?= $filter_status === 'all' ? 'selected' : '' ?>>Semua Status</option>
                        <option value="borrowed" <?= $filter_status === 'borrowed' ? 'selected' : '' ?>>Dipinjam</option>
                        <option value="returned" <?= $filter_status === 'returned' ? 'selected' : '' ?>>Dikembalikan</option>
                        <option value="overdue" <?= $filter_status === 'overdue' ? 'selected' : '' ?>>Terlambat</option>
                    </select>
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-primary/90 text-white text-sm font-medium rounded-lg transition-colors">
                        <span class="material-symbols-outlined text-[18px]">filter_alt</span>
                        Filter
                    </button>
                    <a href="<?= BASE_URL ?>admin/borrowings.php" class="inline-flex items-center gap-2 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-[#293038] text-sm font-medium rounded-lg transition-colors">
                        <span class="material-symbols-outlined text-[18px]">restart_alt</span>
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-[#293038] border-b border-gray-200 dark:border-gray-700">
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">#</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Member</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Buku</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Tgl Pinjam</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Batas Kembali</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Tgl Kembali</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Status</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700/50">
                        <?php $no = $offset + 1; foreach ($borrowings as $br): ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                            <td class="px-4 py-3 text-gray-500 dark:text-slate-400"><?= $no++ ?></td>
                            <td class="px-4 py-3">
                                <p class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($br['full_name']) ?></p>
                                <p class="text-xs text-gray-400 dark:text-slate-500">@<?= htmlspecialchars($br['username']) ?></p>
                            </td>
                            <td class="px-4 py-3 text-gray-700 dark:text-slate-300 max-w-[200px] truncate"><?= htmlspecialchars($br['title']) ?></td>
                            <td class="px-4 py-3 text-gray-600 dark:text-slate-400 whitespace-nowrap"><?= formatDate($br['borrow_date']) ?></td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <span class="text-gray-600 dark:text-slate-400"><?= formatDate($br['due_date']) ?></span>
                                <?php if ($br['status'] === 'borrowed' && $br['days_overdue'] > 0): ?>
                                    <span class="ml-1 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400">
                                        <?= $br['days_overdue'] ?> hari terlambat
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-gray-600 dark:text-slate-400 whitespace-nowrap"><?= $br['return_date'] ? formatDate($br['return_date']) : '<span class="text-slate-500">-</span>' ?></td>
                            <td class="px-4 py-3">
                                <?php
                                // Switch-case untuk badge status
                                switch ($br['status']) {
                                    case 'borrowed':
                                        echo '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"><span class="w-1.5 h-1.5 rounded-full bg-blue-500"></span>Dipinjam</span>';
                                        break;
                                    case 'returned':
                                        echo '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400"><span class="w-1.5 h-1.5 rounded-full bg-green-500"></span>Dikembalikan</span>';
                                        break;
                                    case 'overdue':
                                        echo '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"><span class="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>Terlambat</span>';
                                        break;
                                    default:
                                        echo '<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-slate-400">-</span>';
                                }
                                ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if ($br['status'] === 'borrowed' || $br['status'] === 'overdue'): ?>
                                <form method="POST">
                                    <input type="hidden" name="borrow_id" value="<?= $br['borrow_id'] ?>">
                                    <input type="hidden" name="return_book" value="1">
                                    <button type="submit" onclick="return confirm('Kembalikan buku ini?')"
                                            class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-medium rounded-lg transition-colors shadow-sm">
                                        <span class="material-symbols-outlined text-[16px]">assignment_return</span>
                                        Kembalikan
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($borrowings)): ?>
                        <tr>
                            <td colspan="8" class="px-4 py-12 text-center">
                                <div class="flex flex-col items-center gap-2">
                                    <span class="material-symbols-outlined text-4xl text-gray-300 dark:text-slate-600">inbox</span>
                                    <p class="text-gray-500 dark:text-slate-400">Tidak ada data peminjaman</p>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="flex items-center justify-center gap-1 pt-2">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary text-white text-sm font-semibold shadow-sm"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&status=<?= $filter_status ?>&search=<?= urlencode($filter_search) ?>"
                       class="inline-flex items-center justify-center w-9 h-9 rounded-lg text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-[#293038] text-sm font-medium transition-colors"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>

    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
