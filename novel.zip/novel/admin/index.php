<?php
/**
 * Admin Dashboard - BookHaven Digital Library
 * ALGORITMA: FOREACH, ARRAY MULTIDIMENSI, IF-ELSE
 * 
 * Menampilkan statistik perpustakaan:
 * - Total buku, member, peminjaman aktif, overdue, denda
 * - Data chart: genre, tier, trend peminjaman
 * - Aktivitas terbaru
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$page_title = 'Admin Dashboard';

// =============================================
// STATISTIK UTAMA (ARRAY)
// =============================================
$stats = [];

// Total buku
$r = mysqli_query($conn, "SELECT COUNT(*) as c FROM books WHERE is_active = 1");
$stats['total_books'] = mysqli_fetch_assoc($r)['c'];

// Total member aktif
$r = mysqli_query($conn, "SELECT COUNT(*) as c FROM users WHERE role = 'member' AND is_active = 1");
$stats['total_members'] = mysqli_fetch_assoc($r)['c'];

// Buku sedang dipinjam
$r = mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE status = 'borrowed'");
$stats['active_borrows'] = mysqli_fetch_assoc($r)['c'];

// Buku overdue (jatuh tempo < hari ini DAN status masih borrowed)
$r = mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE status = 'borrowed' AND due_date < CURDATE()");
$stats['overdue'] = mysqli_fetch_assoc($r)['c'];

// Total denda belum bayar
$r = mysqli_query($conn, "SELECT COALESCE(SUM(penalty_amount), 0) as total FROM penalties WHERE penalty_status = 'unpaid'");
$stats['unpaid_penalties'] = mysqli_fetch_assoc($r)['total'];

// Total denda sudah bayar
$r = mysqli_query($conn, "SELECT COALESCE(SUM(penalty_amount), 0) as total FROM penalties WHERE penalty_status = 'paid'");
$stats['paid_penalties'] = mysqli_fetch_assoc($r)['total'];

// =============================================
// DATA CHART: Peminjaman per Genre (ARRAY MULTIDIMENSI)
// =============================================
$genre_stats = [];
$r = mysqli_query($conn, "SELECT g.genre_name, COUNT(br.borrow_id) as count
                          FROM borrowings br
                          JOIN book_genres bg ON br.book_id = bg.book_id
                          JOIN genres g ON bg.genre_id = g.genre_id
                          GROUP BY g.genre_name
                          ORDER BY count DESC");
while ($row = mysqli_fetch_assoc($r)) {
    $genre_stats[] = $row;
}

// DATA CHART: Distribusi member per tier
$tier_stats = [];
$r = mysqli_query($conn, "SELECT mt.tier_name, COUNT(u.user_id) as count
                          FROM users u
                          JOIN membership_tiers mt ON u.tier_id = mt.tier_id
                          WHERE u.role = 'member'
                          GROUP BY mt.tier_name
                          ORDER BY mt.tier_id");
while ($row = mysqli_fetch_assoc($r)) {
    $tier_stats[] = $row;
}

// DATA CHART: Trend peminjaman 30 hari terakhir
$trend_data = [];
$r = mysqli_query($conn, "SELECT DATE(borrow_date) as date, COUNT(*) as count
                          FROM borrowings
                          WHERE borrow_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                          GROUP BY DATE(borrow_date)
                          ORDER BY date");
while ($row = mysqli_fetch_assoc($r)) {
    $trend_data[] = $row;
}

// =============================================
// AKTIVITAS TERBARU
// =============================================

// 10 peminjaman terbaru
$recent_borrows = [];
$r = mysqli_query($conn, "SELECT br.*, b.title, u.full_name, u.username
                          FROM borrowings br
                          JOIN books b ON br.book_id = b.book_id
                          JOIN users u ON br.user_id = u.user_id
                          ORDER BY br.created_at DESC LIMIT 10");
while ($row = mysqli_fetch_assoc($r)) {
    $recent_borrows[] = $row;
}

// Daftar overdue
$overdue_list = [];
$r = mysqli_query($conn, "SELECT br.*, b.title, u.full_name, u.username, mt.penalty_rate, mt.tier_name
                          FROM borrowings br
                          JOIN books b ON br.book_id = b.book_id
                          JOIN users u ON br.user_id = u.user_id
                          JOIN membership_tiers mt ON u.tier_id = mt.tier_id
                          WHERE br.status = 'borrowed' AND br.due_date < CURDATE()
                          ORDER BY br.due_date ASC");
while ($row = mysqli_fetch_assoc($r)) {
    $due = new DateTime($row['due_date']);
    $today = new DateTime();
    $row['days_overdue'] = $today->diff($due)->days;
    $row['potential_penalty'] = $row['days_overdue'] * $row['penalty_rate'];
    $overdue_list[] = $row;
}

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Dashboard Overview</h2>
            <p class="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Selamat datang, <?= htmlspecialchars($_SESSION['full_name'] ?? 'Admin') ?></p>
        </div>
        <div class="flex items-center gap-3">
            <span class="text-xs text-gray-400 dark:text-slate-500 hidden sm:inline"><?= date('d F Y') ?></span>
            <div class="relative">
                <button class="relative p-2 text-gray-400 dark:text-slate-400 hover:text-primary transition-colors rounded-lg hover:bg-gray-100 dark:hover:bg-[#293038]">
                    <span class="material-symbols-outlined">notifications</span>
                    <?php if ($stats['overdue'] > 0): ?>
                        <span class="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-accent-red rounded-full border-2 border-white dark:border-[#111418]"></span>
                    <?php endif; ?>
                </button>
            </div>
        </div>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Stats Cards Row (6 cards) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            <!-- Total Buku -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col justify-between min-h-[128px]">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Total Buku</p>
                        <h3 class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?= number_format($stats['total_books']) ?></h3>
                    </div>
                    <div class="p-2 bg-primary/10 rounded-lg text-primary">
                        <span class="material-symbols-outlined">library_books</span>
                    </div>
                </div>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-2">Buku aktif di perpustakaan</p>
            </div>

            <!-- Member Aktif -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col justify-between min-h-[128px]">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Member Aktif</p>
                        <h3 class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?= number_format($stats['total_members']) ?></h3>
                    </div>
                    <div class="p-2 bg-purple-500/10 rounded-lg text-purple-500">
                        <span class="material-symbols-outlined">group</span>
                    </div>
                </div>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-2">Anggota terdaftar</p>
            </div>

            <!-- Sedang Dipinjam -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col justify-between min-h-[128px]">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Sedang Dipinjam</p>
                        <h3 class="text-2xl font-bold text-gray-900 dark:text-white mt-1"><?= number_format($stats['active_borrows']) ?></h3>
                    </div>
                    <div class="p-2 bg-orange-500/10 rounded-lg text-orange-500">
                        <span class="material-symbols-outlined">outbox</span>
                    </div>
                </div>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-2">Peminjaman aktif</p>
            </div>

            <!-- Overdue -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-accent-red/30 shadow-sm shadow-accent-red/5 flex flex-col justify-between min-h-[128px] relative overflow-hidden">
                <div class="absolute right-0 top-0 w-16 h-16 bg-accent-red/10 rounded-bl-full -mr-2 -mt-2"></div>
                <div class="flex justify-between items-start relative z-10">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Overdue</p>
                        <h3 class="text-2xl font-bold text-accent-red mt-1"><?= number_format($stats['overdue']) ?></h3>
                    </div>
                    <div class="p-2 bg-accent-red/10 rounded-lg text-accent-red">
                        <span class="material-symbols-outlined">warning</span>
                    </div>
                </div>
                <p class="text-xs text-accent-red font-medium relative z-10 mt-2"><?= $stats['overdue'] > 0 ? 'Perlu tindakan' : 'Semua aman' ?></p>
            </div>

            <!-- Denda Belum Bayar -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col justify-between min-h-[128px]">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Denda Belum Bayar</p>
                        <h3 class="text-xl font-bold text-gray-900 dark:text-white mt-1"><?= formatRupiah($stats['unpaid_penalties']) ?></h3>
                    </div>
                    <div class="p-2 bg-yellow-500/10 rounded-lg text-yellow-500">
                        <span class="material-symbols-outlined">payments</span>
                    </div>
                </div>
                <p class="text-xs text-yellow-500 font-medium mt-2">Menunggu pembayaran</p>
            </div>

            <!-- Denda Terbayar -->
            <div class="bg-white dark:bg-[#1e293b] p-5 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col justify-between min-h-[128px]">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm font-medium text-gray-500 dark:text-slate-400">Denda Terbayar</p>
                        <h3 class="text-xl font-bold text-gray-900 dark:text-white mt-1"><?= formatRupiah($stats['paid_penalties']) ?></h3>
                    </div>
                    <div class="p-2 bg-green-500/10 rounded-lg text-green-500">
                        <span class="material-symbols-outlined">check_circle</span>
                    </div>
                </div>
                <p class="text-xs text-green-500 font-medium mt-2">Sudah lunas</p>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Peminjaman per Genre (Bar Chart) -->
            <div class="lg:col-span-7 xl:col-span-8 bg-white dark:bg-[#1e293b] p-6 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="text-lg font-bold text-gray-900 dark:text-white">Peminjaman per Genre</h3>
                        <p class="text-sm text-gray-500 dark:text-slate-400 mt-0.5">Statistik berdasarkan genre buku</p>
                    </div>
                    <span class="inline-flex items-center gap-1 rounded-lg bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary ring-1 ring-inset ring-primary/20">
                        <span class="material-symbols-outlined text-[14px]">bar_chart</span>
                        Genre
                    </span>
                </div>
                <?php if (empty($genre_stats)): ?>
                    <div class="flex flex-col items-center justify-center py-12 text-gray-400 dark:text-slate-500">
                        <span class="material-symbols-outlined text-5xl mb-3">insert_chart_outlined</span>
                        <p class="text-sm">Belum ada data peminjaman</p>
                    </div>
                <?php else: ?>
                    <?php
                    $max_count = max(array_column($genre_stats, 'count'));
                    $bar_colors = ['#1466b8', '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899', '#f43f5e', '#f97316', '#eab308'];
                    $color_idx = 0;
                    // FOREACH: Tampilkan bar chart sederhana
                    foreach ($genre_stats as $gs):
                        $percentage = $max_count > 0 ? ($gs['count'] / $max_count * 100) : 0;
                        $color = $bar_colors[$color_idx % count($bar_colors)];
                        $color_idx++;
                    ?>
                        <div class="mb-3 last:mb-0">
                            <div class="flex justify-between items-center mb-1.5">
                                <span class="text-sm font-medium text-gray-700 dark:text-slate-300"><?= htmlspecialchars($gs['genre_name']) ?></span>
                                <span class="text-sm font-bold text-gray-900 dark:text-white"><?= $gs['count'] ?></span>
                            </div>
                            <div class="w-full h-5 bg-gray-100 dark:bg-[#293038] rounded-full overflow-hidden">
                                <div class="h-full rounded-full transition-all duration-700 ease-out" style="width: <?= $percentage ?>%; background-color: <?= $color ?>;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Distribusi Member per Tier (Donut) -->
            <div class="lg:col-span-5 xl:col-span-4 bg-white dark:bg-[#1e293b] p-6 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-1">Distribusi Member per Tier</h3>
                <p class="text-sm text-gray-500 dark:text-slate-400 mb-6">Berdasarkan level keanggotaan</p>
                <?php if (empty($tier_stats)): ?>
                    <div class="flex-1 flex flex-col items-center justify-center text-gray-400 dark:text-slate-500">
                        <span class="material-symbols-outlined text-5xl mb-3">donut_large</span>
                        <p class="text-sm">Belum ada data member</p>
                    </div>
                <?php else: ?>
                    <?php
                    $total_members = array_sum(array_column($tier_stats, 'count'));
                    $tier_colors = [
                        'Free'    => ['hex' => '#6b7280', 'tw' => 'bg-gray-500'],
                        'Silver'  => ['hex' => '#06b6d4', 'tw' => 'bg-cyan-500'],
                        'Gold'    => ['hex' => '#eab308', 'tw' => 'bg-yellow-500'],
                        'Premium' => ['hex' => '#a855f7', 'tw' => 'bg-purple-500'],
                    ];
                    // Build donut segments
                    $cumulative = 0;
                    $segments = [];
                    foreach ($tier_stats as $ts) {
                        $pct = $total_members > 0 ? round(($ts['count'] / $total_members) * 100) : 0;
                        $color = $tier_colors[$ts['tier_name']]['hex'] ?? '#3b82f6';
                        $segments[] = ['name' => $ts['tier_name'], 'count' => $ts['count'], 'pct' => $pct, 'color' => $color, 'offset' => $cumulative];
                        $cumulative += $pct;
                    }
                    ?>
                    <div class="flex-1 flex items-center justify-center gap-8 flex-wrap">
                        <!-- Donut Chart (SVG) -->
                        <div class="relative w-40 h-40 shrink-0">
                            <svg class="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                                <path class="text-gray-100 dark:text-gray-700" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" stroke-width="4"></path>
                                <?php foreach ($segments as $seg): ?>
                                <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                      fill="none" stroke="<?= $seg['color'] ?>" stroke-width="4"
                                      stroke-dasharray="<?= $seg['pct'] ?>, 100"
                                      stroke-dashoffset="-<?= $seg['offset'] ?>"></path>
                                <?php endforeach; ?>
                            </svg>
                            <div class="absolute inset-0 flex items-center justify-center flex-col">
                                <span class="text-xl font-bold text-gray-900 dark:text-white"><?= $total_members ?></span>
                                <span class="text-[10px] text-gray-500 dark:text-slate-400 uppercase tracking-wider">Total</span>
                            </div>
                        </div>
                        <!-- Legend -->
                        <div class="flex flex-col gap-3 text-sm">
                            <?php foreach ($tier_stats as $ts):
                                $pct = $total_members > 0 ? round(($ts['count'] / $total_members) * 100) : 0;
                                $dot_color = $tier_colors[$ts['tier_name']]['tw'] ?? 'bg-blue-500';
                            ?>
                                <div class="flex items-center gap-2.5">
                                    <span class="w-3 h-3 rounded-full <?= $dot_color ?> shrink-0"></span>
                                    <span class="text-gray-600 dark:text-slate-400 min-w-[60px]"><?= htmlspecialchars($ts['tier_name']) ?></span>
                                    <span class="font-bold text-gray-900 dark:text-white"><?= $ts['count'] ?></span>
                                    <span class="text-gray-400 dark:text-slate-500 text-xs">(<?= $pct ?>%)</span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tables Row -->
        <div class="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <!-- Recent Borrowings Table -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden flex flex-col">
                <div class="p-5 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined text-primary text-[20px]">history</span>
                        <h3 class="text-base font-bold text-gray-900 dark:text-white">Peminjaman Terbaru</h3>
                    </div>
                    <a href="<?= BASE_URL ?>admin/borrowings.php" class="text-sm text-primary hover:text-blue-400 font-medium transition-colors inline-flex items-center gap-1">
                        Lihat Semua
                        <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
                    </a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm">
                        <thead class="bg-gray-50 dark:bg-[#293038] text-gray-500 dark:text-slate-400">
                            <tr>
                                <th class="px-5 py-3 font-medium">Member</th>
                                <th class="px-5 py-3 font-medium">Buku</th>
                                <th class="px-5 py-3 font-medium">Tanggal</th>
                                <th class="px-5 py-3 font-medium">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700 text-gray-700 dark:text-gray-300">
                            <?php if (empty($recent_borrows)): ?>
                                <tr>
                                    <td colspan="4" class="px-5 py-10 text-center text-gray-400 dark:text-slate-500">
                                        <span class="material-symbols-outlined text-4xl block mb-2">inbox</span>
                                        <p class="text-sm">Belum ada data peminjaman</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_borrows as $rb): ?>
                                    <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                        <td class="px-5 py-3.5">
                                            <div class="flex items-center gap-2.5">
                                                <div class="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                                                    <?= strtoupper(substr($rb['full_name'], 0, 1)) ?>
                                                </div>
                                                <span class="font-medium text-gray-900 dark:text-white text-sm"><?= htmlspecialchars($rb['full_name']) ?></span>
                                            </div>
                                        </td>
                                        <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400 text-sm max-w-[200px] truncate"><?= htmlspecialchars(substr($rb['title'], 0, 30)) ?></td>
                                        <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400 text-sm"><?= formatDate($rb['borrow_date']) ?></td>
                                        <td class="px-5 py-3.5">
                                            <?php if ($rb['status'] === 'borrowed'): ?>
                                                <span class="inline-flex items-center rounded-full bg-blue-100 dark:bg-blue-900/30 px-2.5 py-1 text-xs font-medium text-blue-700 dark:text-blue-400">Aktif</span>
                                            <?php elseif ($rb['status'] === 'returned'): ?>
                                                <span class="inline-flex items-center rounded-full bg-green-100 dark:bg-green-900/30 px-2.5 py-1 text-xs font-medium text-green-700 dark:text-green-400">Kembali</span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center rounded-full bg-red-100 dark:bg-red-900/30 px-2.5 py-1 text-xs font-medium text-red-700 dark:text-red-400">Overdue</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Overdue Alerts -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden flex flex-col">
                <div class="p-5 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center bg-red-50/50 dark:bg-red-900/10">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined text-accent-red text-[20px]">warning</span>
                        <h3 class="text-base font-bold text-gray-900 dark:text-white">Daftar Overdue</h3>
                    </div>
                    <span class="bg-accent-red text-white text-xs font-bold px-2.5 py-1 rounded-full"><?= count($overdue_list) ?> Item</span>
                </div>

                <?php if (empty($overdue_list)): ?>
                    <div class="flex-1 flex flex-col items-center justify-center py-12">
                        <div class="w-14 h-14 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mb-3">
                            <span class="material-symbols-outlined text-green-600 dark:text-green-400 text-3xl">check_circle</span>
                        </div>
                        <p class="text-sm font-medium text-gray-700 dark:text-slate-300">Tidak ada buku terlambat</p>
                        <p class="text-xs text-gray-400 dark:text-slate-500 mt-1">Semua peminjaman tepat waktu</p>
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm">
                            <thead class="bg-gray-50 dark:bg-[#293038] text-gray-500 dark:text-slate-400">
                                <tr>
                                    <th class="px-5 py-3 font-medium">Member</th>
                                    <th class="px-5 py-3 font-medium">Buku</th>
                                    <th class="px-5 py-3 font-medium">Terlambat</th>
                                    <th class="px-5 py-3 font-medium">Potensi Denda</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700 text-gray-700 dark:text-gray-300">
                                <?php
                                // FOREACH: Tampilkan overdue dengan perhitungan denda
                                foreach ($overdue_list as $od):
                                ?>
                                    <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                        <td class="px-5 py-3.5">
                                            <div>
                                                <span class="font-medium text-gray-900 dark:text-white text-sm"><?= htmlspecialchars($od['full_name']) ?></span>
                                                <span class="inline-flex items-center rounded-full bg-gray-100 dark:bg-gray-700/50 px-2 py-0.5 text-[10px] font-medium text-gray-600 dark:text-gray-300 ml-1.5"><?= htmlspecialchars($od['tier_name']) ?></span>
                                            </div>
                                        </td>
                                        <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400 text-sm max-w-[180px] truncate"><?= htmlspecialchars(substr($od['title'], 0, 35)) ?></td>
                                        <td class="px-5 py-3.5">
                                            <span class="inline-flex items-center gap-1 rounded-full bg-red-100 dark:bg-red-900/30 px-2.5 py-1 text-xs font-semibold text-red-700 dark:text-red-400">
                                                <span class="material-symbols-outlined text-[12px]">schedule</span>
                                                <?= $od['days_overdue'] ?> hari
                                            </span>
                                        </td>
                                        <td class="px-5 py-3.5 text-accent-red font-bold text-sm"><?= formatRupiah($od['potential_penalty']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div><!-- end scrollable content -->
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
