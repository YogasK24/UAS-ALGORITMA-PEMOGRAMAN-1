<?php
/**
 * Admin - Kelola Buku - BookHaven Digital Library
 * CRUD buku dengan genre management
 * ALGORITMA: FOREACH, IF-ELSE, ARRAY MULTIDIMENSI
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$page_title = 'Kelola Buku';

// =============================================
// PROSES TAMBAH / EDIT / HAPUS BUKU
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tambah Buku
    if (isset($_POST['add_book'])) {
        $title = sanitize($_POST['title']);
        $isbn = sanitize($_POST['isbn']);
        $author_id = intval($_POST['author_id']);
        $publisher_id = intval($_POST['publisher_id']);
        $year = intval($_POST['year_published']);
        $pages = intval($_POST['pages']);
        $language = sanitize($_POST['language']);
        $synopsis = sanitize($_POST['synopsis']);
        $total_copies = intval($_POST['total_copies']);
        $genres = $_POST['genres'] ?? [];

        // Upload cover atau URL
        $cover_name = '';
        // Prioritas: URL > File Upload
        if (!empty($_POST['cover_url'])) {
            // Simpan URL langsung ke database
            $cover_name = sanitize($_POST['cover_url']);
        } elseif (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === 0) {
            $ext = pathinfo($_FILES['cover_image']['name'], PATHINFO_EXTENSION);
            $cover_name = 'cover_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['cover_image']['tmp_name'], __DIR__ . '/../uploads/covers/' . $cover_name);
        }

        $sql = "INSERT INTO books (isbn, title, author_id, publisher_id, year_published, pages, language, synopsis, cover_image, total_copies, available_copies) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssiiiisssis", $isbn, $title, $author_id, $publisher_id, $year, $pages, $language, $synopsis, $cover_name, $total_copies, $total_copies);
        
        if (mysqli_stmt_execute($stmt)) {
            $new_book_id = mysqli_insert_id($conn);
            // FOREACH: Insert genre relasi
            foreach ($genres as $genre_id) {
                $gid = intval($genre_id);
                $sql = "INSERT IGNORE INTO book_genres (book_id, genre_id) VALUES (?, ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ii", $new_book_id, $gid);
                mysqli_stmt_execute($stmt);
            }
            setFlash('success', 'Buku berhasil ditambahkan!');
        } else {
            setFlash('danger', 'Gagal menambahkan buku');
        }
        header("Location: " . BASE_URL . "admin/books.php");
        exit;
    }

    // Edit Buku
    if (isset($_POST['edit_book'])) {
        $book_id = intval($_POST['book_id']);
        $title = sanitize($_POST['title']);
        $isbn = sanitize($_POST['isbn']);
        $author_id = intval($_POST['author_id']);
        $publisher_id = intval($_POST['publisher_id']);
        $year = intval($_POST['year_published']);
        $pages = intval($_POST['pages']);
        $language = sanitize($_POST['language']);
        $synopsis = sanitize($_POST['synopsis']);
        $total_copies = intval($_POST['total_copies']);
        $genres = $_POST['genres'] ?? [];

        // Update cover jika ada URL atau file baru
        $cover_update = '';
        $cover_params = '';
        if (!empty($_POST['cover_url'])) {
            $cover_update = ', cover_image=?';
            $cover_value = sanitize($_POST['cover_url']);
        } elseif (isset($_FILES['cover_image_edit']) && $_FILES['cover_image_edit']['error'] === 0) {
            $ext = pathinfo($_FILES['cover_image_edit']['name'], PATHINFO_EXTENSION);
            $cover_value = 'cover_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['cover_image_edit']['tmp_name'], __DIR__ . '/../uploads/covers/' . $cover_value);
            $cover_update = ', cover_image=?';
        }

        if ($cover_update) {
            $sql = "UPDATE books SET isbn=?, title=?, author_id=?, publisher_id=?, year_published=?, pages=?, language=?, synopsis=?, total_copies=?{$cover_update} WHERE book_id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssiiiissi" . "s" . "i", $isbn, $title, $author_id, $publisher_id, $year, $pages, $language, $synopsis, $total_copies, $cover_value, $book_id);
        } else {
            $sql = "UPDATE books SET isbn=?, title=?, author_id=?, publisher_id=?, year_published=?, pages=?, language=?, synopsis=?, total_copies=? WHERE book_id=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssiiiissii", $isbn, $title, $author_id, $publisher_id, $year, $pages, $language, $synopsis, $total_copies, $book_id);
        }
        
        if (mysqli_stmt_execute($stmt)) {
            // Update genres: hapus lama, insert baru
            mysqli_query($conn, "DELETE FROM book_genres WHERE book_id = $book_id");
            foreach ($genres as $genre_id) {
                $gid = intval($genre_id);
                $sql = "INSERT IGNORE INTO book_genres (book_id, genre_id) VALUES (?, ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ii", $book_id, $gid);
                mysqli_stmt_execute($stmt);
            }
            setFlash('success', 'Buku berhasil diperbarui!');
        }
        header("Location: " . BASE_URL . "admin/books.php");
        exit;
    }

    // Hapus Buku (soft delete)
    if (isset($_POST['delete_book'])) {
        $book_id = intval($_POST['book_id']);
        $sql = "UPDATE books SET is_active = 0 WHERE book_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $book_id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Buku berhasil dihapus');
        header("Location: " . BASE_URL . "admin/books.php");
        exit;
    }
}

// Query semua buku
$sql = "SELECT b.*, a.author_name, p.publisher_name 
        FROM books b
        LEFT JOIN authors a ON b.author_id = a.author_id
        LEFT JOIN publishers p ON b.publisher_id = p.publisher_id
        WHERE b.is_active = 1
        ORDER BY b.created_at DESC";
$result = mysqli_query($conn, $sql);
$books = [];
while ($row = mysqli_fetch_assoc($result)) {
    $row['genres'] = getBookGenres($row['book_id'], $conn);
    $books[] = $row;
}

// Data untuk form
$authors = [];
$r = mysqli_query($conn, "SELECT * FROM authors ORDER BY author_name");
while ($row = mysqli_fetch_assoc($r)) $authors[] = $row;

$publishers = [];
$r = mysqli_query($conn, "SELECT * FROM publishers ORDER BY publisher_name");
while ($row = mysqli_fetch_assoc($r)) $publishers[] = $row;

$all_genres = [];
$r = mysqli_query($conn, "SELECT * FROM genres ORDER BY genre_name");
while ($row = mysqli_fetch_assoc($r)) $all_genres[] = $row;

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Manajemen Buku</h2>
            <div class="flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400 mt-0.5">
                <a href="<?= BASE_URL ?>admin/index.php" class="hover:text-primary transition-colors">Dashboard</a>
                <span class="material-symbols-outlined text-[12px]">chevron_right</span>
                <span class="text-gray-900 dark:text-white font-medium">Buku</span>
            </div>
        </div>
        <button onclick="openModal('addBookModal')" class="inline-flex items-center gap-2 bg-primary hover:bg-blue-700 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-sm shadow-primary/20 transition-colors">
            <span class="material-symbols-outlined text-[18px]">add_circle</span>
            Tambah Buku
        </button>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Summary Bar -->
        <div class="flex items-center gap-4 flex-wrap">
            <div class="inline-flex items-center gap-2 bg-white dark:bg-[#1e293b] border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2.5 text-sm">
                <span class="material-symbols-outlined text-primary text-[18px]">inventory_2</span>
                <span class="text-gray-500 dark:text-slate-400">Total:</span>
                <span class="font-bold text-gray-900 dark:text-white"><?= count($books) ?> buku</span>
            </div>
        </div>

        <!-- Books Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                    <thead class="bg-gray-50 dark:bg-[#293038] text-gray-500 dark:text-slate-400">
                        <tr>
                            <th class="px-5 py-3.5 font-medium w-12">#</th>
                            <th class="px-5 py-3.5 font-medium">ISBN</th>
                            <th class="px-5 py-3.5 font-medium">Judul</th>
                            <th class="px-5 py-3.5 font-medium">Penulis</th>
                            <th class="px-5 py-3.5 font-medium">Genre</th>
                            <th class="px-5 py-3.5 font-medium">Tahun</th>
                            <th class="px-5 py-3.5 font-medium">Stok</th>
                            <th class="px-5 py-3.5 font-medium">Rating</th>
                            <th class="px-5 py-3.5 font-medium">Dipinjam</th>
                            <th class="px-5 py-3.5 font-medium text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700 text-gray-700 dark:text-gray-300">
                        <?php if (empty($books)): ?>
                            <tr>
                                <td colspan="10" class="px-5 py-12 text-center text-gray-400 dark:text-slate-500">
                                    <span class="material-symbols-outlined text-5xl block mb-3">library_books</span>
                                    <p class="text-sm font-medium">Belum ada buku</p>
                                    <p class="text-xs mt-1">Klik tombol "Tambah Buku" untuk menambahkan</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php
                            $no = 1;
                            foreach ($books as $book):
                            ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                    <td class="px-5 py-3.5 text-gray-400 dark:text-slate-500 font-medium"><?= $no++ ?></td>
                                    <td class="px-5 py-3.5">
                                        <span class="font-mono text-xs text-gray-500 dark:text-slate-400 bg-gray-100 dark:bg-[#293038] px-2 py-1 rounded"><?= $book['isbn'] ?: '-' ?></span>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <span class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars(substr($book['title'], 0, 40)) ?></span>
                                    </td>
                                    <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400"><?= htmlspecialchars($book['author_name'] ?? '-') ?></td>
                                    <td class="px-5 py-3.5">
                                        <div class="flex flex-wrap gap-1">
                                            <?php foreach ($book['genres'] as $g): ?>
                                                <span class="inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium <?= getGenreBadgeClass($g['genre_name']) ?>"><?= htmlspecialchars($g['genre_name']) ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400"><?= $book['year_published'] ?></td>
                                    <td class="px-5 py-3.5">
                                        <?php
                                        $stock_pct = $book['total_copies'] > 0 ? ($book['available_copies'] / $book['total_copies']) * 100 : 0;
                                        $stock_color = $stock_pct > 50 ? 'text-green-600 dark:text-green-400' : ($stock_pct > 0 ? 'text-yellow-600 dark:text-yellow-400' : 'text-red-600 dark:text-red-400');
                                        ?>
                                        <span class="font-semibold <?= $stock_color ?>"><?= $book['available_copies'] ?></span>
                                        <span class="text-gray-400 dark:text-slate-500">/<?= $book['total_copies'] ?></span>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <div class="flex items-center gap-1">
                                            <span class="material-symbols-outlined text-yellow-500 text-[16px]">star</span>
                                            <span class="font-medium text-gray-900 dark:text-white"><?= number_format($book['rating_avg'], 1) ?></span>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <span class="inline-flex items-center gap-1 text-gray-600 dark:text-slate-300">
                                            <span class="material-symbols-outlined text-[14px]">swap_horiz</span>
                                            <?= $book['total_borrowed'] ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <div class="flex items-center justify-center gap-1.5">
                                            <!-- View -->
                                            <a href="<?= BASE_URL ?>book_detail.php?id=<?= $book['book_id'] ?>"
                                               class="p-1.5 rounded-lg text-gray-400 dark:text-slate-500 hover:text-primary hover:bg-primary/10 transition-all" title="Detail">
                                                <span class="material-symbols-outlined text-[18px]">visibility</span>
                                            </a>
                                            <!-- Edit -->
                                            <button class="edit-book-btn p-1.5 rounded-lg text-gray-400 dark:text-slate-500 hover:text-yellow-500 hover:bg-yellow-500/10 transition-all"
                                                    data-book='<?= htmlspecialchars(json_encode($book)) ?>' title="Edit">
                                                <span class="material-symbols-outlined text-[18px]">edit</span>
                                            </button>
                                            <!-- Delete -->
                                            <form method="POST" class="inline">
                                                <input type="hidden" name="book_id" value="<?= $book['book_id'] ?>">
                                                <input type="hidden" name="delete_book" value="1">
                                                <button type="submit"
                                                        class="p-1.5 rounded-lg text-gray-400 dark:text-slate-500 hover:text-accent-red hover:bg-accent-red/10 transition-all"
                                                        onclick="return confirm('Hapus buku ini?')" title="Hapus">
                                                    <span class="material-symbols-outlined text-[18px]">delete</span>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div><!-- end scrollable content -->
</main>

<!-- ============================== -->
<!-- Add Book Modal -->
<!-- ============================== -->
<div id="addBookModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto border border-gray-200 dark:border-gray-700 mx-4">
        <form method="POST" enctype="multipart/form-data">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700 sticky top-0 bg-white dark:bg-[#1e293b] z-10">
                <div class="flex items-center gap-3">
                    <div class="p-2 bg-primary/10 rounded-lg text-primary">
                        <span class="material-symbols-outlined">add_circle</span>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-gray-900 dark:text-white">Tambah Buku Baru</h3>
                        <p class="text-xs text-gray-500 dark:text-slate-400">Isi data buku yang ingin ditambahkan</p>
                    </div>
                </div>
                <button type="button" onclick="closeModal('addBookModal')" class="p-2 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-[#293038] transition-all">
                    <span class="material-symbols-outlined">close</span>
                </button>
            </div>

            <!-- Modal Body -->
            <div class="px-6 py-5">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Judul -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Judul Buku <span class="text-accent-red">*</span></label>
                        <input type="text" name="title" required
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                               placeholder="Masukkan judul buku">
                    </div>
                    <!-- ISBN -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">ISBN</label>
                        <input type="text" name="isbn"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                               placeholder="978-xxx-xxx">
                    </div>
                    <!-- Penulis -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Penulis</label>
                        <select name="author_id"
                                class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                            <option value="0">-- Pilih Penulis --</option>
                            <?php foreach ($authors as $a): ?>
                                <option value="<?= $a['author_id'] ?>"><?= htmlspecialchars($a['author_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- Penerbit -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Penerbit</label>
                        <select name="publisher_id"
                                class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                            <option value="0">-- Pilih Penerbit --</option>
                            <?php foreach ($publishers as $p): ?>
                                <option value="<?= $p['publisher_id'] ?>"><?= htmlspecialchars($p['publisher_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- Tahun Terbit -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Tahun Terbit</label>
                        <input type="number" name="year_published" min="1900" max="<?= date('Y') ?>"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                               placeholder="<?= date('Y') ?>">
                    </div>
                    <!-- Jumlah Halaman -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Jumlah Halaman</label>
                        <input type="number" name="pages" min="1"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                               placeholder="0">
                    </div>
                    <!-- Total Stok -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Total Stok</label>
                        <input type="number" name="total_copies" min="1" value="1"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- Bahasa -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Bahasa</label>
                        <input type="text" name="language" value="Indonesian"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- Cover Image -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Cover Image</label>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <!-- URL Input -->
                            <div>
                                <label class="block text-xs text-gray-500 dark:text-slate-400 mb-1">URL Gambar (prioritas)</label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 -translate-y-1/2 material-symbols-outlined text-gray-400 text-[18px]">link</span>
                                    <input type="url" name="cover_url" 
                                           class="w-full pl-10 pr-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                                           placeholder="https://covers.openlibrary.org/b/id/...">
                                </div>
                            </div>
                            <!-- File Upload -->
                            <div>
                                <label class="block text-xs text-gray-500 dark:text-slate-400 mb-1">Atau Upload File</label>
                                <input type="file" name="cover_image" accept="image/*"
                                       class="w-full px-3.5 py-2 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-medium file:bg-primary/10 file:text-primary hover:file:bg-primary/20 transition-all">
                            </div>
                        </div>
                        <p class="text-[11px] text-gray-400 dark:text-slate-500 mt-1.5">Jika URL diisi, file upload diabaikan. Gunakan URL dari Open Library, Google Books, dll.</p>
                    </div>
                    <!-- Genre -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-2">Genre</label>
                        <div class="flex flex-wrap gap-3 p-4 bg-gray-50 dark:bg-[#293038] rounded-xl border border-gray-200 dark:border-gray-600">
                            <?php foreach ($all_genres as $g): ?>
                                <label class="inline-flex items-center gap-2 cursor-pointer group">
                                    <input type="checkbox" name="genres[]" value="<?= $g['genre_id'] ?>"
                                           class="w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-primary focus:ring-primary/50 bg-white dark:bg-[#1e293b]">
                                    <span class="text-sm text-gray-600 dark:text-slate-400 group-hover:text-gray-900 dark:group-hover:text-white transition-colors"><?= htmlspecialchars($g['genre_name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <!-- Sinopsis -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Sinopsis</label>
                        <textarea name="synopsis" rows="3"
                                  class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all resize-none"
                                  placeholder="Tulis sinopsis buku..."></textarea>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700 sticky bottom-0 bg-white dark:bg-[#1e293b]">
                <button type="button" onclick="closeModal('addBookModal')"
                        class="px-5 py-2.5 text-sm font-medium text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-[#293038] hover:bg-gray-200 dark:hover:bg-[#374151] rounded-xl border border-gray-300 dark:border-gray-600 transition-colors">
                    Batal
                </button>
                <button type="submit" name="add_book"
                        class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-primary hover:bg-blue-700 rounded-xl shadow-sm shadow-primary/20 transition-colors">
                    <span class="material-symbols-outlined text-[18px]">save</span>
                    Simpan Buku
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ============================== -->
<!-- Edit Book Modal -->
<!-- ============================== -->
<div id="editBookModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto border border-gray-200 dark:border-gray-700 mx-4">
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="book_id" id="edit_book_id">

            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700 sticky top-0 bg-white dark:bg-[#1e293b] z-10">
                <div class="flex items-center gap-3">
                    <div class="p-2 bg-yellow-500/10 rounded-lg text-yellow-500">
                        <span class="material-symbols-outlined">edit</span>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-gray-900 dark:text-white">Edit Buku</h3>
                        <p class="text-xs text-gray-500 dark:text-slate-400">Perbarui informasi buku</p>
                    </div>
                </div>
                <button type="button" onclick="closeModal('editBookModal')" class="p-2 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-[#293038] transition-all">
                    <span class="material-symbols-outlined">close</span>
                </button>
            </div>

            <!-- Modal Body -->
            <div class="px-6 py-5">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <!-- Judul -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Judul Buku <span class="text-accent-red">*</span></label>
                        <input type="text" name="title" id="edit_title" required
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- ISBN -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">ISBN</label>
                        <input type="text" name="isbn" id="edit_isbn"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- Penulis -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Penulis</label>
                        <select name="author_id" id="edit_author_id"
                                class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                            <option value="0">-- Pilih --</option>
                            <?php foreach ($authors as $a): ?>
                                <option value="<?= $a['author_id'] ?>"><?= htmlspecialchars($a['author_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- Penerbit -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Penerbit</label>
                        <select name="publisher_id" id="edit_publisher_id"
                                class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                            <option value="0">-- Pilih --</option>
                            <?php foreach ($publishers as $p): ?>
                                <option value="<?= $p['publisher_id'] ?>"><?= htmlspecialchars($p['publisher_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- Tahun -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Tahun</label>
                        <input type="number" name="year_published" id="edit_year"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- Halaman -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Halaman</label>
                        <input type="number" name="pages" id="edit_pages"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- Total Stok -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Total Stok</label>
                        <input type="number" name="total_copies" id="edit_copies" min="1"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- Bahasa -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Bahasa</label>
                        <input type="text" name="language" id="edit_language"
                               class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all">
                    </div>
                    <!-- Cover Image -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Cover Image</label>
                        <!-- Current cover preview -->
                        <div id="edit_cover_preview" class="mb-3 hidden">
                            <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-[#293038] rounded-xl border border-gray-200 dark:border-gray-600">
                                <img id="edit_cover_img" src="" alt="Current cover" class="w-12 h-16 rounded-lg object-cover shadow-sm">
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-gray-500 dark:text-slate-400">Cover saat ini</p>
                                    <p id="edit_cover_text" class="text-xs text-gray-700 dark:text-slate-300 truncate"></p>
                                </div>
                                <button type="button" onclick="document.getElementById('edit_cover_url').value=''; document.getElementById('edit_cover_preview').classList.add('hidden');" class="p-1 text-gray-400 hover:text-red-400 transition-colors" title="Hapus cover">
                                    <span class="material-symbols-outlined text-[16px]">close</span>
                                </button>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs text-gray-500 dark:text-slate-400 mb-1">URL Gambar (prioritas)</label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 -translate-y-1/2 material-symbols-outlined text-gray-400 text-[18px]">link</span>
                                    <input type="url" name="cover_url" id="edit_cover_url"
                                           class="w-full pl-10 pr-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                                           placeholder="https://covers.openlibrary.org/b/id/...">
                                </div>
                            </div>
                            <div>
                                <label class="block text-xs text-gray-500 dark:text-slate-400 mb-1">Atau Upload File Baru</label>
                                <input type="file" name="cover_image_edit" accept="image/*"
                                       class="w-full px-3.5 py-2 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-medium file:bg-primary/10 file:text-primary hover:file:bg-primary/20 transition-all">
                            </div>
                        </div>
                        <p class="text-[11px] text-gray-400 dark:text-slate-500 mt-1.5">Kosongkan jika tidak ingin mengubah cover. Jika URL diisi, file upload diabaikan.</p>
                    </div>
                    <!-- Genre -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-2">Genre</label>
                        <div class="flex flex-wrap gap-3 p-4 bg-gray-50 dark:bg-[#293038] rounded-xl border border-gray-200 dark:border-gray-600" id="edit_genres_container">
                            <?php foreach ($all_genres as $g): ?>
                                <label class="inline-flex items-center gap-2 cursor-pointer group">
                                    <input type="checkbox" name="genres[]" value="<?= $g['genre_id'] ?>"
                                           class="edit-genre-check w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-primary focus:ring-primary/50 bg-white dark:bg-[#1e293b]"
                                           data-genre-id="<?= $g['genre_id'] ?>">
                                    <span class="text-sm text-gray-600 dark:text-slate-400 group-hover:text-gray-900 dark:group-hover:text-white transition-colors"><?= htmlspecialchars($g['genre_name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <!-- Sinopsis -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Sinopsis</label>
                        <textarea name="synopsis" id="edit_synopsis" rows="3"
                                  class="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-[#293038] border border-gray-300 dark:border-gray-600 rounded-xl text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all resize-none"></textarea>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700 sticky bottom-0 bg-white dark:bg-[#1e293b]">
                <button type="button" onclick="closeModal('editBookModal')"
                        class="px-5 py-2.5 text-sm font-medium text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-[#293038] hover:bg-gray-200 dark:hover:bg-[#374151] rounded-xl border border-gray-300 dark:border-gray-600 transition-colors">
                    Batal
                </button>
                <button type="submit" name="edit_book"
                        class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-yellow-500 hover:bg-yellow-600 rounded-xl shadow-sm shadow-yellow-500/20 transition-colors">
                    <span class="material-symbols-outlined text-[18px]">check_circle</span>
                    Update Buku
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// ============================
// Modal open / close helpers
// ============================
function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}
function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = '';
    }
}

// Close modal on backdrop click
document.querySelectorAll('[data-modal]').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal(this.id);
        }
    });
});

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('[data-modal]:not(.hidden)').forEach(modal => {
            closeModal(modal.id);
        });
    }
});

// ============================
// Populate edit modal on click
// ============================
document.querySelectorAll('.edit-book-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const book = JSON.parse(this.dataset.book);
        document.getElementById('edit_book_id').value = book.book_id;
        document.getElementById('edit_title').value = book.title;
        document.getElementById('edit_isbn').value = book.isbn || '';
        document.getElementById('edit_author_id').value = book.author_id || 0;
        document.getElementById('edit_publisher_id').value = book.publisher_id || 0;
        document.getElementById('edit_year').value = book.year_published || '';
        document.getElementById('edit_pages').value = book.pages || '';
        document.getElementById('edit_copies').value = book.total_copies || 1;
        document.getElementById('edit_language').value = book.language || 'Indonesian';
        document.getElementById('edit_synopsis').value = book.synopsis || '';

        // Cover URL / preview
        const coverPreview = document.getElementById('edit_cover_preview');
        const coverImg = document.getElementById('edit_cover_img');
        const coverText = document.getElementById('edit_cover_text');
        const coverUrlInput = document.getElementById('edit_cover_url');
        if (book.cover_image) {
            const isUrl = /^https?:\/\//i.test(book.cover_image);
            const imgSrc = isUrl ? book.cover_image : '<?= BASE_URL ?>uploads/covers/' + book.cover_image;
            coverImg.src = imgSrc;
            coverText.textContent = isUrl ? book.cover_image : book.cover_image;
            coverUrlInput.value = isUrl ? book.cover_image : '';
            coverPreview.classList.remove('hidden');
        } else {
            coverPreview.classList.add('hidden');
            coverUrlInput.value = '';
        }

        // Uncheck all, then check matching genres
        document.querySelectorAll('.edit-genre-check').forEach(cb => cb.checked = false);
        if (book.genres) {
            book.genres.forEach(g => {
                const cb = document.querySelector(`.edit-genre-check[data-genre-id="${g.genre_id}"]`);
                if (cb) cb.checked = true;
            });
        }

        openModal('editBookModal');
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
