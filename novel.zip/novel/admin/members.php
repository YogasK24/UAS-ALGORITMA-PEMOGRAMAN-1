<?php
/**
 * Admin - Kelola Member - BookHaven Digital Library
 * Mengelola data anggota perpustakaan
 * Algoritma: foreach, if-else, switch-case
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$page_title = 'Kelola Member';

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['toggle_status'])) {
        $uid = intval($_POST['user_id']);
        $new_status = $_POST['current_status'] === 'active' ? 'suspended' : 'active';
        $stmt = mysqli_prepare($conn, "UPDATE users SET status = ? WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, "si", $new_status, $uid);
        mysqli_stmt_execute($stmt);
        setFlash('success', "Status member berhasil diubah menjadi $new_status");
        header("Location: " . BASE_URL . "admin/members.php"); exit;
    }
    if (isset($_POST['change_tier'])) {
        $uid = intval($_POST['user_id']);
        $tier = intval($_POST['tier_id']);
        $stmt = mysqli_prepare($conn, "UPDATE users SET tier_id = ? WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, "ii", $tier, $uid);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Tier member berhasil diubah');
        header("Location: " . BASE_URL . "admin/members.php"); exit;
    }
}

// Filter
$search = $_GET['search'] ?? '';
$filter_tier = $_GET['tier'] ?? 'all';
$page = max(1, intval($_GET['page'] ?? 1));

$where = ["u.role = 'member'"];
$params = [];
$types = '';

if (!empty($search)) {
    $where[] = "(u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
    $s = "%$search%";
    $params = array_merge($params, [$s, $s, $s]);
    $types .= 'sss';
}
if ($filter_tier !== 'all') {
    $where[] = "u.tier_id = ?";
    $params[] = intval($filter_tier);
    $types .= 'i';
}

$where_sql = 'WHERE ' . implode(' AND ', $where);

// Count
$csql = "SELECT COUNT(*) as total FROM users u $where_sql";
$cstmt = mysqli_prepare($conn, $csql);
if (!empty($params)) mysqli_stmt_bind_param($cstmt, $types, ...$params);
mysqli_stmt_execute($cstmt);
$total = mysqli_fetch_assoc(mysqli_stmt_get_result($cstmt))['total'];
$total_pages = ceil($total / ITEMS_PER_PAGE);
$offset = ($page - 1) * ITEMS_PER_PAGE;

// Fetch members with stats
$sql = "SELECT u.*,
        (SELECT COUNT(*) FROM borrowings WHERE user_id = u.user_id AND status = 'borrowed') as active_borrows,
        (SELECT COUNT(*) FROM borrowings WHERE user_id = u.user_id) as total_borrows,
        (SELECT COALESCE(SUM(penalty_amount), 0) FROM penalties WHERE user_id = u.user_id AND penalty_status = 'unpaid') as unpaid_penalties
        FROM users u $where_sql
        ORDER BY u.created_at DESC LIMIT ? OFFSET ?";
$stmt = mysqli_prepare($conn, $sql);
$all_params = array_merge($params, [ITEMS_PER_PAGE, $offset]);
$all_types = $types . 'ii';
mysqli_stmt_bind_param($stmt, $all_types, ...$all_params);
mysqli_stmt_execute($stmt);
$members = [];
$result = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($result)) $members[] = $row;

// Tier names array - demonstrating multidimensional array
$tiers = [
    1 => ['name' => 'Free', 'color' => 'secondary', 'icon' => 'star'],
    2 => ['name' => 'Silver', 'color' => 'info', 'icon' => 'star_half'],
    3 => ['name' => 'Gold', 'color' => 'warning', 'icon' => 'star'],
    4 => ['name' => 'Premium', 'color' => 'danger', 'icon' => 'diamond'],
];

// Tailwind color maps for tiers
$tier_tw = [
    1 => ['bg' => 'bg-gray-100 dark:bg-gray-800', 'text' => 'text-gray-600 dark:text-gray-400'],
    2 => ['bg' => 'bg-slate-100 dark:bg-slate-700/40', 'text' => 'text-slate-600 dark:text-slate-300'],
    3 => ['bg' => 'bg-yellow-100 dark:bg-yellow-900/30', 'text' => 'text-yellow-700 dark:text-yellow-400'],
    4 => ['bg' => 'bg-purple-100 dark:bg-purple-900/30', 'text' => 'text-purple-700 dark:text-purple-400'],
];

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span class="material-symbols-outlined text-primary">group</span>
                Kelola Member
            </h2>
            <p class="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Kelola data anggota perpustakaan</p>
        </div>
        <div class="flex items-center gap-2">
            <span class="text-xs text-gray-400 dark:text-slate-500 hidden sm:inline">Total: <span class="font-semibold text-gray-700 dark:text-slate-300"><?= $total ?></span> member</span>
        </div>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Filter Card -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5">
            <form method="GET" class="flex flex-col md:flex-row gap-4 items-end">
                <div class="flex-1 min-w-0">
                    <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Cari Member</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500 text-[20px]">search</span>
                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                               placeholder="Nama, username, atau email..."
                               class="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-colors">
                    </div>
                </div>
                <div class="w-full md:w-48">
                    <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Tier</label>
                    <select name="tier" class="w-full py-2.5 px-3 bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-colors">
                        <option value="all">Semua Tier</option>
                        <?php foreach ($tiers as $tid => $t): ?>
                        <option value="<?= $tid ?>" <?= $filter_tier == $tid ? 'selected' : '' ?>><?= $t['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-primary/90 text-white text-sm font-medium rounded-lg transition-colors">
                        <span class="material-symbols-outlined text-[18px]">filter_alt</span>
                        Filter
                    </button>
                    <a href="<?= BASE_URL ?>admin/members.php" class="inline-flex items-center gap-2 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-[#293038] text-sm font-medium rounded-lg transition-colors">
                        <span class="material-symbols-outlined text-[18px]">restart_alt</span>
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-[#293038] border-b border-gray-200 dark:border-gray-700">
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">#</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Member</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Email</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Tier</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Pinjaman Aktif</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Total Pinjam</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Denda</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Status</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700/50">
                        <?php $no = $offset + 1; foreach ($members as $m): ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                            <td class="px-4 py-3 text-gray-500 dark:text-slate-400"><?= $no++ ?></td>
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                                        <?= strtoupper(substr($m['full_name'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <p class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($m['full_name']) ?></p>
                                        <p class="text-xs text-gray-400 dark:text-slate-500">@<?= htmlspecialchars($m['username']) ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-gray-600 dark:text-slate-400"><?= htmlspecialchars($m['email']) ?></td>
                            <td class="px-4 py-3">
                                <?php
                                    $t = $tiers[$m['tier_id']] ?? $tiers[1];
                                    $ttw = $tier_tw[$m['tier_id']] ?? $tier_tw[1];
                                ?>
                                <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold <?= $ttw['bg'] ?> <?= $ttw['text'] ?>">
                                    <span class="material-symbols-outlined text-[14px]" style="font-variation-settings:'FILL' 1"><?= $t['icon'] ?></span>
                                    <?= $t['name'] ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-center">
                                <span class="inline-flex items-center justify-center min-w-[24px] px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400">
                                    <?= $m['active_borrows'] ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-center text-gray-700 dark:text-slate-300 font-medium"><?= $m['total_borrows'] ?></td>
                            <td class="px-4 py-3">
                                <?php if ($m['unpaid_penalties'] > 0): ?>
                                    <span class="text-red-600 dark:text-red-400 font-semibold text-xs"><?= formatRupiah($m['unpaid_penalties']) ?></span>
                                <?php else: ?>
                                    <span class="text-green-600 dark:text-green-400 text-xs">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if ($m['status'] === 'active'): ?>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400">
                                        <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span>Aktif
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400">
                                        <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>Suspended
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-1.5">
                                    <!-- Toggle Status -->
                                    <form method="POST">
                                        <input type="hidden" name="user_id" value="<?= $m['user_id'] ?>">
                                        <input type="hidden" name="current_status" value="<?= $m['status'] ?>">
                                        <input type="hidden" name="toggle_status" value="1">
                                        <?php if ($m['status'] === 'active'): ?>
                                            <button type="submit" onclick="return confirm('Suspend member ini?')" title="Suspend"
                                                    class="p-1.5 rounded-lg border border-red-300 dark:border-red-700/50 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
                                                <span class="material-symbols-outlined text-[18px]">person_off</span>
                                            </button>
                                        <?php else: ?>
                                            <button type="submit" onclick="return confirm('Aktifkan member ini?')" title="Activate"
                                                    class="p-1.5 rounded-lg border border-green-300 dark:border-green-700/50 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors">
                                                <span class="material-symbols-outlined text-[18px]">person_check</span>
                                            </button>
                                        <?php endif; ?>
                                    </form>
                                    <!-- Change Tier -->
                                    <button onclick="document.getElementById('tierModal<?= $m['user_id'] ?>').classList.remove('hidden')" title="Ubah Tier"
                                            class="p-1.5 rounded-lg border border-yellow-300 dark:border-yellow-700/50 text-yellow-600 dark:text-yellow-400 hover:bg-yellow-50 dark:hover:bg-yellow-900/20 transition-colors">
                                        <span class="material-symbols-outlined text-[18px]">swap_vert</span>
                                    </button>
                                </div>

                                <!-- Tier Modal -->
                                <div id="tierModal<?= $m['user_id'] ?>" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center p-4">
                                    <!-- Backdrop -->
                                    <div class="absolute inset-0 bg-black/60 backdrop-blur-sm" onclick="this.parentElement.classList.add('hidden')"></div>
                                    <!-- Modal Content -->
                                    <div class="relative bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-2xl w-full max-w-sm">
                                        <form method="POST">
                                            <div class="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700">
                                                <h3 class="text-base font-bold text-gray-900 dark:text-white">Ubah Tier</h3>
                                                <button type="button" onclick="this.closest('[data-modal]').classList.add('hidden')"
                                                        class="p-1 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                                    <span class="material-symbols-outlined text-[20px]">close</span>
                                                </button>
                                            </div>
                                            <div class="p-5 space-y-4">
                                                <p class="text-sm text-gray-600 dark:text-slate-400">
                                                    Member: <span class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($m['full_name']) ?></span>
                                                </p>
                                                <input type="hidden" name="user_id" value="<?= $m['user_id'] ?>">
                                                <div>
                                                    <label class="block text-sm font-medium text-gray-700 dark:text-slate-300 mb-1.5">Pilih Tier Baru</label>
                                                    <select name="tier_id" class="w-full py-2.5 px-3 bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-colors">
                                                        <?php foreach ($tiers as $tid => $t): ?>
                                                        <option value="<?= $tid ?>" <?= $m['tier_id'] == $tid ? 'selected' : '' ?>><?= $t['name'] ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="flex justify-end gap-2 p-5 border-t border-gray-200 dark:border-gray-700">
                                                <button type="button" onclick="this.closest('[data-modal]').classList.add('hidden')"
                                                        class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-slate-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-[#293038] transition-colors">
                                                    Batal
                                                </button>
                                                <button type="submit" name="change_tier" value="1"
                                                        class="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm">
                                                    Simpan
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($members)): ?>
                        <tr>
                            <td colspan="9" class="px-4 py-12 text-center">
                                <div class="flex flex-col items-center gap-2">
                                    <span class="material-symbols-outlined text-4xl text-gray-300 dark:text-slate-600">group_off</span>
                                    <p class="text-gray-500 dark:text-slate-400">Tidak ada data member</p>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="flex items-center justify-center gap-1 pt-2">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-primary text-white text-sm font-semibold shadow-sm"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&tier=<?= $filter_tier ?>&search=<?= urlencode($search) ?>"
                       class="inline-flex items-center justify-center w-9 h-9 rounded-lg text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-[#293038] text-sm font-medium transition-colors"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>

    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
