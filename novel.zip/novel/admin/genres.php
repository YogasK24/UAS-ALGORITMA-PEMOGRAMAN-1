<?php
/**
 * Admin - Kelola Genre - BookHaven Digital Library
 * CRUD genre buku
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$page_title = 'Kelola Genre';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_genre'])) {
        $name = sanitize($_POST['genre_name']);
        $desc = sanitize($_POST['description'] ?? '');
        $stmt = mysqli_prepare($conn, "INSERT INTO genres (genre_name, description) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "ss", $name, $desc);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Genre berhasil ditambahkan');
        header("Location: " . BASE_URL . "admin/genres.php"); exit;
    }
    if (isset($_POST['edit_genre'])) {
        $id = intval($_POST['genre_id']);
        $name = sanitize($_POST['genre_name']);
        $desc = sanitize($_POST['description'] ?? '');
        $stmt = mysqli_prepare($conn, "UPDATE genres SET genre_name=?, description=? WHERE genre_id=?");
        mysqli_stmt_bind_param($stmt, "ssi", $name, $desc, $id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Genre berhasil diperbarui');
        header("Location: " . BASE_URL . "admin/genres.php"); exit;
    }
    if (isset($_POST['delete_genre'])) {
        $id = intval($_POST['genre_id']);
        $stmt = mysqli_prepare($conn, "DELETE FROM genres WHERE genre_id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Genre berhasil dihapus');
        header("Location: " . BASE_URL . "admin/genres.php"); exit;
    }
}

$genres = [];
$r = mysqli_query($conn, "SELECT g.*, (SELECT COUNT(*) FROM book_genres WHERE genre_id = g.genre_id) as book_count FROM genres g ORDER BY g.genre_name");
while ($row = mysqli_fetch_assoc($r)) $genres[] = $row;

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Kelola Genre</h2>
            <div class="flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400 mt-0.5">
                <a href="<?= BASE_URL ?>admin/index.php" class="hover:text-primary transition-colors">Dashboard</a>
                <span class="material-symbols-outlined text-[12px]">chevron_right</span>
                <span class="text-gray-900 dark:text-white font-medium">Genre</span>
            </div>
        </div>
        <button onclick="openModal('addModal')" class="inline-flex items-center gap-2 bg-primary hover:bg-blue-700 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-sm shadow-primary/20 transition-colors">
            <span class="material-symbols-outlined text-[18px]">add_circle</span>
            Tambah Genre
        </button>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Summary Bar -->
        <div class="flex items-center gap-4 flex-wrap">
            <div class="inline-flex items-center gap-2 bg-white dark:bg-[#1e293b] border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2.5 text-sm">
                <span class="material-symbols-outlined text-primary text-[18px]">category</span>
                <span class="text-gray-500 dark:text-slate-400">Total:</span>
                <span class="font-bold text-gray-900 dark:text-white"><?= count($genres) ?> genre</span>
            </div>
        </div>

        <!-- Genre Card Grid -->
        <?php if (empty($genres)): ?>
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-12 text-center">
                <span class="material-symbols-outlined text-5xl text-gray-300 dark:text-slate-600 block mb-3">label_off</span>
                <p class="text-sm font-medium text-gray-400 dark:text-slate-500">Belum ada genre</p>
                <p class="text-xs text-gray-400 dark:text-slate-500 mt-1">Klik tombol "Tambah Genre" untuk menambahkan</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <?php foreach ($genres as $g): ?>
                    <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md hover:border-gray-300 dark:hover:border-gray-600 transition-all duration-200 flex flex-col">
                        <!-- Card Body -->
                        <div class="p-5 flex-1 flex flex-col items-center text-center">
                            <!-- Genre Badge -->
                            <span class="inline-flex items-center rounded-full px-3.5 py-1.5 text-sm font-semibold <?= getGenreBadgeClass($g['genre_name']) ?> mb-3">
                                <?= htmlspecialchars($g['genre_name']) ?>
                            </span>
                            <!-- Description -->
                            <p class="text-xs text-gray-500 dark:text-slate-400 leading-relaxed mb-3 line-clamp-2 flex-1">
                                <?= htmlspecialchars($g['description'] ?? '-') ?>
                            </p>
                            <!-- Book Count -->
                            <div class="inline-flex items-center gap-1.5 text-sm">
                                <span class="material-symbols-outlined text-primary text-[16px]">menu_book</span>
                                <span class="font-bold text-gray-900 dark:text-white"><?= $g['book_count'] ?></span>
                                <span class="text-gray-400 dark:text-slate-500">buku</span>
                            </div>
                        </div>
                        <!-- Card Actions -->
                        <div class="flex items-center justify-center gap-2 px-5 py-3 border-t border-gray-100 dark:border-gray-700/50">
                            <button onclick="editGenre(<?= htmlspecialchars(json_encode($g)) ?>)"
                                    class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-500 dark:text-slate-400 hover:text-yellow-500 hover:bg-yellow-500/10 transition-all" title="Edit">
                                <span class="material-symbols-outlined text-[16px]">edit</span>
                                Edit
                            </button>
                            <form method="POST" class="inline">
                                <input type="hidden" name="genre_id" value="<?= $g['genre_id'] ?>">
                                <input type="hidden" name="delete_genre" value="1">
                                <button type="submit" onclick="return confirm('Hapus genre ini?')"
                                        class="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-500 dark:text-slate-400 hover:text-red-500 hover:bg-red-500/10 transition-all" title="Hapus">
                                    <span class="material-symbols-outlined text-[16px]">delete</span>
                                    Hapus
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div><!-- end scrollable -->
</main>

<!-- Add Modal -->
<div id="addModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-lg mx-4 transform transition-all">
        <form method="POST">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                        <span class="material-symbols-outlined text-primary text-[20px]">new_label</span>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white">Tambah Genre</h3>
                </div>
                <button type="button" onclick="closeModal('addModal')" class="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-all">
                    <span class="material-symbols-outlined text-[20px]">close</span>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="px-6 py-5 space-y-4 max-h-[65vh] overflow-y-auto">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Nama Genre <span class="text-red-500">*</span></label>
                    <input type="text" name="genre_name" required
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500"
                           placeholder="Masukkan nama genre">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Deskripsi</label>
                    <textarea name="description" rows="3"
                              class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500 resize-none"
                              placeholder="Deskripsi singkat genre"></textarea>
                </div>
            </div>
            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                <button type="button" onclick="closeModal('addModal')"
                        class="px-4 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors">
                    Batal
                </button>
                <button type="submit" name="add_genre"
                        class="px-5 py-2.5 text-sm font-medium text-white bg-primary hover:bg-blue-700 rounded-lg shadow-sm shadow-primary/20 transition-colors">
                    <span class="inline-flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[16px]">save</span>
                        Simpan
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-lg mx-4 transform transition-all">
        <form method="POST">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                        <span class="material-symbols-outlined text-yellow-500 text-[20px]">edit</span>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white">Edit Genre</h3>
                </div>
                <button type="button" onclick="closeModal('editModal')" class="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-all">
                    <span class="material-symbols-outlined text-[20px]">close</span>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="px-6 py-5 space-y-4 max-h-[65vh] overflow-y-auto">
                <input type="hidden" name="genre_id" id="e_genre_id">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Nama Genre <span class="text-red-500">*</span></label>
                    <input type="text" name="genre_name" id="e_genre_name" required
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Deskripsi</label>
                    <textarea name="description" id="e_genre_desc" rows="3"
                              class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all resize-none"></textarea>
                </div>
            </div>
            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                <button type="button" onclick="closeModal('editModal')"
                        class="px-4 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors">
                    Batal
                </button>
                <button type="submit" name="edit_genre"
                        class="px-5 py-2.5 text-sm font-medium text-white bg-yellow-500 hover:bg-yellow-600 rounded-lg shadow-sm shadow-yellow-500/20 transition-colors">
                    <span class="inline-flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[16px]">save</span>
                        Update
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal helpers
function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}
function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
    document.body.style.overflow = '';
}
// Close modal on backdrop click
document.querySelectorAll('[data-modal]').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) closeModal(this.id);
    });
});
// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('[data-modal]:not(.hidden)').forEach(m => closeModal(m.id));
    }
});

// Populate edit modal
function editGenre(g) {
    document.getElementById('e_genre_id').value = g.genre_id;
    document.getElementById('e_genre_name').value = g.genre_name;
    document.getElementById('e_genre_desc').value = g.description || '';
    openModal('editModal');
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
