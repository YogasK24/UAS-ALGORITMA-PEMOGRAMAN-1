<?php
/**
 * Admin - Kelola Penulis - BookHaven Digital Library
 * CRUD penulis novel
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$page_title = 'Kelola Penulis';

// Proses CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_author'])) {
        $name = sanitize($_POST['author_name']);
        $bio = sanitize($_POST['biography'] ?? '');
        $country = sanitize($_POST['country'] ?? '');
        $year = intval($_POST['birth_year'] ?? 0);
        $sql = "INSERT INTO authors (author_name, biography, country, birth_year) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssi", $name, $bio, $country, $year);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Penulis berhasil ditambahkan');
        header("Location: " . BASE_URL . "admin/authors.php"); exit;
    }
    if (isset($_POST['edit_author'])) {
        $id = intval($_POST['author_id']);
        $name = sanitize($_POST['author_name']);
        $bio = sanitize($_POST['biography'] ?? '');
        $country = sanitize($_POST['country'] ?? '');
        $year = intval($_POST['birth_year'] ?? 0);
        $sql = "UPDATE authors SET author_name=?, biography=?, country=?, birth_year=? WHERE author_id=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssii", $name, $bio, $country, $year, $id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Penulis berhasil diperbarui');
        header("Location: " . BASE_URL . "admin/authors.php"); exit;
    }
    if (isset($_POST['delete_author'])) {
        $id = intval($_POST['author_id']);
        $sql = "DELETE FROM authors WHERE author_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Penulis berhasil dihapus');
        header("Location: " . BASE_URL . "admin/authors.php"); exit;
    }
}

$authors = [];
$r = mysqli_query($conn, "SELECT a.*, (SELECT COUNT(*) FROM books WHERE author_id = a.author_id) as book_count FROM authors a ORDER BY a.author_name");
while ($row = mysqli_fetch_assoc($r)) $authors[] = $row;

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 flex flex-col h-screen overflow-hidden">
    <!-- Header Bar -->
    <header class="h-16 flex items-center justify-between px-6 bg-white dark:bg-[#111418] border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div>
            <h2 class="text-lg font-bold text-gray-900 dark:text-white">Kelola Penulis</h2>
            <div class="flex items-center gap-1.5 text-xs text-gray-500 dark:text-slate-400 mt-0.5">
                <a href="<?= BASE_URL ?>admin/index.php" class="hover:text-primary transition-colors">Dashboard</a>
                <span class="material-symbols-outlined text-[12px]">chevron_right</span>
                <span class="text-gray-900 dark:text-white font-medium">Penulis</span>
            </div>
        </div>
        <button onclick="openModal('addModal')" class="inline-flex items-center gap-2 bg-primary hover:bg-blue-700 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-sm shadow-primary/20 transition-colors">
            <span class="material-symbols-outlined text-[18px]">add_circle</span>
            Tambah Penulis
        </button>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-6 space-y-6">

        <?php showFlash(); ?>

        <!-- Summary Bar -->
        <div class="flex items-center gap-4 flex-wrap">
            <div class="inline-flex items-center gap-2 bg-white dark:bg-[#1e293b] border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2.5 text-sm">
                <span class="material-symbols-outlined text-primary text-[18px]">person_edit</span>
                <span class="text-gray-500 dark:text-slate-400">Total:</span>
                <span class="font-bold text-gray-900 dark:text-white"><?= count($authors) ?> penulis</span>
            </div>
        </div>

        <!-- Authors Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                    <thead class="bg-gray-50 dark:bg-[#293038] text-gray-500 dark:text-slate-400">
                        <tr>
                            <th class="px-5 py-3.5 font-medium w-12">#</th>
                            <th class="px-5 py-3.5 font-medium">Nama</th>
                            <th class="px-5 py-3.5 font-medium">Negara</th>
                            <th class="px-5 py-3.5 font-medium">Tahun Lahir</th>
                            <th class="px-5 py-3.5 font-medium">Jumlah Buku</th>
                            <th class="px-5 py-3.5 font-medium text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700 text-gray-700 dark:text-gray-300">
                        <?php if (empty($authors)): ?>
                            <tr>
                                <td colspan="6" class="px-5 py-12 text-center text-gray-400 dark:text-slate-500">
                                    <span class="material-symbols-outlined text-5xl block mb-3">person_off</span>
                                    <p class="text-sm font-medium">Belum ada penulis</p>
                                    <p class="text-xs mt-1">Klik tombol "Tambah Penulis" untuk menambahkan</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; foreach ($authors as $a): ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                    <td class="px-5 py-3.5 text-gray-400 dark:text-slate-500 font-medium"><?= $no++ ?></td>
                                    <td class="px-5 py-3.5">
                                        <div>
                                            <span class="font-semibold text-gray-900 dark:text-white"><?= htmlspecialchars($a['author_name']) ?></span>
                                            <?php if (!empty($a['biography'])): ?>
                                                <p class="text-xs text-gray-400 dark:text-slate-500 mt-0.5 line-clamp-1"><?= htmlspecialchars(substr($a['biography'], 0, 60)) ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400">
                                        <?php if (!empty($a['country'])): ?>
                                            <span class="inline-flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[14px]">public</span>
                                                <?= htmlspecialchars($a['country']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-300 dark:text-slate-600">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-3.5 text-gray-500 dark:text-slate-400">
                                        <?= $a['birth_year'] ? $a['birth_year'] : '<span class="text-gray-300 dark:text-slate-600">-</span>' ?>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <span class="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400">
                                            <span class="material-symbols-outlined text-[13px]">menu_book</span>
                                            <?= $a['book_count'] ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-3.5">
                                        <div class="flex items-center justify-center gap-1.5">
                                            <button onclick="editAuthor(<?= htmlspecialchars(json_encode($a)) ?>)"
                                                    class="p-1.5 rounded-lg text-gray-400 dark:text-slate-500 hover:text-yellow-500 hover:bg-yellow-500/10 transition-all" title="Edit">
                                                <span class="material-symbols-outlined text-[18px]">edit</span>
                                            </button>
                                            <form method="POST" class="inline">
                                                <input type="hidden" name="author_id" value="<?= $a['author_id'] ?>">
                                                <input type="hidden" name="delete_author" value="1">
                                                <button type="submit" onclick="return confirm('Hapus penulis ini?')"
                                                        class="p-1.5 rounded-lg text-gray-400 dark:text-slate-500 hover:text-red-500 hover:bg-red-500/10 transition-all" title="Hapus">
                                                    <span class="material-symbols-outlined text-[18px]">delete</span>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div><!-- end scrollable -->
</main>

<!-- Add Modal -->
<div id="addModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-lg mx-4 transform transition-all">
        <form method="POST">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                        <span class="material-symbols-outlined text-primary text-[20px]">person_add</span>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white">Tambah Penulis</h3>
                </div>
                <button type="button" onclick="closeModal('addModal')" class="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-all">
                    <span class="material-symbols-outlined text-[20px]">close</span>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="px-6 py-5 space-y-4 max-h-[65vh] overflow-y-auto">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Nama Penulis <span class="text-red-500">*</span></label>
                    <input type="text" name="author_name" required
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500"
                           placeholder="Masukkan nama penulis">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Negara</label>
                    <input type="text" name="country"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500"
                           placeholder="Contoh: Indonesia">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Tahun Lahir</label>
                    <input type="number" name="birth_year" min="1000" max="2100"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500"
                           placeholder="Contoh: 1990">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Biografi</label>
                    <textarea name="biography" rows="3"
                              class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all placeholder-gray-400 dark:placeholder-slate-500 resize-none"
                              placeholder="Biografi singkat penulis"></textarea>
                </div>
            </div>
            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                <button type="button" onclick="closeModal('addModal')"
                        class="px-4 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors">
                    Batal
                </button>
                <button type="submit" name="add_author"
                        class="px-5 py-2.5 text-sm font-medium text-white bg-primary hover:bg-blue-700 rounded-lg shadow-sm shadow-primary/20 transition-colors">
                    <span class="inline-flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[16px]">save</span>
                        Simpan
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" data-modal class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
    <div class="bg-white dark:bg-[#1e293b] rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 w-full max-w-lg mx-4 transform transition-all">
        <form method="POST">
            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                        <span class="material-symbols-outlined text-yellow-500 text-[20px]">edit</span>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white">Edit Penulis</h3>
                </div>
                <button type="button" onclick="closeModal('editModal')" class="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-all">
                    <span class="material-symbols-outlined text-[20px]">close</span>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="px-6 py-5 space-y-4 max-h-[65vh] overflow-y-auto">
                <input type="hidden" name="author_id" id="e_author_id">
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Nama Penulis <span class="text-red-500">*</span></label>
                    <input type="text" name="author_name" id="e_author_name" required
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Negara</label>
                    <input type="text" name="country" id="e_country"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Tahun Lahir</label>
                    <input type="number" name="birth_year" id="e_birth_year" min="1000" max="2100"
                           class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Biografi</label>
                    <textarea name="biography" id="e_biography" rows="3"
                              class="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-[#293038] text-gray-900 dark:text-white px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all resize-none"></textarea>
                </div>
            </div>
            <!-- Modal Footer -->
            <div class="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
                <button type="button" onclick="closeModal('editModal')"
                        class="px-4 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors">
                    Batal
                </button>
                <button type="submit" name="edit_author"
                        class="px-5 py-2.5 text-sm font-medium text-white bg-yellow-500 hover:bg-yellow-600 rounded-lg shadow-sm shadow-yellow-500/20 transition-colors">
                    <span class="inline-flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[16px]">save</span>
                        Update
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal helpers
function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}
function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
    document.body.style.overflow = '';
}
// Close modal on backdrop click
document.querySelectorAll('[data-modal]').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) closeModal(this.id);
    });
});
// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('[data-modal]:not(.hidden)').forEach(m => closeModal(m.id));
    }
});

// Populate edit modal
function editAuthor(a) {
    document.getElementById('e_author_id').value = a.author_id;
    document.getElementById('e_author_name').value = a.author_name;
    document.getElementById('e_country').value = a.country || '';
    document.getElementById('e_birth_year').value = a.birth_year || '';
    document.getElementById('e_biography').value = a.biography || '';
    openModal('editModal');
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
