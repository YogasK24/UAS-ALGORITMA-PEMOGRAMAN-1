<?php
/**
 * Database Configuration - BookHaven Digital Library
 * Koneksi ke MySQL menggunakan XAMPP
 */

// Konfigurasi database
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'db_digital_library';

// Membuat koneksi ke MySQL
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Cek koneksi - PEMILIHAN (if-else)
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Set charset ke utf8mb4
mysqli_set_charset($conn, "utf8mb4");
?>
