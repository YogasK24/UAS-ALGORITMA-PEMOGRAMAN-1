<?php
/**
 * General Configuration - BookHaven Digital Library
 * Konfigurasi umum sistem perpustakaan digital
 */

// Start session jika belum aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Base URL - sesuaikan dengan path XAMPP
define('BASE_URL', '/novel/digital-library/');
define('SITE_NAME', 'BookHaven');
define('SITE_DESC', 'Sistem Perpustakaan Digital Novel');

// Path untuk uploads
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('COVER_PATH', UPLOAD_PATH . 'covers/');
define('PDF_PATH', UPLOAD_PATH . 'pdfs/');

// Pagination
define('ITEMS_PER_PAGE', 12);

// Membership tier IDs
define('TIER_FREE', 1);
define('TIER_SILVER', 2);
define('TIER_GOLD', 3);
define('TIER_PREMIUM', 4);

// Include database
require_once __DIR__ . '/database.php';
?>
