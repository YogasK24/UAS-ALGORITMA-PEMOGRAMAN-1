<?php
/**
 * Borrowing History - BookHaven Digital Library
 * Riwayat peminjaman member
 * ALGORITMA: FOREACH, IF-ELSE, ARRAY
 */
require_once __DIR__ . '/../includes/functions.php';
requireMember();

$page_title = 'Riwayat Peminjaman';
$user_id = $_SESSION['user_id'];

// Query riwayat peminjaman
$sql = "SELECT br.*, b.title, b.book_id, a.author_name, 
               p.penalty_amount, p.penalty_status
        FROM borrowings br
        JOIN books b ON br.book_id = b.book_id
        LEFT JOIN authors a ON b.author_id = a.author_id
        LEFT JOIN penalties p ON br.borrow_id = p.borrow_id
        WHERE br.user_id = ?
        ORDER BY br.created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$history = [];
while ($row = mysqli_fetch_assoc($result)) {
    $history[] = $row;
}

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- Page Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
            <h1 class="text-white text-3xl font-black tracking-tight flex items-center gap-3">
                <span class="material-symbols-outlined text-primary text-3xl">history</span>
                Riwayat Peminjaman
            </h1>
            <p class="text-gray-400 text-sm mt-1">Semua riwayat peminjaman buku Anda</p>
        </div>
        <a href="<?= BASE_URL ?>catalog.php" class="flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
            <span class="material-symbols-outlined text-[18px]">explore</span>
            Jelajahi Katalog
        </a>
    </div>

    <?php if (empty($history)): ?>
        <!-- Empty State -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-12 text-center">
            <span class="material-symbols-outlined text-6xl text-gray-500 dark:text-gray-600 mb-4">schedule</span>
            <h3 class="text-xl font-bold text-gray-900 dark:text-white mt-3">Belum ada riwayat peminjaman</h3>
            <p class="text-gray-500 dark:text-gray-400 mt-2 mb-6">Mulai jelajahi katalog dan pinjam buku pertama Anda!</p>
            <a href="<?= BASE_URL ?>catalog.php" class="inline-flex items-center gap-2 px-6 py-3 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors">
                <span class="material-symbols-outlined text-[18px]">explore</span>
                Jelajahi Katalog
            </a>
        </div>
    <?php else: ?>
        <!-- History Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead class="bg-gray-50 dark:bg-[#293038] text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                        <tr>
                            <th class="px-6 py-4">#</th>
                            <th class="px-6 py-4">Buku</th>
                            <th class="px-6 py-4">Tgl Pinjam</th>
                            <th class="px-6 py-4">Jatuh Tempo</th>
                            <th class="px-6 py-4">Tgl Kembali</th>
                            <th class="px-6 py-4">Status</th>
                            <th class="px-6 py-4">Denda</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                        <?php 
                        $no = 1;
                        foreach ($history as $item): 
                        ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                <td class="px-6 py-4 text-gray-500 dark:text-gray-400 font-medium"><?= $no++ ?></td>
                                <td class="px-6 py-4">
                                    <a href="<?= BASE_URL ?>book_detail.php?id=<?= $item['book_id'] ?>" class="text-white font-semibold hover:text-primary transition-colors">
                                        <?= htmlspecialchars($item['title']) ?>
                                    </a>
                                    <p class="text-gray-500 dark:text-gray-400 text-xs mt-0.5"><?= htmlspecialchars($item['author_name'] ?? '') ?></p>
                                </td>
                                <td class="px-6 py-4 text-gray-300 whitespace-nowrap"><?= formatDate($item['borrow_date']) ?></td>
                                <td class="px-6 py-4 text-gray-300 whitespace-nowrap"><?= formatDate($item['due_date']) ?></td>
                                <td class="px-6 py-4 text-gray-300 whitespace-nowrap"><?= $item['return_date'] ? formatDate($item['return_date']) : '<span class="text-gray-500">-</span>' ?></td>
                                <td class="px-6 py-4">
                                    <?php
                                    // PEMILIHAN (SWITCH-CASE): Badge status
                                    switch ($item['status']) {
                                        case 'borrowed':
                                            echo '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30"><span class="w-1.5 h-1.5 rounded-full bg-blue-400"></span>Dipinjam</span>';
                                            break;
                                        case 'returned':
                                            echo '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-400 border border-green-500/30"><span class="w-1.5 h-1.5 rounded-full bg-green-400"></span>Dikembalikan</span>';
                                            break;
                                        case 'overdue':
                                            echo '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-400 border border-red-500/30"><span class="w-1.5 h-1.5 rounded-full bg-red-400"></span>Terlambat</span>';
                                            break;
                                    }
                                    ?>
                                </td>
                                <td class="px-6 py-4">
                                    <?php if ($item['penalty_amount'] > 0): ?>
                                        <span class="text-red-400 font-semibold text-sm"><?= formatRupiah($item['penalty_amount']) ?></span>
                                        <?php if ($item['penalty_status'] === 'paid'): ?>
                                            <span class="flex items-center gap-1 text-green-400 text-xs mt-1">
                                                <span class="material-symbols-outlined text-[14px]">check_circle</span> Lunas
                                            </span>
                                        <?php else: ?>
                                            <span class="flex items-center gap-1 text-red-400 text-xs mt-1">
                                                <span class="material-symbols-outlined text-[14px]">cancel</span> Belum bayar
                                            </span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-green-400">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Summary -->
        <div class="mt-4 text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2">
            <span class="material-symbols-outlined text-[16px]">info</span>
            Menampilkan <?= count($history) ?> riwayat peminjaman
        </div>
    <?php endif; ?>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
