<?php
/**
 * Reading List (Wishlist) - BookHaven Digital Library
 * ALGORITMA: FOREACH, IF-ELSE, ARRAY
 */
require_once __DIR__ . '/../includes/functions.php';
requireMember();

$page_title = 'Reading List';
$user_id = $_SESSION['user_id'];

// Hapus dari reading list
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_from_list'])) {
    $list_id = intval($_POST['list_id']);
    $sql = "DELETE FROM reading_lists WHERE list_id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $list_id, $user_id);
    mysqli_stmt_execute($stmt);
    setFlash('success', 'Buku dihapus dari Reading List');
    header("Location: " . BASE_URL . "member/reading_list.php");
    exit;
}

// Update status reading list
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $list_id = intval($_POST['list_id']);
    $new_status = sanitize($_POST['status']);
    $valid = ['want_to_read', 'currently_reading', 'finished'];
    if (in_array($new_status, $valid)) {
        $sql = "UPDATE reading_lists SET status = ? WHERE list_id = ? AND user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sii", $new_status, $list_id, $user_id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Status berhasil diupdate');
    }
    header("Location: " . BASE_URL . "member/reading_list.php");
    exit;
}

// Query reading list
$sql = "SELECT rl.*, b.title, b.cover_image, b.book_id, b.available_copies,
               a.author_name, b.rating_avg
        FROM reading_lists rl
        JOIN books b ON rl.book_id = b.book_id
        LEFT JOIN authors a ON b.author_id = a.author_id
        WHERE rl.user_id = ?
        ORDER BY rl.added_date DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$reading_list = [];
while ($row = mysqli_fetch_assoc($result)) {
    $reading_list[] = $row;
}

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- Page Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
            <h1 class="text-white text-3xl font-black tracking-tight flex items-center gap-3">
                <span class="material-symbols-outlined text-red-400 text-3xl">favorite</span>
                Reading List
            </h1>
            <p class="text-gray-400 text-sm mt-1">Koleksi buku yang ingin Anda baca</p>
        </div>
        <a href="<?= BASE_URL ?>catalog.php" class="flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
            <span class="material-symbols-outlined text-[18px]">explore</span>
            Jelajahi Katalog
        </a>
    </div>

    <?php showFlash(); ?>

    <?php if (empty($reading_list)): ?>
        <!-- Empty State -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-12 text-center">
            <span class="material-symbols-outlined text-6xl text-gray-500 dark:text-gray-600 mb-4">favorite_border</span>
            <h3 class="text-xl font-bold text-gray-900 dark:text-white mt-3">Reading list Anda kosong</h3>
            <p class="text-gray-500 dark:text-gray-400 mt-2 mb-6">Tambahkan buku dari katalog ke reading list</p>
            <a href="<?= BASE_URL ?>catalog.php" class="inline-flex items-center gap-2 px-6 py-3 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors">
                <span class="material-symbols-outlined text-[18px]">explore</span>
                Jelajahi Katalog
            </a>
        </div>
    <?php else: ?>
        <!-- Card Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            <?php foreach ($reading_list as $item): ?>
                <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col h-full hover:border-primary/40 transition-colors">
                    <!-- Card Body -->
                    <div class="p-5 flex-1">
                        <div class="flex gap-4">
                            <!-- Book Cover -->
                            <?php $item_cover = getBookCoverUrl($item['cover_image']); ?>
                            <?php if ($item_cover): ?>
                                <img src="<?= htmlspecialchars($item_cover) ?>" alt="" class="flex-shrink-0 w-16 h-20 rounded-lg object-cover shadow-sm border border-gray-700/50" loading="lazy">
                            <?php else: ?>
                                <div class="flex-shrink-0 w-16 h-20 rounded-lg bg-gradient-to-br from-primary/30 to-blue-900/50 border border-gray-700/50 flex items-center justify-center">
                                    <span class="material-symbols-outlined text-primary/70 text-2xl">menu_book</span>
                                </div>
                            <?php endif; ?>
                            <!-- Book Info -->
                            <div class="flex-1 min-w-0">
                                <h3 class="font-bold text-sm leading-snug mb-1">
                                    <a href="<?= BASE_URL ?>book_detail.php?id=<?= $item['book_id'] ?>" class="text-white hover:text-primary transition-colors line-clamp-2">
                                        <?= htmlspecialchars($item['title']) ?>
                                    </a>
                                </h3>
                                <p class="text-gray-400 text-xs mb-2"><?= htmlspecialchars($item['author_name'] ?? '') ?></p>
                                
                                <!-- Rating Stars -->
                                <div class="flex items-center gap-1 mb-3">
                                    <?php 
                                    $rating = round($item['rating_avg'] ?? 0);
                                    for ($i = 1; $i <= 5; $i++): 
                                    ?>
                                        <span class="material-symbols-outlined text-[16px] <?= $i <= $rating ? 'text-yellow-400' : 'text-gray-600' ?>" style="font-variation-settings: 'FILL' <?= $i <= $rating ? '1' : '0' ?>">star</span>
                                    <?php endfor; ?>
                                    <span class="text-gray-500 text-xs ml-1">(<?= number_format($item['rating_avg'] ?? 0, 1) ?>)</span>
                                </div>

                                <!-- Status Dropdown -->
                                <form method="POST">
                                    <input type="hidden" name="list_id" value="<?= $item['list_id'] ?>">
                                    <input type="hidden" name="update_status" value="1">
                                    <select name="status" onchange="this.form.submit()"
                                            class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-xs text-gray-300 focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors cursor-pointer">
                                        <option value="want_to_read" <?= $item['status'] === 'want_to_read' ? 'selected' : '' ?>>📖 Ingin Baca</option>
                                        <option value="currently_reading" <?= $item['status'] === 'currently_reading' ? 'selected' : '' ?>>📚 Sedang Baca</option>
                                        <option value="finished" <?= $item['status'] === 'finished' ? 'selected' : '' ?>>✅ Selesai</option>
                                    </select>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Card Footer -->
                    <div class="border-t border-gray-200 dark:border-gray-700 px-5 py-3 flex items-center gap-2">
                        <?php if ($item['available_copies'] > 0): ?>
                            <form method="POST" action="<?= BASE_URL ?>borrow_book.php" class="flex-1">
                                <input type="hidden" name="book_id" value="<?= $item['book_id'] ?>">
                                <button type="submit" class="w-full flex items-center justify-center gap-1.5 px-3 py-2 bg-primary hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors">
                                    <span class="material-symbols-outlined text-[16px]">download</span> Pinjam
                                </button>
                            </form>
                        <?php endif; ?>
                        <form method="POST">
                            <input type="hidden" name="list_id" value="<?= $item['list_id'] ?>">
                            <input type="hidden" name="remove_from_list" value="1">
                            <button type="submit" onclick="return confirm('Hapus dari reading list?')"
                                    class="flex items-center justify-center p-2 rounded-lg border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-colors">
                                <span class="material-symbols-outlined text-[16px]">delete</span>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Summary -->
        <div class="mt-6 text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2">
            <span class="material-symbols-outlined text-[16px]">info</span>
            <?= count($reading_list) ?> buku dalam reading list
        </div>
    <?php endif; ?>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
