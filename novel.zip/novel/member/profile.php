<?php
/**
 * Member Profile & Upgrade Tier - BookHaven Digital Library
 * ALGORITMA: IF-ELSE, FOREACH, ARRAY
 */
require_once __DIR__ . '/../includes/functions.php';
requireMember();

$page_title = 'Profil & Membership';
$user_id = $_SESSION['user_id'];
$user_info = getUserInfo($user_id, $conn);

// Update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    
    $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, address = ? WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssssi", $full_name, $email, $phone, $address, $user_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['full_name'] = $full_name;
        $_SESSION['email'] = $email;
        setFlash('success', 'Profil berhasil diperbarui!');
    }
    header("Location: " . BASE_URL . "member/profile.php");
    exit;
}

// Upgrade tier (simulasi)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upgrade_tier'])) {
    $new_tier_id = intval($_POST['tier_id']);
    
    // Validasi tier
    $sql = "SELECT * FROM membership_tiers WHERE tier_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $new_tier_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $new_tier = mysqli_fetch_assoc($result);
    
    if ($new_tier && $new_tier_id != $user_info['tier_id']) {
        $expiry = date('Y-m-d', strtotime('+30 days'));
        $sql = "UPDATE users SET tier_id = ?, tier_expiry = ? WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "isi", $new_tier_id, $expiry, $user_id);
        
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['tier_id'] = $new_tier_id;
            $_SESSION['tier_name'] = $new_tier['tier_name'];
            $action = ($new_tier_id > $user_info['tier_id']) ? 'upgrade' : 'downgrade';
            setFlash('success', "Berhasil $action ke tier {$new_tier['tier_name']}! (Simulasi - berlaku hingga " . formatDate($expiry) . ")");
        }
    }
    header("Location: " . BASE_URL . "member/profile.php");
    exit;
}

// Change password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new_pass = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    // Verify current password
    $sql = "SELECT password FROM users WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
    if (!password_verify($current, $row['password'])) {
        setFlash('danger', 'Password saat ini salah');
    } elseif (strlen($new_pass) < 6) {
        setFlash('danger', 'Password baru minimal 6 karakter');
    } elseif ($new_pass !== $confirm) {
        setFlash('danger', 'Konfirmasi password tidak cocok');
    } else {
        $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET password = ? WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $hashed, $user_id);
        mysqli_stmt_execute($stmt);
        setFlash('success', 'Password berhasil diubah!');
    }
    header("Location: " . BASE_URL . "member/profile.php");
    exit;
}

// All tiers for upgrade
$tiers = [];
$result = mysqli_query($conn, "SELECT * FROM membership_tiers ORDER BY tier_id");
while ($row = mysqli_fetch_assoc($result)) {
    $tiers[] = $row;
}

include __DIR__ . '/../includes/header.php';

// Tier badge color mapping
$tier_colors = [
    'Free'    => 'bg-slate-500/20 text-slate-300 border-slate-600',
    'Silver'  => 'bg-slate-400/20 text-slate-200 border-slate-500',
    'Gold'    => 'bg-yellow-500/20 text-yellow-300 border-yellow-600',
    'Premium' => 'bg-purple-500/20 text-purple-300 border-purple-600',
];
$tier_icon = [
    'Free'    => 'shield',
    'Silver'  => 'workspace_premium',
    'Gold'    => 'emoji_events',
    'Premium' => 'diamond',
];
?>

<main class="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- Page Header -->
    <div class="mb-8">
        <h1 class="text-white text-3xl font-black tracking-tight flex items-center gap-3">
            <span class="material-symbols-outlined text-primary text-3xl">manage_accounts</span>
            Profil & Membership
        </h1>
        <p class="text-gray-400 text-sm mt-1">Kelola informasi profil dan keanggotaan Anda</p>
    </div>

    <?php showFlash(); ?>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- ===== LEFT COLUMN ===== -->
        <div class="space-y-6">

            <!-- Profile Form -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-3">
                    <span class="material-symbols-outlined text-primary">person</span>
                    <h2 class="text-white font-bold text-base">Informasi Profil</h2>
                </div>
                <div class="p-6">
                    <form method="POST">
                        <div class="space-y-4">
                            <!-- Username (disabled) -->
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Username</label>
                                <input type="text" value="<?= htmlspecialchars($user_info['username']) ?>" disabled
                                       class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-500 cursor-not-allowed opacity-60">
                            </div>
                            <!-- Full Name -->
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Nama Lengkap</label>
                                <input type="text" name="full_name" required
                                       value="<?= htmlspecialchars($user_info['full_name']) ?>"
                                       class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors">
                            </div>
                            <!-- Email -->
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Email</label>
                                <input type="email" name="email" required
                                       value="<?= htmlspecialchars($user_info['email']) ?>"
                                       class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors">
                            </div>
                            <!-- Phone -->
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Telepon</label>
                                <input type="text" name="phone"
                                       value="<?= htmlspecialchars($user_info['phone'] ?? '') ?>"
                                       class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors">
                            </div>
                            <!-- Address -->
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Alamat</label>
                                <textarea name="address" rows="2"
                                          class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors resize-none"><?= htmlspecialchars($user_info['address'] ?? '') ?></textarea>
                            </div>
                        </div>
                        <button type="submit" name="update_profile"
                                class="mt-6 inline-flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
                            <span class="material-symbols-outlined text-[18px]">check_circle</span>
                            Simpan Perubahan
                        </button>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-3">
                    <span class="material-symbols-outlined text-yellow-400">lock</span>
                    <h2 class="text-white font-bold text-base">Ubah Password</h2>
                </div>
                <div class="p-6">
                    <form method="POST">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Password Saat Ini</label>
                                <input type="password" name="current_password" required
                                       class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Password Baru</label>
                                <input type="password" name="new_password" required minlength="6"
                                       class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors">
                                <p class="text-gray-500 text-xs mt-1">Minimal 6 karakter</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1.5">Konfirmasi Password Baru</label>
                                <input type="password" name="confirm_password" required
                                       class="w-full bg-slate-50 dark:bg-[#111418] border border-gray-200 dark:border-gray-700 rounded-lg px-4 py-2.5 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-primary/50 focus:border-primary/50 outline-none transition-colors">
                            </div>
                        </div>
                        <button type="submit" name="change_password"
                                class="mt-6 inline-flex items-center gap-2 px-5 py-2.5 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
                            <span class="material-symbols-outlined text-[18px]">key</span>
                            Ubah Password
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ===== RIGHT COLUMN ===== -->
        <div class="space-y-6">

            <!-- Current Tier Info -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-3">
                    <span class="material-symbols-outlined text-yellow-400">verified</span>
                    <h2 class="text-white font-bold text-base">Membership Tier</h2>
                </div>
                <div class="p-6">
                    <!-- Current Tier Badge -->
                    <div class="text-center mb-6">
                        <div class="inline-flex flex-col items-center gap-3 p-6 rounded-2xl bg-gradient-to-br from-[#111418] to-[#1e293b] border border-gray-700">
                            <span class="material-symbols-outlined text-5xl text-yellow-400" style="font-variation-settings: 'FILL' 1">
                                <?= $tier_icon[$user_info['tier_name']] ?? 'shield' ?>
                            </span>
                            <span class="text-2xl font-black text-white"><?= $user_info['tier_name'] ?></span>
                            <?php if ($user_info['tier_expiry']): ?>
                                <p class="text-gray-400 text-xs flex items-center gap-1">
                                    <span class="material-symbols-outlined text-[14px]">schedule</span>
                                    Berlaku hingga: <?= formatDate($user_info['tier_expiry']) ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Tier Comparison List -->
                    <div class="space-y-3">
                        <?php foreach ($tiers as $tier): 
                            $is_current = ($tier['tier_id'] == $user_info['tier_id']);
                            $can_change = ($tier['tier_id'] != $user_info['tier_id']);
                            $is_upgrade = ($tier['tier_id'] > $user_info['tier_id']);
                            $t_class = $tier_colors[$tier['tier_name']] ?? $tier_colors['Free'];
                        ?>
                            <div class="rounded-xl border <?= $is_current ? 'border-primary bg-primary/5' : 'border-gray-700 bg-[#111418]' ?> p-4 transition-colors">
                                <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1.5">
                                            <span class="material-symbols-outlined text-[18px] <?= $is_current ? 'text-primary' : 'text-gray-500' ?>" style="font-variation-settings: 'FILL' 1">
                                                <?= $tier_icon[$tier['tier_name']] ?? 'shield' ?>
                                            </span>
                                            <h3 class="font-bold text-sm text-white"><?= $tier['tier_name'] ?></h3>
                                            <?php if ($is_current): ?>
                                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-500/20 text-green-400 border border-green-500/30">
                                                    <span class="w-1 h-1 rounded-full bg-green-400"></span>Aktif
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex flex-wrap gap-x-3 gap-y-1 text-xs text-gray-400">
                                            <span class="flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[12px]">library_books</span>
                                                <?= $tier['max_books'] == 999 ? '∞' : $tier['max_books'] ?> buku
                                            </span>
                                            <span class="flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[12px]">schedule</span>
                                                <?= $tier['borrow_days'] ?> hari
                                            </span>
                                            <span class="flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[12px]">autorenew</span>
                                                <?= $tier['renewal_limit'] == 999 ? '∞' : $tier['renewal_limit'] ?>x extend
                                            </span>
                                            <span class="flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[12px]">payments</span>
                                                <?= $tier['penalty_rate'] > 0 ? formatRupiah($tier['penalty_rate']) . '/hari' : 'No penalty' ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="text-right flex-shrink-0">
                                        <p class="text-white font-bold text-sm">
                                            <?= $tier['monthly_fee'] > 0 ? formatRupiah($tier['monthly_fee']) : 'Gratis' ?>
                                        </p>
                                        <?php if ($tier['monthly_fee'] > 0): ?>
                                            <p class="text-gray-500 text-[10px]">/bulan</p>
                                        <?php endif; ?>
                                        <?php if ($can_change): ?>
                                            <form method="POST" class="mt-2">
                                                <input type="hidden" name="tier_id" value="<?= $tier['tier_id'] ?>">
                                                <input type="hidden" name="upgrade_tier" value="1">
                                                <?php if ($is_upgrade): ?>
                                                    <button type="submit" 
                                                            onclick="return confirm('Upgrade ke <?= $tier['tier_name'] ?>?')"
                                                            class="inline-flex items-center gap-1 px-3 py-1.5 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg text-xs font-semibold transition-colors">
                                                        <span class="material-symbols-outlined text-[14px]">upgrade</span>
                                                        Upgrade
                                                    </button>
                                                <?php else: ?>
                                                    <button type="submit" 
                                                            onclick="return confirm('Ganti ke tier <?= $tier['tier_name'] ?>?')"
                                                            class="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-600 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition-colors">
                                                        <span class="material-symbols-outlined text-[14px]">swap_vert</span>
                                                        Ganti
                                                    </button>
                                                <?php endif; ?>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
