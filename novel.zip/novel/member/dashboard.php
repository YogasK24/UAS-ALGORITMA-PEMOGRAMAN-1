<?php
/**
 * Member Dashboard - BookHaven Digital Library
 * ALGORITMA: FOREACH, ARRAY MULTIDIMENSI, IF-ELSE
 */
require_once __DIR__ . '/../includes/functions.php';
requireMember();

$page_title = 'Dashboard Member';
$user_id = $_SESSION['user_id'];
$user_info = getUserInfo($user_id, $conn);

// =============================================
// STATISTIK MEMBER (ARRAY)
// =============================================
$stats = [];

// Total buku dipinjam aktif
$result = mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE user_id = $user_id AND status = 'borrowed'");
$stats['active_borrows'] = mysqli_fetch_assoc($result)['c'];

// Total pernah dipinjam
$result = mysqli_query($conn, "SELECT COUNT(*) as c FROM borrowings WHERE user_id = $user_id");
$stats['total_borrows'] = mysqli_fetch_assoc($result)['c'];

// Total review ditulis
$result = mysqli_query($conn, "SELECT COUNT(*) as c FROM reviews WHERE user_id = $user_id");
$stats['total_reviews'] = mysqli_fetch_assoc($result)['c'];

// Total denda belum bayar
$stats['unpaid_penalty'] = getUnpaidPenalties($user_id, $conn);

// Reading list count
$result = mysqli_query($conn, "SELECT COUNT(*) as c FROM reading_lists WHERE user_id = $user_id");
$stats['reading_list'] = mysqli_fetch_assoc($result)['c'];

// =============================================
// BUKU YANG SEGERA JATUH TEMPO (ARRAY MULTIDIMENSI)
// =============================================
$sql = "SELECT br.*, b.title, b.cover_image, a.author_name
        FROM borrowings br
        JOIN books b ON br.book_id = b.book_id
        LEFT JOIN authors a ON b.author_id = a.author_id
        WHERE br.user_id = ? AND br.status = 'borrowed'
        ORDER BY br.due_date ASC LIMIT 5";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$upcoming_due = [];
while ($row = mysqli_fetch_assoc($result)) {
    $due = new DateTime($row['due_date']);
    $today = new DateTime();
    $row['days_remaining'] = (int)$today->diff($due)->format('%r%a');
    $upcoming_due[] = $row;
}

// =============================================
// REKOMENDASI BUKU (FUNCTION: getRecommendations)
// =============================================
$recommendations = getRecommendations($user_id, $conn);

include __DIR__ . '/../includes/header.php';

// Tier badge color mapping
$tier_colors = [
    'Free'    => 'bg-slate-500/20 text-slate-300 border-slate-600',
    'Silver'  => 'bg-slate-400/20 text-slate-200 border-slate-500',
    'Gold'    => 'bg-yellow-500/20 text-yellow-300 border-yellow-600',
    'Premium' => 'bg-purple-500/20 text-purple-300 border-purple-600',
];
$tier_class = $tier_colors[$user_info['tier_name']] ?? $tier_colors['Free'];

// Borrow capacity percentage
$max_b = $user_info['max_books'] == 999 ? 20 : $user_info['max_books'];
$borrow_pct = $max_b > 0 ? round(($stats['active_borrows'] / $max_b) * 100) : 0;
?>

<!-- ===== MAIN CONTENT ===== -->
<main class="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <?php showFlash(); ?>

    <!-- Welcome & Tier Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-8">
        <div class="flex flex-col gap-2">
            <h1 class="text-white text-3xl sm:text-4xl font-black leading-tight tracking-tight">
                Halo, <?= htmlspecialchars($user_info['full_name']) ?>!
            </h1>
            <p class="text-gray-400 text-base font-normal flex items-center gap-2 flex-wrap">
                Selamat datang kembali di dashboard Anda.
                <span class="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-bold border <?= $tier_class ?>">
                    <span class="material-symbols-outlined text-[14px]">verified</span>
                    <?= $user_info['tier_name'] ?>
                </span>
            </p>
        </div>
        <a href="<?= BASE_URL ?>catalog.php" class="flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
            <span class="material-symbols-outlined text-[18px]">explore</span>
            Jelajahi Katalog
        </a>
    </div>

    <!-- ===== STAT CARDS ===== -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <!-- Active Borrows -->
        <div class="relative overflow-hidden bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 flex flex-col gap-2">
            <div class="flex items-center gap-3 mb-1">
                <span class="material-symbols-outlined text-primary">library_books</span>
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Sedang Dipinjam</p>
            </div>
            <div class="flex items-baseline gap-2">
                <p class="text-white tracking-tight text-3xl font-black"><?= $stats['active_borrows'] ?></p>
                <span class="text-gray-500 text-lg font-normal">/ <?= $user_info['max_books'] == 999 ? '∞' : $user_info['max_books'] ?></span>
            </div>
            <div class="absolute bottom-0 left-0 h-1 bg-primary/20 w-full">
                <div class="h-full bg-primary transition-all" style="width: <?= min($borrow_pct, 100) ?>%"></div>
            </div>
        </div>

        <!-- Total Borrows -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 flex flex-col gap-2">
            <div class="flex items-center gap-3 mb-1">
                <span class="material-symbols-outlined text-blue-400">history</span>
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Total Peminjaman</p>
            </div>
            <p class="text-white tracking-tight text-3xl font-black"><?= $stats['total_borrows'] ?></p>
        </div>

        <!-- Reviews -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-5 flex flex-col gap-2">
            <div class="flex items-center gap-3 mb-1">
                <span class="material-symbols-outlined text-yellow-400">star</span>
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Review Ditulis</p>
            </div>
            <p class="text-white tracking-tight text-3xl font-black"><?= $stats['total_reviews'] ?></p>
        </div>

        <!-- Unpaid Penalty -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border <?= $stats['unpaid_penalty'] > 0 ? 'border-red-500/50 dark:border-red-700' : 'border-gray-200 dark:border-gray-700' ?> shadow-sm p-5 flex flex-col gap-2">
            <div class="flex items-center gap-3 mb-1">
                <span class="material-symbols-outlined <?= $stats['unpaid_penalty'] > 0 ? 'text-red-400' : 'text-green-400' ?>">
                    <?= $stats['unpaid_penalty'] > 0 ? 'warning' : 'check_circle' ?>
                </span>
                <p class="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Denda</p>
            </div>
            <p class="tracking-tight text-3xl font-black <?= $stats['unpaid_penalty'] > 0 ? 'text-red-400' : 'text-green-400' ?>">
                <?= formatRupiah($stats['unpaid_penalty']) ?>
            </p>
            <?php if ($stats['unpaid_penalty'] > 0): ?>
                <a href="<?= BASE_URL ?>member/penalties.php" class="text-xs text-red-400 hover:underline font-medium">Bayar sekarang →</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===== MAIN 2-COLUMN LAYOUT ===== -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">

        <!-- LEFT: Upcoming Due Books -->
        <div class="lg:col-span-8 flex flex-col gap-8">
            <section class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 class="text-white text-lg font-bold flex items-center gap-2">
                        <span class="material-symbols-outlined text-primary">calendar_month</span>
                        Buku Yang Dipinjam
                    </h2>
                    <a href="<?= BASE_URL ?>member/borrowed.php" class="text-primary text-sm font-semibold hover:underline flex items-center gap-1">
                        Lihat Semua
                        <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
                    </a>
                </div>

                <?php if (empty($upcoming_due)): ?>
                    <div class="flex flex-col items-center justify-center py-16 px-6">
                        <span class="material-symbols-outlined text-gray-600 text-6xl mb-4">menu_book</span>
                        <p class="text-gray-400 text-base mb-4">Tidak ada buku yang sedang dipinjam</p>
                        <a href="<?= BASE_URL ?>catalog.php" class="flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors">
                            <span class="material-symbols-outlined text-[18px]">explore</span>
                            Jelajahi Katalog
                        </a>
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr class="bg-gray-50 dark:bg-[#293038] text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                                    <th class="px-6 py-3">Buku</th>
                                    <th class="px-6 py-3">Jatuh Tempo</th>
                                    <th class="px-6 py-3">Status</th>
                                    <th class="px-6 py-3 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <?php 
                                // PERULANGAN (FOREACH): Tampilkan buku yang dipinjam
                                foreach ($upcoming_due as $borrow): 
                                ?>
                                    <tr class="hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                        <td class="px-6 py-4">
                                            <div class="flex items-center gap-3">
                                                <?php $borrow_cover = getBookCoverUrl($borrow['cover_image']); ?>
                                                <?php if ($borrow_cover): ?>
                                                    <img src="<?= htmlspecialchars($borrow_cover) ?>" 
                                                         alt="" class="w-10 h-14 rounded object-cover shadow-sm flex-shrink-0" loading="lazy">
                                                <?php else: ?>
                                                    <div class="w-10 h-14 rounded bg-gray-700 flex items-center justify-center flex-shrink-0">
                                                        <span class="material-symbols-outlined text-gray-500 text-[18px]">book</span>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="min-w-0">
                                                    <p class="text-white font-semibold truncate"><?= htmlspecialchars($borrow['title']) ?></p>
                                                    <p class="text-gray-400 text-xs truncate"><?= htmlspecialchars($borrow['author_name'] ?? '-') ?></p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 text-gray-300 whitespace-nowrap"><?= formatDate($borrow['due_date']) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php 
                                            // PEMILIHAN (IF-ELSE): Status berdasarkan sisa hari
                                            if ($borrow['days_remaining'] < 0): 
                                            ?>
                                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-900/30 text-red-400 border border-red-800">
                                                    <span class="material-symbols-outlined text-[14px]">error</span>
                                                    Terlambat <?= abs($borrow['days_remaining']) ?> hari
                                                </span>
                                            <?php elseif ($borrow['days_remaining'] <= 3): ?>
                                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-yellow-900/30 text-yellow-400 border border-yellow-800">
                                                    <span class="material-symbols-outlined text-[14px]">warning</span>
                                                    <?= $borrow['days_remaining'] ?> hari lagi
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-green-900/30 text-green-400 border border-green-800">
                                                    <span class="size-1.5 rounded-full bg-green-500 animate-pulse"></span>
                                                    <?= $borrow['days_remaining'] ?> hari lagi
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <form method="POST" action="<?= BASE_URL ?>return_book.php" class="inline">
                                                <input type="hidden" name="borrow_id" value="<?= $borrow['borrow_id'] ?>">
                                                <button type="submit" onclick="return confirm('Kembalikan buku ini?')"
                                                        class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-green-600/20 hover:bg-green-600/30 text-green-400 rounded-lg text-xs font-semibold transition-colors border border-green-700/50">
                                                    <span class="material-symbols-outlined text-[16px]">check_circle</span>
                                                    Kembalikan
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>
        </div>

        <!-- RIGHT: Membership Info + Quick Links -->
        <div class="lg:col-span-4 flex flex-col gap-6">

            <!-- Membership Card -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                <div class="bg-primary/10 px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-3">
                    <span class="material-symbols-outlined text-primary">shield</span>
                    <h3 class="text-white font-bold text-base">Membership Anda</h3>
                </div>
                <div class="p-6">
                    <div class="text-center mb-5">
                        <span class="inline-flex items-center gap-2 px-5 py-2 rounded-full text-sm font-bold border <?= $tier_class ?>">
                            <span class="material-symbols-outlined text-[18px]">verified</span>
                            <?= $user_info['tier_name'] ?>
                        </span>
                    </div>
                    <ul class="space-y-3 text-sm">
                        <li class="flex items-center gap-3 text-gray-300">
                            <span class="material-symbols-outlined text-green-400 text-[18px]">check_circle</span>
                            Max <strong class="text-white mx-1"><?= $user_info['max_books'] == 999 ? 'Unlimited' : $user_info['max_books'] ?></strong> buku dipinjam
                        </li>
                        <li class="flex items-center gap-3 text-gray-300">
                            <span class="material-symbols-outlined text-green-400 text-[18px]">check_circle</span>
                            <strong class="text-white mr-1"><?= $user_info['borrow_days'] ?></strong> hari peminjaman
                        </li>
                        <li class="flex items-center gap-3 text-gray-300">
                            <span class="material-symbols-outlined text-green-400 text-[18px]">check_circle</span>
                            <strong class="text-white mr-1"><?= $user_info['renewal_limit'] == 999 ? 'Unlimited' : $user_info['renewal_limit'] . 'x' ?></strong> perpanjangan
                        </li>
                        <li class="flex items-center gap-3 text-gray-300">
                            <?php if ($user_info['penalty_rate'] > 0): ?>
                                <span class="material-symbols-outlined text-blue-400 text-[18px]">info</span>
                                Denda <strong class="text-white mx-1"><?= formatRupiah($user_info['penalty_rate']) ?></strong>/hari
                            <?php else: ?>
                                <span class="material-symbols-outlined text-green-400 text-[18px]">check_circle</span>
                                Tanpa denda keterlambatan
                            <?php endif; ?>
                        </li>
                    </ul>
                    <?php if ($user_info['tier_id'] < TIER_PREMIUM): ?>
                        <a href="<?= BASE_URL ?>member/profile.php" class="mt-5 w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-300 border border-yellow-600 rounded-lg text-sm font-bold transition-colors">
                            <span class="material-symbols-outlined text-[18px]">upgrade</span>
                            Upgrade Tier
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center gap-3">
                    <span class="material-symbols-outlined text-primary">bolt</span>
                    <h3 class="text-white font-bold text-base">Menu Cepat</h3>
                </div>
                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <a href="<?= BASE_URL ?>catalog.php" class="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors group">
                        <span class="material-symbols-outlined text-primary text-[20px]">grid_view</span>
                        <span class="text-sm text-gray-300 group-hover:text-white transition-colors font-medium">Jelajahi Katalog</span>
                        <span class="material-symbols-outlined text-gray-600 text-[16px] ml-auto">chevron_right</span>
                    </a>
                    <a href="<?= BASE_URL ?>member/reading_list.php" class="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors group">
                        <span class="material-symbols-outlined text-red-400 text-[20px]">favorite</span>
                        <span class="text-sm text-gray-300 group-hover:text-white transition-colors font-medium">Reading List</span>
                        <span class="ml-auto flex items-center gap-2">
                            <span class="bg-primary/20 text-primary text-xs font-bold px-2 py-0.5 rounded-full"><?= $stats['reading_list'] ?></span>
                            <span class="material-symbols-outlined text-gray-600 text-[16px]">chevron_right</span>
                        </span>
                    </a>
                    <a href="<?= BASE_URL ?>member/history.php" class="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors group">
                        <span class="material-symbols-outlined text-blue-400 text-[20px]">history</span>
                        <span class="text-sm text-gray-300 group-hover:text-white transition-colors font-medium">Riwayat Peminjaman</span>
                        <span class="material-symbols-outlined text-gray-600 text-[16px] ml-auto">chevron_right</span>
                    </a>
                    <a href="<?= BASE_URL ?>member/penalties.php" class="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors group">
                        <span class="material-symbols-outlined text-yellow-400 text-[20px]">gavel</span>
                        <span class="text-sm text-gray-300 group-hover:text-white transition-colors font-medium">Denda</span>
                        <?php if ($stats['unpaid_penalty'] > 0): ?>
                            <span class="ml-auto flex items-center gap-2">
                                <span class="bg-red-900/30 text-red-400 text-xs font-bold px-2 py-0.5 rounded-full"><?= formatRupiah($stats['unpaid_penalty']) ?></span>
                                <span class="material-symbols-outlined text-gray-600 text-[16px]">chevron_right</span>
                            </span>
                        <?php else: ?>
                            <span class="material-symbols-outlined text-gray-600 text-[16px] ml-auto">chevron_right</span>
                        <?php endif; ?>
                    </a>
                    <a href="<?= BASE_URL ?>member/borrowed.php" class="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors group">
                        <span class="material-symbols-outlined text-green-400 text-[20px]">library_books</span>
                        <span class="text-sm text-gray-300 group-hover:text-white transition-colors font-medium">Buku Dipinjam</span>
                        <span class="material-symbols-outlined text-gray-600 text-[16px] ml-auto">chevron_right</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== RECOMMENDATIONS ===== -->
    <?php if (!empty($recommendations)): ?>
        <section class="mt-10">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-white text-2xl font-bold flex items-center gap-2">
                    <span class="material-symbols-outlined text-primary">auto_awesome</span>
                    Rekomendasi untuk Anda
                </h2>
                <a href="<?= BASE_URL ?>catalog.php" class="text-primary text-sm font-semibold hover:underline">Lihat Semua →</a>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php 
                // FOREACH: Tampilkan rekomendasi
                foreach (array_slice($recommendations, 0, 4) as $rec): 
                ?>
                    <a href="<?= BASE_URL ?>book_detail.php?id=<?= $rec['book_id'] ?>" class="group">
                        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden hover:shadow-md hover:border-primary/50 transition-all h-full flex flex-col">
                            <!-- Cover -->
                            <div class="relative aspect-[2/3] bg-gray-800 overflow-hidden">
                                <?php $rec_cover = getBookCoverUrl($rec['cover_image']); ?>
                                <?php if ($rec_cover): ?>
                                    <img src="<?= htmlspecialchars($rec_cover) ?>" 
                                         alt="<?= htmlspecialchars($rec['title']) ?>"
                                         class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                         loading="lazy">
                                <?php else: ?>
                                    <div class="w-full h-full flex flex-col items-center justify-center text-gray-500 gap-2 p-4">
                                        <span class="material-symbols-outlined text-4xl">book</span>
                                        <span class="text-xs text-center line-clamp-2"><?= htmlspecialchars($rec['title']) ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <!-- Info -->
                            <div class="p-3 flex flex-col flex-1">
                                <h3 class="text-white text-sm font-bold line-clamp-2 group-hover:text-primary transition-colors"><?= htmlspecialchars($rec['title']) ?></h3>
                                <p class="text-gray-400 text-xs mt-1 line-clamp-1"><?= htmlspecialchars($rec['author_name'] ?? '') ?></p>
                                <?php if (!empty($rec['rating_avg']) && $rec['rating_avg'] > 0): ?>
                                    <div class="mt-auto pt-2">
                                        <?= ratingStars($rec['rating_avg']) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
