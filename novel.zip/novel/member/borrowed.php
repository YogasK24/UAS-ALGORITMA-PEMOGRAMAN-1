<?php
/**
 * Borrowed Books - BookHaven Digital Library
 * Halaman daftar buku yang sedang dipinjam member
 * 
 * ALGORITMA:
 * - FOREACH: Loop setiap peminjaman aktif
 * - IF-ELSE: Cek overdue, due soon, extend eligibility
 * - ARRAY MULTIDIMENSI: Data peminjaman dengan info buku & tier
 */
require_once __DIR__ . '/../includes/functions.php';
requireMember();

$page_title = 'Buku Dipinjam';
$user_id = $_SESSION['user_id'];

// =============================================
// EXTEND BORROWING (jika ada request)
// ALGORITMA: IF-ELSE untuk validasi
// =============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['extend_borrowing'])) {
    $borrowing_id = intval($_POST['borrow_id']);
    
    // Query peminjaman dengan info tier
    $sql = "SELECT br.*, mt.renewal_limit, mt.borrow_days, mt.tier_name
            FROM borrowings br
            JOIN users u ON br.user_id = u.user_id
            JOIN membership_tiers mt ON u.tier_id = mt.tier_id
            WHERE br.borrow_id = ? AND br.user_id = ? AND br.status = 'borrowed'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $borrowing_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $borrow = mysqli_fetch_assoc($result);
    
    if ($borrow) {
        // PEMILIHAN: Cek apakah masih bisa extend
        if ($borrow['extended_count'] >= $borrow['renewal_limit']) {
            setFlash('danger', "Batas perpanjangan untuk tier {$borrow['tier_name']} sudah tercapai ({$borrow['renewal_limit']}x)");
        } elseif (strtotime($borrow['due_date']) < strtotime('today')) {
            setFlash('danger', 'Tidak bisa memperpanjang. Buku sudah melewati jatuh tempo.');
        } else {
            // Hitung due date baru
            $new_due = date('Y-m-d', strtotime($borrow['due_date'] . " +{$borrow['borrow_days']} days"));
            $new_count = $borrow['extended_count'] + 1;
            
            $sql = "UPDATE borrowings SET due_date = ?, extended_count = ?, updated_at = NOW() 
                    WHERE borrow_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sii", $new_due, $new_count, $borrowing_id);
            
            if (mysqli_stmt_execute($stmt)) {
                setFlash('success', "Berhasil diperpanjang! Jatuh tempo baru: " . formatDate($new_due) . 
                         " (Perpanjangan ke-{$new_count}/{$borrow['renewal_limit']})");
            }
        }
    }
    header("Location: " . BASE_URL . "member/borrowed.php");
    exit;
}

// =============================================
// QUERY PEMINJAMAN AKTIF (ARRAY MULTIDIMENSI)
// =============================================
$sql = "SELECT br.*, b.title, b.cover_image, b.book_id, a.author_name,
               mt.renewal_limit, mt.borrow_days, mt.tier_name, mt.penalty_rate
        FROM borrowings br
        JOIN books b ON br.book_id = b.book_id
        LEFT JOIN authors a ON b.author_id = a.author_id
        JOIN users u ON br.user_id = u.user_id
        JOIN membership_tiers mt ON u.tier_id = mt.tier_id
        WHERE br.user_id = ? AND br.status IN ('borrowed', 'overdue')
        ORDER BY br.due_date ASC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// ARRAY MULTIDIMENSI: Simpan semua peminjaman dengan detail
$borrowings = [];
$total_potential_penalty = 0;

// PERULANGAN (WHILE): Fetch semua data
while ($row = mysqli_fetch_assoc($result)) {
    $due = new DateTime($row['due_date']);
    $today = new DateTime();
    $diff = (int)$today->diff($due)->format('%r%a');
    
    $row['days_remaining'] = $diff;
    $row['is_overdue'] = ($diff < 0);
    $row['is_due_soon'] = ($diff >= 0 && $diff <= 3);
    $row['can_extend'] = ($row['extended_count'] < $row['renewal_limit'] && $diff >= 0);
    
    // Hitung potensi denda jika terlambat
    if ($row['is_overdue']) {
        $row['potential_penalty'] = abs($diff) * $row['penalty_rate'];
        $total_potential_penalty += $row['potential_penalty'];
    } else {
        $row['potential_penalty'] = 0;
    }
    
    $borrowings[] = $row;
}

$user_info = getUserInfo($user_id, $conn);

// Tier badge color mapping
$tier_colors = [
    'Free'    => 'bg-slate-500/20 text-slate-300 border-slate-600',
    'Silver'  => 'bg-slate-400/20 text-slate-200 border-slate-500',
    'Gold'    => 'bg-yellow-500/20 text-yellow-300 border-yellow-600',
    'Premium' => 'bg-purple-500/20 text-purple-300 border-purple-600',
];
$tier_class = $tier_colors[$user_info['tier_name']] ?? $tier_colors['Free'];

// Borrow capacity
$max_b = $user_info['max_books'] == 999 ? 20 : $user_info['max_books'];
$borrow_pct = $max_b > 0 ? round((count($borrowings) / $max_b) * 100) : 0;

include __DIR__ . '/../includes/header.php';
?>

<!-- ===== MAIN CONTENT ===== -->
<main class="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <?php showFlash(); ?>

    <!-- ===== HEADER ===== -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-6">
        <div class="flex flex-col gap-2">
            <div class="flex items-center gap-3">
                <a href="<?= BASE_URL ?>member/dashboard.php" class="text-gray-400 hover:text-white transition-colors">
                    <span class="material-symbols-outlined text-[20px]">arrow_back</span>
                </a>
                <h1 class="text-white text-3xl sm:text-4xl font-black leading-tight tracking-tight">
                    Buku Yang Dipinjam
                </h1>
            </div>
            <p class="text-gray-400 text-base font-normal flex items-center gap-3 flex-wrap ml-8">
                <span class="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-bold border <?= $tier_class ?>">
                    <span class="material-symbols-outlined text-[14px]">verified</span>
                    <?= $user_info['tier_name'] ?>
                </span>
                <span class="text-gray-500">•</span>
                Dipinjam: <strong class="text-primary"><?= count($borrowings) ?></strong> / <?= $user_info['max_books'] == 999 ? '∞' : $user_info['max_books'] ?>
            </p>
        </div>
        <a href="<?= BASE_URL ?>catalog.php" class="flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
            <span class="material-symbols-outlined text-[18px]">add</span>
            Pinjam Buku Baru
        </a>
    </div>

    <!-- ===== STAT SUMMARY CARDS ===== -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <!-- Borrowed Count with Progress -->
        <div class="relative overflow-hidden bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-4 flex flex-col gap-1">
            <div class="flex items-center justify-between mb-1">
                <div class="flex items-center gap-2">
                    <span class="material-symbols-outlined text-primary text-[20px]">library_books</span>
                    <p class="text-[10px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Dipinjam</p>
                </div>
                <span class="text-[10px] font-bold bg-primary/10 text-primary px-2 py-0.5 rounded"><?= min($borrow_pct, 100) ?>%</span>
            </div>
            <p class="text-white tracking-tight text-2xl font-black"><?= count($borrowings) ?> <span class="text-gray-500 text-base font-normal">/ <?= $user_info['max_books'] == 999 ? '∞' : $user_info['max_books'] ?></span></p>
            <div class="absolute bottom-0 left-0 h-1 bg-primary/20 w-full">
                <div class="h-full bg-primary transition-all" style="width: <?= min($borrow_pct, 100) ?>%"></div>
            </div>
        </div>

        <!-- Overdue Count -->
        <?php $overdue_count = count(array_filter($borrowings, fn($b) => $b['is_overdue'])); ?>
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border <?= $overdue_count > 0 ? 'border-red-500/50 dark:border-red-700' : 'border-gray-200 dark:border-gray-700' ?> shadow-sm p-4 flex flex-col gap-1">
            <div class="flex items-center gap-2 mb-1">
                <span class="material-symbols-outlined <?= $overdue_count > 0 ? 'text-red-400' : 'text-green-400' ?> text-[20px]">
                    <?= $overdue_count > 0 ? 'error' : 'check_circle' ?>
                </span>
                <p class="text-[10px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Terlambat</p>
            </div>
            <p class="tracking-tight text-2xl font-black <?= $overdue_count > 0 ? 'text-red-400' : 'text-green-400' ?>"><?= $overdue_count ?></p>
        </div>

        <!-- Due Soon Count -->
        <?php $due_soon_count = count(array_filter($borrowings, fn($b) => $b['is_due_soon'])); ?>
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border <?= $due_soon_count > 0 ? 'border-yellow-500/50 dark:border-yellow-700' : 'border-gray-200 dark:border-gray-700' ?> shadow-sm p-4 flex flex-col gap-1">
            <div class="flex items-center gap-2 mb-1">
                <span class="material-symbols-outlined <?= $due_soon_count > 0 ? 'text-yellow-400' : 'text-gray-400' ?> text-[20px]">schedule</span>
                <p class="text-[10px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Segera Jatuh Tempo</p>
            </div>
            <p class="tracking-tight text-2xl font-black <?= $due_soon_count > 0 ? 'text-yellow-400' : 'text-gray-400' ?>"><?= $due_soon_count ?></p>
        </div>

        <!-- Potential Penalty -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border <?= $total_potential_penalty > 0 ? 'border-red-500/50 dark:border-red-700' : 'border-gray-200 dark:border-gray-700' ?> shadow-sm p-4 flex flex-col gap-1">
            <div class="flex items-center gap-2 mb-1">
                <span class="material-symbols-outlined <?= $total_potential_penalty > 0 ? 'text-red-400' : 'text-green-400' ?> text-[20px]">gavel</span>
                <p class="text-[10px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Potensi Denda</p>
            </div>
            <p class="tracking-tight text-xl font-black <?= $total_potential_penalty > 0 ? 'text-red-400' : 'text-green-400' ?>"><?= formatRupiah($total_potential_penalty) ?></p>
        </div>
    </div>

    <!-- ===== POTENTIAL PENALTY ALERT ===== -->
    <?php if ($total_potential_penalty > 0): ?>
        <div class="flex items-center gap-3 px-5 py-4 rounded-xl border border-red-700 bg-red-900/20 text-sm mb-6">
            <span class="material-symbols-outlined text-red-400 text-[22px]">warning</span>
            <div class="flex-1">
                <p class="text-red-300">
                    <strong class="text-red-200">Perhatian!</strong> Anda memiliki potensi denda sebesar 
                    <strong class="text-red-200"><?= formatRupiah($total_potential_penalty) ?></strong> dari buku yang terlambat dikembalikan.
                    Segera kembalikan untuk menghindari denda bertambah.
                </p>
            </div>
            <a href="<?= BASE_URL ?>member/penalties.php" class="shrink-0 text-xs font-bold text-red-300 hover:text-white bg-red-800/50 hover:bg-red-800 px-3 py-1.5 rounded-lg transition-colors">
                Lihat Denda
            </a>
        </div>
    <?php endif; ?>

    <!-- ===== MAIN TABLE / EMPTY STATE ===== -->
    <?php if (empty($borrowings)): ?>
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm">
            <div class="flex flex-col items-center justify-center py-20 px-6">
                <span class="material-symbols-outlined text-gray-600 text-7xl mb-4">menu_book</span>
                <h3 class="text-white text-xl font-bold mb-2">Tidak ada buku yang sedang dipinjam</h3>
                <p class="text-gray-400 text-sm mb-6 text-center max-w-md">Jelajahi katalog kami untuk menemukan buku menarik dan mulai membaca hari ini.</p>
                <a href="<?= BASE_URL ?>catalog.php" class="flex items-center gap-2 px-6 py-3 bg-primary hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-sm">
                    <span class="material-symbols-outlined text-[18px]">explore</span>
                    Jelajahi Katalog
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 dark:bg-[#293038] text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                            <th class="px-5 py-3.5 w-10">#</th>
                            <th class="px-5 py-3.5">Buku</th>
                            <th class="px-5 py-3.5 whitespace-nowrap">Tgl Pinjam</th>
                            <th class="px-5 py-3.5 whitespace-nowrap">Jatuh Tempo</th>
                            <th class="px-5 py-3.5 whitespace-nowrap">Sisa Hari</th>
                            <th class="px-5 py-3.5 text-center">Perpanjangan</th>
                            <th class="px-5 py-3.5 text-center">Status</th>
                            <th class="px-5 py-3.5 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                        <?php 
                        $no = 1;
                        // PERULANGAN (FOREACH): Tampilkan setiap peminjaman
                        foreach ($borrowings as $borrow): 
                        ?>
                            <tr class="<?= $borrow['is_overdue'] ? 'bg-red-900/10' : '' ?> hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                <!-- # -->
                                <td class="px-5 py-4 text-gray-500 font-medium"><?= $no++ ?></td>

                                <!-- Buku -->
                                <td class="px-5 py-4">
                                    <div class="flex items-center gap-3">
                                        <?php $borrow_cover = getBookCoverUrl($borrow['cover_image']); ?>
                                        <?php if ($borrow_cover): ?>
                                            <img src="<?= htmlspecialchars($borrow_cover) ?>" 
                                                 alt="" class="w-10 h-14 rounded object-cover shadow-sm flex-shrink-0 <?= $borrow['is_overdue'] ? 'grayscale opacity-80' : '' ?>" loading="lazy">
                                        <?php else: ?>
                                            <div class="w-10 h-14 rounded bg-gray-700 flex items-center justify-center flex-shrink-0">
                                                <span class="material-symbols-outlined text-gray-500 text-[18px]">book</span>
                                            </div>
                                        <?php endif; ?>
                                        <div class="min-w-0">
                                            <a href="<?= BASE_URL ?>book_detail.php?id=<?= $borrow['book_id'] ?>" class="text-white font-semibold hover:text-primary transition-colors truncate block">
                                                <?= htmlspecialchars($borrow['title']) ?>
                                            </a>
                                            <p class="text-gray-400 text-xs truncate"><?= htmlspecialchars($borrow['author_name'] ?? '-') ?></p>
                                        </div>
                                    </div>
                                </td>

                                <!-- Tgl Pinjam -->
                                <td class="px-5 py-4 text-gray-300 whitespace-nowrap"><?= formatDate($borrow['borrow_date']) ?></td>

                                <!-- Jatuh Tempo -->
                                <td class="px-5 py-4 whitespace-nowrap <?= $borrow['is_overdue'] ? 'text-red-400 font-bold' : ($borrow['is_due_soon'] ? 'text-yellow-400 font-bold' : 'text-gray-300') ?>">
                                    <?= formatDate($borrow['due_date']) ?>
                                </td>

                                <!-- Sisa Hari -->
                                <td class="px-5 py-4 whitespace-nowrap">
                                    <?php 
                                    // PEMILIHAN (IF-ELSE): Warna berdasarkan sisa hari
                                    if ($borrow['is_overdue']): 
                                    ?>
                                        <div class="flex flex-col gap-1">
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-900/30 text-red-400 border border-red-800 w-fit">
                                                <span class="material-symbols-outlined text-[14px]">error</span>
                                                -<?= abs($borrow['days_remaining']) ?> hari
                                            </span>
                                            <?php if ($borrow['potential_penalty'] > 0): ?>
                                                <span class="text-[11px] text-red-400/80 font-medium pl-1">Denda: <?= formatRupiah($borrow['potential_penalty']) ?></span>
                                            <?php endif; ?>
                                        </div>
                                    <?php elseif ($borrow['is_due_soon']): ?>
                                        <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-yellow-900/30 text-yellow-400 border border-yellow-800 w-fit">
                                            <span class="material-symbols-outlined text-[14px]">warning</span>
                                            <?= $borrow['days_remaining'] ?> hari
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-green-900/30 text-green-400 border border-green-800 w-fit">
                                            <?= $borrow['days_remaining'] ?> hari
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Perpanjangan -->
                                <td class="px-5 py-4 text-center">
                                    <span class="text-gray-300 font-medium">
                                        <?= $borrow['extended_count'] ?><span class="text-gray-500">/<?= $borrow['renewal_limit'] == 999 ? '∞' : $borrow['renewal_limit'] ?></span>
                                    </span>
                                </td>

                                <!-- Status -->
                                <td class="px-5 py-4 text-center">
                                    <?php if ($borrow['is_overdue']): ?>
                                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-burgundy/80 text-white border border-red-800 animate-pulse">
                                            <span class="material-symbols-outlined text-[12px]">error</span>
                                            TERLAMBAT
                                        </span>
                                    <?php elseif ($borrow['is_due_soon']): ?>
                                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-yellow-900/30 text-yellow-400 border border-yellow-800">
                                            <span class="material-symbols-outlined text-[12px]">warning</span>
                                            SEGERA
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-green-900/30 text-green-400 border border-green-800">
                                            <span class="size-1.5 rounded-full bg-green-500 animate-pulse"></span>
                                            AKTIF
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Aksi -->
                                <td class="px-5 py-4">
                                    <div class="flex items-center justify-center gap-2">
                                        <!-- Tombol Kembalikan -->
                                        <form method="POST" action="<?= BASE_URL ?>return_book.php" class="inline">
                                            <input type="hidden" name="borrow_id" value="<?= $borrow['borrow_id'] ?>">
                                            <button type="submit" onclick="return confirm('Kembalikan buku ini?')"
                                                    class="inline-flex items-center gap-1.5 px-3 py-1.5 <?= $borrow['is_overdue'] 
                                                        ? 'bg-burgundy hover:bg-red-900 text-white border-red-800' 
                                                        : 'bg-green-600/20 hover:bg-green-600/30 text-green-400 border-green-700/50' 
                                                    ?> rounded-lg text-xs font-semibold transition-colors border"
                                                    title="Kembalikan buku">
                                                <span class="material-symbols-outlined text-[16px]">check_circle</span>
                                                <span class="hidden sm:inline">Kembalikan</span>
                                            </button>
                                        </form>
                                        
                                        <!-- Tombol Perpanjang -->
                                        <?php if ($borrow['can_extend']): ?>
                                            <form method="POST" class="inline">
                                                <input type="hidden" name="borrow_id" value="<?= $borrow['borrow_id'] ?>">
                                                <input type="hidden" name="extend_borrowing" value="1">
                                                <button type="submit" onclick="return confirm('Perpanjang peminjaman buku ini?')"
                                                        class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-primary/20 hover:bg-primary/30 text-primary rounded-lg text-xs font-semibold transition-colors border border-primary/30"
                                                        title="Perpanjang peminjaman">
                                                    <span class="material-symbols-outlined text-[16px]">update</span>
                                                    <span class="hidden sm:inline">Perpanjang</span>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <button disabled
                                                    class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-800 text-gray-600 rounded-lg text-xs font-semibold border border-gray-700 cursor-not-allowed"
                                                    title="<?= $borrow['is_overdue'] ? 'Tidak bisa perpanjang: buku sudah terlambat' : 'Batas perpanjangan tercapai' ?>">
                                                <span class="material-symbols-outlined text-[16px]">block</span>
                                                <span class="hidden sm:inline">Perpanjang</span>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Table Footer Summary -->
            <div class="px-5 py-3 bg-gray-50 dark:bg-[#293038] border-t border-gray-200 dark:border-gray-700 flex flex-wrap items-center justify-between gap-3 text-xs text-gray-400">
                <span>Menampilkan <strong class="text-white"><?= count($borrowings) ?></strong> peminjaman aktif</span>
                <div class="flex items-center gap-4">
                    <span class="flex items-center gap-1.5">
                        <span class="size-2 rounded-full bg-green-500"></span> Aktif
                    </span>
                    <span class="flex items-center gap-1.5">
                        <span class="size-2 rounded-full bg-yellow-500"></span> Segera Jatuh Tempo
                    </span>
                    <span class="flex items-center gap-1.5">
                        <span class="size-2 rounded-full bg-red-500"></span> Terlambat
                    </span>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- ===== HELP BOX ===== -->
    <div class="mt-6 rounded-xl bg-blue-900/20 p-5 border border-blue-800 flex items-start gap-4">
        <span class="material-symbols-outlined text-primary mt-0.5 text-[22px]">help</span>
        <div class="flex-1">
            <h4 class="font-bold text-white text-sm mb-1">Butuh bantuan?</h4>
            <p class="text-xs text-gray-400 leading-relaxed">
                Kembalikan buku tepat waktu untuk menghindari denda. Tier 
                <strong class="text-white"><?= $user_info['tier_name'] ?></strong> Anda memungkinkan 
                <strong class="text-white"><?= $user_info['renewal_limit'] == 999 ? 'unlimited' : $user_info['renewal_limit'] . 'x' ?></strong> perpanjangan 
                dan <strong class="text-white"><?= $user_info['borrow_days'] ?></strong> hari masa pinjam per buku.
                <?php if ($user_info['penalty_rate'] > 0): ?>
                    Denda keterlambatan: <strong class="text-white"><?= formatRupiah($user_info['penalty_rate']) ?></strong>/hari.
                <?php else: ?>
                    <strong class="text-green-400">Tanpa denda keterlambatan</strong> untuk tier Premium.
                <?php endif; ?>
            </p>
        </div>
    </div>

</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
