<?php
/**
 * Member Penalties - BookHaven Digital Library
 * Halaman denda member
 * ALGORITMA: FOREACH, IF-ELSE, ARRAY
 */
require_once __DIR__ . '/../includes/functions.php';
requireMember();

$page_title = 'Denda Saya';
$user_id = $_SESSION['user_id'];

// Bayar denda (simulasi)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_penalty'])) {
    $penalty_id = intval($_POST['penalty_id']);
    $method = sanitize($_POST['payment_method'] ?? 'Transfer Bank');
    
    $sql = "UPDATE penalties SET penalty_status = 'paid', paid_at = NOW(), payment_method = ? 
            WHERE penalty_id = ? AND user_id = ? AND penalty_status = 'unpaid'";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sii", $method, $penalty_id, $user_id);
    
    if (mysqli_stmt_execute($stmt) && mysqli_affected_rows($conn) > 0) {
        setFlash('success', 'Denda berhasil dibayar! (Simulasi)');
    } else {
        setFlash('danger', 'Gagal memproses pembayaran');
    }
    header("Location: " . BASE_URL . "member/penalties.php");
    exit;
}

// Query denda
$sql = "SELECT p.*, b.title, br.borrow_date, br.due_date, br.return_date
        FROM penalties p
        JOIN borrowings br ON p.borrow_id = br.borrow_id
        JOIN books b ON br.book_id = b.book_id
        WHERE p.user_id = ?
        ORDER BY p.created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$penalties = [];
$total_unpaid = 0;
while ($row = mysqli_fetch_assoc($result)) {
    $penalties[] = $row;
    if ($row['penalty_status'] === 'unpaid') {
        $total_unpaid += $row['penalty_amount'];
    }
}

include __DIR__ . '/../includes/header.php';
?>

<main class="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- Page Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
            <h1 class="text-white text-3xl font-black tracking-tight flex items-center gap-3">
                <span class="material-symbols-outlined text-yellow-400 text-3xl">gavel</span>
                Denda Saya
            </h1>
            <p class="text-gray-400 text-sm mt-1">Informasi denda dan pembayaran</p>
        </div>
    </div>

    <?php showFlash(); ?>

    <?php if ($total_unpaid > 0): ?>
        <!-- Unpaid Alert -->
        <div class="bg-red-500/10 border border-red-500/30 rounded-xl p-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div class="flex items-center gap-3 flex-1">
                <div class="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
                    <span class="material-symbols-outlined text-red-400 text-2xl">warning</span>
                </div>
                <div>
                    <h3 class="text-red-400 font-bold text-sm">Total Denda Belum Bayar</h3>
                    <p class="text-red-300 text-2xl font-black mt-0.5"><?= formatRupiah($total_unpaid) ?></p>
                    <p class="text-red-400/70 text-xs mt-1">Harap bayar denda untuk dapat meminjam buku kembali.</p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if (empty($penalties)): ?>
        <!-- Empty State -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm p-12 text-center">
            <span class="material-symbols-outlined text-6xl text-green-500 mb-4">sentiment_satisfied</span>
            <h3 class="text-xl font-bold text-gray-900 dark:text-white mt-3">Tidak ada denda</h3>
            <p class="text-gray-500 dark:text-gray-400 mt-2">Terus pertahankan! Kembalikan buku tepat waktu.</p>
        </div>
    <?php else: ?>
        <!-- Penalties Table -->
        <div class="bg-white dark:bg-[#1e293b] rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead class="bg-gray-50 dark:bg-[#293038] text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                        <tr>
                            <th class="px-6 py-4">#</th>
                            <th class="px-6 py-4">Buku</th>
                            <th class="px-6 py-4">Terlambat</th>
                            <th class="px-6 py-4">Jumlah</th>
                            <th class="px-6 py-4">Status</th>
                            <th class="px-6 py-4">Tanggal Bayar</th>
                            <th class="px-6 py-4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                        <?php 
                        $no = 1;
                        foreach ($penalties as $penalty): 
                        ?>
                            <tr class="<?= $penalty['penalty_status'] === 'unpaid' ? 'bg-red-500/5' : '' ?> hover:bg-gray-50 dark:hover:bg-[#293038]/50 transition-colors">
                                <td class="px-6 py-4 text-gray-500 dark:text-gray-400 font-medium"><?= $no++ ?></td>
                                <td class="px-6 py-4">
                                    <p class="text-white font-semibold text-sm"><?= htmlspecialchars($penalty['title']) ?></p>
                                    <div class="flex flex-wrap gap-x-3 gap-y-0.5 mt-1">
                                        <span class="text-gray-500 text-xs flex items-center gap-1">
                                            <span class="material-symbols-outlined text-[12px]">calendar_today</span>
                                            Pinjam: <?= formatDate($penalty['borrow_date']) ?>
                                        </span>
                                        <span class="text-gray-500 text-xs flex items-center gap-1">
                                            <span class="material-symbols-outlined text-[12px]">event</span>
                                            Tempo: <?= formatDate($penalty['due_date']) ?>
                                        </span>
                                        <span class="text-gray-500 text-xs flex items-center gap-1">
                                            <span class="material-symbols-outlined text-[12px]">event_available</span>
                                            Kembali: <?= formatDate($penalty['return_date']) ?>
                                        </span>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-red-500/20 text-red-400">
                                        <?= $penalty['days_late'] ?> hari
                                    </span>
                                </td>
                                <td class="px-6 py-4 font-bold text-white whitespace-nowrap"><?= formatRupiah($penalty['penalty_amount']) ?></td>
                                <td class="px-6 py-4">
                                    <?php if ($penalty['penalty_status'] === 'unpaid'): ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-400 border border-red-500/30">
                                            <span class="w-1.5 h-1.5 rounded-full bg-red-400"></span>Belum Bayar
                                        </span>
                                    <?php elseif ($penalty['penalty_status'] === 'paid'): ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-green-500/20 text-green-400 border border-green-500/30">
                                            <span class="w-1.5 h-1.5 rounded-full bg-green-400"></span>Lunas
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-500/20 text-gray-400 border border-gray-500/30">
                                            <span class="w-1.5 h-1.5 rounded-full bg-gray-400"></span>Dibebaskan
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 text-gray-300 whitespace-nowrap"><?= $penalty['paid_at'] ? formatDate($penalty['paid_at']) : '<span class="text-gray-500">-</span>' ?></td>
                                <td class="px-6 py-4">
                                    <?php if ($penalty['penalty_status'] === 'unpaid'): ?>
                                        <form method="POST">
                                            <input type="hidden" name="penalty_id" value="<?= $penalty['penalty_id'] ?>">
                                            <input type="hidden" name="payment_method" value="Transfer Bank">
                                            <input type="hidden" name="pay_penalty" value="1">
                                            <button type="submit" 
                                                    onclick="return confirm('Bayar denda <?= formatRupiah($penalty['penalty_amount']) ?>?')"
                                                    class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-lg text-xs font-semibold transition-colors">
                                                <span class="material-symbols-outlined text-[16px]">credit_card</span> Bayar
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-gray-500 text-xs"><?= $penalty['payment_method'] ?? '-' ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Summary -->
        <div class="mt-4 text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2">
            <span class="material-symbols-outlined text-[16px]">info</span>
            Menampilkan <?= count($penalties) ?> catatan denda
        </div>
    <?php endif; ?>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
