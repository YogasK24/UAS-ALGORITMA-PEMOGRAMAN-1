/**
 * BookHaven Digital Library - Penalty Calculator
 * Kalkulator denda keterlambatan (client-side)
 * Algoritma: switch-case, if-else, operasi aritmatika
 */

/**
 * Kalkulasi denda berdasarkan hari terlambat dan tier
 * @param {number} daysLate - Jumlah hari keterlambatan
 * @param {number} tierId - ID tier membership (1-4)
 * @returns {number} - Jumlah denda dalam Rupiah
 */
function calculatePenalty(daysLate, tierId) {
  if (daysLate <= 0) return 0;

  let ratePerDay = 0;

  // Switch-case untuk menentukan tarif per hari berdasarkan tier
  switch (tierId) {
    case 1: // Free
      ratePerDay = 1000;
      break;
    case 2: // Silver
      ratePerDay = 750;
      break;
    case 3: // Gold
      ratePerDay = 500;
      break;
    case 4: // Premium
      ratePerDay = 250;
      break;
    default:
      ratePerDay = 1000;
  }

  let penalty = daysLate * ratePerDay;

  // Maksimum denda berdasarkan tier
  let maxPenalty;
  if (tierId === 4) {
    maxPenalty = 25000;
  } else if (tierId === 3) {
    maxPenalty = 50000;
  } else if (tierId === 2) {
    maxPenalty = 75000;
  } else {
    maxPenalty = 100000;
  }

  // Pastikan denda tidak melebihi maksimum
  if (penalty > maxPenalty) {
    penalty = maxPenalty;
  }

  return penalty;
}

/**
 * Format angka ke format Rupiah
 * @param {number} amount - Jumlah uang
 * @returns {string} - String terformat
 */
function formatRupiah(amount) {
  return "Rp " + amount.toLocaleString("id-ID");
}

/**
 * Hitung sisa hari sebelum batas waktu
 * @param {string} dueDateStr - Tanggal batas (format YYYY-MM-DD)
 * @returns {number} - Sisa hari (negatif = terlambat)
 */
function calculateDaysRemaining(dueDateStr) {
  const dueDate = new Date(dueDateStr);
  const now = new Date();
  const diffTime = dueDate.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

/**
 * Update tampilan kalkulator denda
 * Dipanggil saat user input berubah
 */
function updatePenaltyDisplay() {
  const daysInput = document.getElementById("calc-days");
  const tierSelect = document.getElementById("calc-tier");
  const resultDiv = document.getElementById("calc-result");

  if (!daysInput || !tierSelect || !resultDiv) return;

  const daysLate = parseInt(daysInput.value) || 0;
  const tierId = parseInt(tierSelect.value) || 1;
  const penalty = calculatePenalty(daysLate, tierId);

  // Tier names array
  const tierNames = { 1: "Free", 2: "Silver", 3: "Gold", 4: "Premium" };

  if (daysLate > 0) {
    resultDiv.innerHTML = `
            <div class="flex flex-col gap-2 px-4 py-3 rounded-xl border bg-yellow-100 dark:bg-yellow-900/30 border-yellow-400 dark:border-yellow-700 text-yellow-800 dark:text-yellow-300 text-sm">
                <p class="font-semibold">Estimasi Denda</p>
                <p>Tier: <strong>${tierNames[tierId]}</strong></p>
                <p>Hari terlambat: <strong>${daysLate} hari</strong></p>
                <hr class="border-yellow-400/30">
                <p class="text-lg font-bold text-red-600 dark:text-red-400">${formatRupiah(penalty)}</p>
            </div>
        `;
  } else {
    resultDiv.innerHTML = `
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl border bg-blue-100 dark:bg-blue-900/30 border-blue-400 dark:border-blue-700 text-blue-800 dark:text-blue-300 text-sm">
                <span class="material-symbols-outlined text-[20px]">info</span>
                <p>Masukkan jumlah hari keterlambatan untuk melihat estimasi denda.</p>
            </div>
        `;
  }
}

/**
 * Konfirmasi sebelum aksi penting
 * @param {string} message - Pesan konfirmasi
 * @returns {boolean}
 */
function confirmAction(message) {
  return confirm(message || "Apakah Anda yakin?");
}

/**
 * Auto-hide flash messages setelah 5 detik
 */
document.addEventListener("DOMContentLoaded", function () {
  // Auto dismiss flash alerts after 5 seconds
  const alerts = document.querySelectorAll('[role="alert"]');
  alerts.forEach(function (alert) {
    setTimeout(function () {
      alert.style.transition = "opacity 0.3s ease, transform 0.3s ease";
      alert.style.opacity = "0";
      alert.style.transform = "translateY(-10px)";
      setTimeout(function () {
        alert.remove();
      }, 300);
    }, 5000);
  });
});
