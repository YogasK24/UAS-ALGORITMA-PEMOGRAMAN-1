<?php
/**
 * Borrow Book Process - BookHaven Digital Library
 * 
 * ALGORITMA UTAMA:
 * - PEMILIHAN (IF-ELSE): Validasi login, ketersediaan, tier limit, denda
 * - ARRAY: Tier info dari canUserBorrow()
 * - FUNCTION CALL: canUserBorrow()
 * - TRANSACTION: Untuk konsistensi data
 */
require_once __DIR__ . '/includes/functions.php';

// =============================================
// STEP 1: Cek login member (PEMILIHAN if-else)
// =============================================
if (!isLoggedIn() || !isMember()) {
    header("Location: " . BASE_URL . "auth/login.php?error=Silakan login sebagai member terlebih dahulu");
    exit;
}

// PEMILIHAN: Cek method POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . BASE_URL . "catalog.php");
    exit;
}

// =============================================
// STEP 2: Ambil book_id dari POST
// =============================================
$book_id = intval($_POST['book_id'] ?? 0);
$user_id = $_SESSION['user_id'];

if ($book_id <= 0) {
    setFlash('danger', 'ID buku tidak valid');
    header("Location: " . BASE_URL . "catalog.php");
    exit;
}

// =============================================
// STEP 3: Cek ketersediaan buku (PEMILIHAN if-else)
// =============================================
$sql = "SELECT * FROM books WHERE book_id = ? AND is_active = 1";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $book_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$book = mysqli_fetch_assoc($result);

if (!$book) {
    setFlash('danger', 'Buku tidak ditemukan');
    header("Location: " . BASE_URL . "catalog.php");
    exit;
}

if ($book['available_copies'] <= 0) {
    setFlash('danger', 'Maaf, buku "' . $book['title'] . '" sedang tidak tersedia (semua stok dipinjam)');
    header("Location: " . BASE_URL . "book_detail.php?id=$book_id");
    exit;
}

// Cek apakah user sudah meminjam buku ini
$sql = "SELECT borrow_id FROM borrowings WHERE user_id = ? AND book_id = ? AND status = 'borrowed'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $user_id, $book_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if (mysqli_num_rows($result) > 0) {
    setFlash('warning', 'Anda sudah meminjam buku ini. Silakan kembalikan dulu sebelum meminjam lagi.');
    header("Location: " . BASE_URL . "book_detail.php?id=$book_id");
    exit;
}

// =============================================
// STEP 4: Cek batas peminjaman tier (FUNCTION CALL + ARRAY)
// =============================================
$borrow_check = canUserBorrow($user_id, $conn); // Mengembalikan ARRAY

// PEMILIHAN: Apakah boleh meminjam?
if (!$borrow_check['can_borrow']) {
    // PEMILIHAN: Alasan tidak bisa meminjam
    if ($borrow_check['has_unpaid_penalty']) {
        setFlash('danger', 'Anda memiliki denda yang belum dibayar. Harap bayar denda terlebih dahulu sebelum meminjam.');
    } else {
        setFlash('danger', $borrow_check['message']);
    }
    header("Location: " . BASE_URL . "book_detail.php?id=$book_id");
    exit;
}

// =============================================
// STEP 5: Hitung tanggal jatuh tempo berdasarkan tier
// =============================================
$borrow_date = date('Y-m-d');
$due_date = date('Y-m-d', strtotime("+{$borrow_check['borrow_days']} days"));

// =============================================
// STEP 6: Mulai TRANSACTION
// =============================================
mysqli_begin_transaction($conn);

try {
    // INSERT ke tabel borrowings
    $sql = "INSERT INTO borrowings (user_id, book_id, borrow_date, due_date, status) 
            VALUES (?, ?, ?, ?, 'borrowed')";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "iiss", $user_id, $book_id, $borrow_date, $due_date);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Gagal menyimpan data peminjaman");
    }
    
    // UPDATE stok buku: available_copies - 1, total_borrowed + 1
    $sql = "UPDATE books SET available_copies = available_copies - 1, 
                             total_borrowed = total_borrowed + 1 
            WHERE book_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $book_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Gagal mengupdate stok buku");
    }
    
    // COMMIT transaction
    mysqli_commit($conn);
    
    // STEP 7: Tampilkan pesan sukses
    setFlash('success', "Buku \"{$book['title']}\" berhasil dipinjam!<br>
        <strong>Tanggal Pinjam:</strong> " . formatDate($borrow_date) . "<br>
        <strong>Jatuh Tempo:</strong> " . formatDate($due_date) . "<br>
        <strong>Tier:</strong> {$borrow_check['tier_name']} ({$borrow_check['borrow_days']} hari)<br>
        <strong>Kuota Pinjam:</strong> " . ($borrow_check['current_count'] + 1) . "/{$borrow_check['max_books']}");
    
    header("Location: " . BASE_URL . "member/borrowed.php");
    exit;
    
} catch (Exception $e) {
    // ROLLBACK jika ada error
    mysqli_rollback($conn);
    setFlash('danger', 'Terjadi kesalahan: ' . $e->getMessage());
    header("Location: " . BASE_URL . "book_detail.php?id=$book_id");
    exit;
}
?>
