<?php
/**
 * BookHaven - Cron Job: Cek Peminjaman Terlambat
 * Jalankan harian untuk menandai peminjaman yang melewati batas waktu
 * 
 * Algoritma:
 * - while loop untuk iterasi setiap peminjaman aktif
 * - if-else untuk cek apakah sudah melewati due_date
 * - foreach untuk proses batch update
 * 
 * Cara menjalankan:
 * php c:\xampp\htdocs\novel\digital-library\cron\check_overdue.php
 * Atau via browser: http://localhost/novel/digital-library/cron/check_overdue.php
 */

require_once __DIR__ . '/../config/database.php';

$now = date('Y-m-d H:i:s');
echo "=== BookHaven Overdue Checker ===\n";
echo "Waktu: $now\n\n";

// 1. Ambil semua peminjaman aktif yang sudah melewati batas
$sql = "SELECT br.borrow_id, br.user_id, br.book_id, br.due_date, u.full_name, b.title
        FROM borrowings br
        JOIN users u ON br.user_id = u.user_id
        JOIN books b ON br.book_id = b.book_id
        WHERE br.status = 'borrowed' AND br.due_date < ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $now);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$overdue_list = [];
while ($row = mysqli_fetch_assoc($result)) {
    $overdue_list[] = $row;
}

echo "Ditemukan " . count($overdue_list) . " peminjaman terlambat.\n\n";

// 2. Update status menjadi overdue
$updated = 0;
$errors = 0;

foreach ($overdue_list as $item) {
    $due = new DateTime($item['due_date']);
    $current = new DateTime($now);
    $diff = $current->diff($due);
    $days_late = $diff->days;

    // Update status
    $update_sql = "UPDATE borrowings SET status = 'overdue' WHERE borrow_id = ? AND status = 'borrowed'";
    $update_stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($update_stmt, "i", $item['borrow_id']);

    if (mysqli_stmt_execute($update_stmt)) {
        if (mysqli_affected_rows($conn) > 0) {
            $updated++;
            echo "[OVERDUE] ID:{$item['borrow_id']} - {$item['full_name']} - \"{$item['title']}\" - {$days_late} hari terlambat\n";
        }
    } else {
        $errors++;
        echo "[ERROR] Gagal update ID:{$item['borrow_id']}\n";
    }
}

echo "\n=== Selesai ===\n";
echo "Diupdate: $updated\n";
echo "Error: $errors\n";

mysqli_close($conn);
