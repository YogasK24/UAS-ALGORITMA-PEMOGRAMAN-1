<?php
/**
 * Return Book Process - BookHaven Digital Library
 * 
 * ALGORITMA UTAMA:
 * - FUNCTION: calculatePenalty() - Menghitung denda otomatis
 * - PEMILIHAN (IF-ELSE): Validasi dan cek keterlambatan
 * - SWITCH-CASE: (di dalam calculatePenalty) Tarif denda per tier
 * - TRANSACTION: Untuk konsistensi data
 */
require_once __DIR__ . '/includes/functions.php';

// Cek login
if (!isLoggedIn()) {
    header("Location: " . BASE_URL . "auth/login.php");
    exit;
}

// PEMILIHAN: Cek method POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: " . BASE_URL . "member/borrowed.php");
    exit;
}

// =============================================
// STEP 1: Ambil borrowing_id dari POST
// =============================================
$borrowing_id = intval($_POST['borrow_id'] ?? 0);
$user_id = $_SESSION['user_id'];

if ($borrowing_id <= 0) {
    setFlash('danger', 'ID peminjaman tidak valid');
    header("Location: " . BASE_URL . "member/borrowed.php");
    exit;
}

// =============================================
// STEP 2: Ambil detail peminjaman
// =============================================
$sql = "SELECT br.*, b.title, b.book_id 
        FROM borrowings br 
        JOIN books b ON br.book_id = b.book_id 
        WHERE br.borrow_id = ? AND br.status IN ('borrowed', 'overdue')";

// Admin bisa mengembalikan buku siapa saja
if (!isAdmin()) {
    $sql .= " AND br.user_id = ?";
}

$stmt = mysqli_prepare($conn, $sql);
if (isAdmin()) {
    mysqli_stmt_bind_param($stmt, "i", $borrowing_id);
} else {
    mysqli_stmt_bind_param($stmt, "ii", $borrowing_id, $user_id);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$borrowing = mysqli_fetch_assoc($result);

// PEMILIHAN: Validasi peminjaman
if (!$borrowing) {
    setFlash('danger', 'Data peminjaman tidak ditemukan');
    header("Location: " . BASE_URL . "member/borrowed.php");
    exit;
}

// =============================================
// STEP 3: Set tanggal pengembalian = hari ini
// =============================================
$return_date = date('Y-m-d');

// =============================================
// STEP 4: Hitung denda (FUNCTION CALL)
// Di dalam calculatePenalty() ada SWITCH-CASE untuk tarif
// =============================================
$penalty_info = calculatePenalty($borrowing_id, $conn);

// =============================================
// STEP 5: Mulai TRANSACTION
// =============================================
mysqli_begin_transaction($conn);

try {
    // PEMILIHAN: Jika ada denda
    if (is_array($penalty_info) && $penalty_info['total_amount'] > 0) {
        // INSERT ke tabel penalties
        $sql = "INSERT INTO penalties (borrow_id, user_id, penalty_amount, days_late, penalty_status) 
                VALUES (?, ?, ?, ?, 'unpaid')";
        $stmt = mysqli_prepare($conn, $sql);
        $penalty_user = $borrowing['user_id'];
        $amount = $penalty_info['total_amount'];
        $days = $penalty_info['days_late'];
        mysqli_stmt_bind_param($stmt, "iidi", $borrowing_id, $penalty_user, $amount, $days);
        
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Gagal menyimpan data denda");
        }
    }
    
    // UPDATE peminjaman: set return_date dan status
    $sql = "UPDATE borrowings SET return_date = ?, status = 'returned', 
            updated_at = NOW() WHERE borrow_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $return_date, $borrowing_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Gagal mengupdate peminjaman");
    }
    
    // UPDATE stok buku: available_copies + 1
    $sql = "UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    $book_id = $borrowing['book_id'];
    mysqli_stmt_bind_param($stmt, "i", $book_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Gagal mengupdate stok buku");
    }
    
    // COMMIT transaction
    mysqli_commit($conn);
    
    // =============================================
    // STEP 6: Tampilkan pesan hasil
    // =============================================
    // PEMILIHAN: Ada denda atau tidak
    if (is_array($penalty_info) && $penalty_info['total_amount'] > 0) {
        setFlash('warning', "Buku \"{$borrowing['title']}\" berhasil dikembalikan.<br>
            <strong class='text-danger'>⚠️ Terlambat {$penalty_info['days_late']} hari</strong><br>
            <strong>Tarif Denda:</strong> " . formatRupiah($penalty_info['penalty_rate']) . "/hari ({$penalty_info['tier_name']})<br>
            <strong>Total Denda:</strong> " . formatRupiah($penalty_info['total_amount']) . "<br>
            <em>Silakan bayar denda di halaman Denda.</em>");
    } else {
        setFlash('success', "Buku \"{$borrowing['title']}\" berhasil dikembalikan tepat waktu. Terima kasih!");
    }
    
    // Redirect berdasarkan role
    if (isAdmin()) {
        header("Location: " . BASE_URL . "admin/borrowings.php");
    } else {
        header("Location: " . BASE_URL . "member/borrowed.php");
    }
    exit;
    
} catch (Exception $e) {
    // ROLLBACK jika ada error
    mysqli_rollback($conn);
    setFlash('danger', 'Terjadi kesalahan: ' . $e->getMessage());
    header("Location: " . BASE_URL . "member/borrowed.php");
    exit;
}
?>
